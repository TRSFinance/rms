/*
 * Created: liushen@Jul 27, 2014 9:40:05 PM
 */
package com.trs.dev4.jdk16.model;

/**
 * 领域对象校验接口。 <br>
 */
public interface IValidator {

	/**
	 * 校验整个对象；要注意，如果校验通过，则必须返回{@link ValidationErrors#NO_ERRORS}对象(而不是返回<code>null</code>
	 * ，否则可能会使后续Spring过程空指针)。
	 * 
	 * @param object
	 *            要校验的对象
	 * @return 校验结果集；注意不能返回<code>null</code>
	 */
	ValidationErrors validate(Object object);

	/**
	 * 校验单个字段；主要用于支持Ajax边输入边验证等场景。
	 * 
	 * @param name
	 *            要检验的字段
	 * @param value
	 *            要校验的字段的值
	 * @return 校验结果
	 */
	ValidationError validate(String name, String value);

}
