package com.trs.dev4.jdk16.cms.tag;

import java.util.Iterator;
import java.util.List;

import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.bo.TagItem;

public class WrapLineTagParser implements TagParser {

	@Override
	public String parse(TagContext tagContext) {
		StringBuilder content = new StringBuilder();
		TagItem tagItem = tagContext.getTagItem();
		List<TagItem> tagItems = tagItem.getChildren();
		for (Iterator<TagItem> iterator = tagItems.iterator(); iterator.hasNext();) {
			TagItem child = iterator.next();
			if (child.isTRSTag()) {
				TagContext childTagContext = new TagContext(tagContext.getGeneratorSession(), child, tagContext.getEntity());
				childTagContext.setPageletTagContext(tagContext.getPageletTagContext());
				content.append(tagContext.parse(childTagContext));
			} else {
				content.append(child.getContent());
			}
		}
		return content.toString();
	}

}
