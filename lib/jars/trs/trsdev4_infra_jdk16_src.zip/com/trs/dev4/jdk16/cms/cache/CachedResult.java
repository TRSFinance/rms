/*
 * Created: yangyu@Aug 7, 2013 9:20:18 AM
 */
package com.trs.dev4.jdk16.cms.cache;

/**
 * 职责: 封装缓存返回的结果，主要为了区分缓存Null数据和缓存不存在的Null数据<br>
 * 
 */
public class CachedResult {
	
	/**
	 * 被缓存数据
	 */
	private Object resultObject;
	
	/**
	 * 数据状态
	 */
	private Status status = Status.EXIST;
	
	public final static CachedResult NOTEXISTED = new CachedResult(Status.NOTEXIST);

	/**
	 * @param resultObject
	 */
	public CachedResult(Object resultObject) {
		super();
		this.resultObject = resultObject;
	}
	
	/**
	 * @param resultObject
	 * @param status
	 */
	public CachedResult(Status status) {
		super();
		this.status = status;
	}

	/**
	 * 是否在缓存中不存在
	 * 
	 * @return
	 * @since yangyu @ Aug 7, 2013
	 */
	public boolean notExist() {
		return status.equals(Status.NOTEXIST);
	}

	/**
	 * @return the {@link #resultObject}
	 */
	public Object getResultObject() {
		return resultObject;
	}
	
	private enum Status {
		NOTEXIST, EXIST;
	}

}
