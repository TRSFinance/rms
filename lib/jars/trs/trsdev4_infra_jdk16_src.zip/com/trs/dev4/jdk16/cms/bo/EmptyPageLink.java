/*
 * Created: yangyu@May 17, 2013 11:26:27 AM
 */
package com.trs.dev4.jdk16.cms.bo;

/**
 * 职责: <br>
 * 
 */
public class EmptyPageLink extends PageLink {

	/**
	 * @since yangyu @ May 17, 2013
	 */
	private static final long serialVersionUID = 1L;

}
