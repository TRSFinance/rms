package com.trs.dev4.jdk16.cms.extension;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.trs.dev4.jdk16.cms.BaseurlExtractor;
import com.trs.dev4.jdk16.cms.GeneratorSessionFactory;
import com.trs.dev4.jdk16.cms.PageLinkManager;
import com.trs.dev4.jdk16.cms.SettingFactory;
import com.trs.dev4.jdk16.cms.SiteManager;
import com.trs.dev4.jdk16.cms.TagAware;
import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.TemplateManager;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.cache.CacheableTagAware;
import com.trs.dev4.jdk16.cms.cache.DefaultTagAware;
import com.trs.dev4.jdk16.cms.core.GeneratorSessionFactoryImpl;
import com.trs.dev4.jdk16.dao.IAccessor;
import com.trs.dev4.jdk16.model.BaseEntity;

/**
 * 构建 generatorSessionFactory 的 factory bean
 * 
 * @author yangyu
 * @since Jan 16, 2013 3:30:25 PM
 */
public class GeneratorSessionFactoryBean implements InitializingBean, FactoryBean<GeneratorSessionFactory>,
		ApplicationContextAware {

	protected static Logger LOG = Logger.getLogger(GeneratorSessionFactoryBean.class);

	private GeneratorSessionFactory generatorSessionFactory;

	private Properties generatorProperties;

	private SiteManager siteManager;

	private TemplateManager templateManager;

	private PageLinkManager pageLinkManager;

	private BaseurlExtractor baseurlExtractor;

	private Map<String, TagParser> customizeTagParsers;

	private Map<String, TagAware<? extends BaseEntity>> customizeTagAwares;

	private ApplicationContext applicationContext;

	public GeneratorSessionFactory getObject() throws Exception {
		return this.generatorSessionFactory;
	}

	public Class<?> getObjectType() {
		return (this.generatorSessionFactory != null) ? this.generatorSessionFactory.getClass()
				: GeneratorSessionFactory.class;
	}

	public boolean isSingleton() {
		return true;
	}

	public void afterPropertiesSet() throws Exception {

		SettingFactory settingFactory = new SettingFactory();
		Settings settings = initializeSettings(settingFactory);
		generatorSessionFactory = new GeneratorSessionFactoryImpl(settings);

	}

	/**
	 * @param settingFactory
	 * @return
	 * @since Administrator @ 2013-11-8
	 */
	private Settings initializeSettings(SettingFactory settingFactory) {
		Settings settings = new Settings();
		settings.setSiteManager(siteManager);
		settings.setPageLinkManager(pageLinkManager);
		settings.setTemplateManager(templateManager);
		settings.setBaseurlExtractor(baseurlExtractor);
		settingFactory.buildSettings(generatorProperties, settings);
		settings.getTagParsers().putAll(customizeTagParsers);
		loadAllTagAwareToSettings(settings);
		return settings;
	}

	/**
	 * 根据 Spring 中配置的所有的 IAccessor 构建所有的 TagAware 标签数据源对象.包括缓存 TagAware 和不缓存的TagAware ,最后设置到全局配置 Settings 中
	 * 
	 * @param settings
	 * @since Administrator @ 2013-11-8
	 */
	private void loadAllTagAwareToSettings(Settings settings) {

		Map<String, IAccessor> accessorBeans = applicationContext.getBeansOfType(IAccessor.class);

		Map<String, TagAware<? extends BaseEntity>> tagAwares = new HashMap<String, TagAware<? extends BaseEntity>>();
		Map<String, TagAware<?>> cacheableAwares = new HashMap<String, TagAware<?>>();
		Set<String> accessorBeanKeySet = accessorBeans.keySet();
		for (String accessorBeanKey : accessorBeanKeySet) {
			IAccessor accessor = accessorBeans.get(accessorBeanKey);
			String tagAwareName = accessor.getClassType().getSimpleName();
			if (customizeTagAwares.containsKey(tagAwareName)) {
				tagAwares.put(tagAwareName.toUpperCase(), new SqlTraceTagAware(customizeTagAwares.get(tagAwareName)));
				cacheableAwares.put(tagAwareName.toUpperCase(), new CacheableTagAware(customizeTagAwares
						.get(tagAwareName), settings));
			} else {
				tagAwares.put(tagAwareName.toUpperCase(), new SqlTraceTagAware(DefaultTagAware.newInstance(accessor)));
				cacheableAwares.put(tagAwareName.toUpperCase(), new CacheableTagAware(DefaultTagAware
						.newInstance(accessor), settings));
			}
		}

		settings.setTagAwares(tagAwares);
		settings.setCachableTagAwares(cacheableAwares);
	}

	public void setGeneratorProperties(Properties generatorProperties) {
		this.generatorProperties = generatorProperties;
	}

	public void setSiteManager(SiteManager siteManager) {
		this.siteManager = siteManager;
	}

	public void setTemplateManager(TemplateManager templateManager) {
		this.templateManager = templateManager;
	}

	public void setPageLinkManager(PageLinkManager pageLinkManager) {
		this.pageLinkManager = pageLinkManager;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	public void setBaseurlExtractor(BaseurlExtractor baseurlExtractor) {
		this.baseurlExtractor = baseurlExtractor;
	}

	public void setCustomizeTagParsers(Map<String, TagParser> customizeTagParsers) {
		this.customizeTagParsers = customizeTagParsers;
	}

	/**
	 * @param generatorSessionFactory
	 *            the {@link #generatorSessionFactory} to set
	 */
	public void setGeneratorSessionFactory(GeneratorSessionFactory generatorSessionFactory) {
		this.generatorSessionFactory = generatorSessionFactory;
	}

	/**
	 * @param customizeTagAwares
	 *            the {@link #customizeTagAwares} to set
	 */
	public void setCustomizeTagAwares(Map<String, TagAware<? extends BaseEntity>> customizeTagAwares) {
		this.customizeTagAwares = customizeTagAwares;
	}

}
