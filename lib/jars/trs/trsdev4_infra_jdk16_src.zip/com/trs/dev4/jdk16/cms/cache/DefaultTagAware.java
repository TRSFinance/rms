/*
 * Created: Administrator@2013-11-7 上午11:20:14
 */
package com.trs.dev4.jdk16.cms.cache;

import com.trs.dev4.jdk16.cms.TagAware;
import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.dao.IAccessor;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * 职责: <br>
 * 
 */
public class DefaultTagAware<T> implements TagAware<T> {
	
	private IAccessor<T> accessor;
	
	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getExtraProperty(com.trs.dev4.jdk16.cms.bo.PublishObject, java.lang.String,
	 *      com.trs.dev4.jdk16.cms.bo.TagContext)
	 * @since Administrator @ 2013-11-7
	 */
	@Override
	public Object getExtraProperty(PublishObject publishable, String key, TagContext tagContext) {
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getPublishObject(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since Administrator @ 2013-11-7
	 */
	@Override
	public T getPublishObject(SearchFilter searchFilter) {
		return accessor.findFirst(searchFilter);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getPublishObjectById(int)
	 * @since Administrator @ 2013-11-7
	 */
	@Override
	public T getPublishObjectById(int id) {
		return accessor.getObject(id);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getTagClass()
	 * @since Administrator @ 2013-11-7
	 */
	@Override
	public Class<T> getTagClass() {
		return accessor.getClassType();
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#objectCachedTime()
	 * @since Administrator @ 2013-11-7
	 */
	@Override
	public int objectCachedTime() {
		return 10;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#pagePublishObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since Administrator @ 2013-11-7
	 */
	@Override
	public PagedList<T> pagePublishObjects(SearchFilter searchFilter) {
		return accessor.pagedObjects(searchFilter);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#specialTagAttribute()
	 * @since Administrator @ 2013-11-7
	 */
	@Override
	public String[] specialTagAttribute() {
		return new String[] {};
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#total(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since Administrator @ 2013-11-7
	 */
	@Override
	public int total(SearchFilter sf) {
		return accessor.total(sf);
	}

	/**
	 * @param settings
	 * @param scaningClass
	 * @param accessor2
	 * @return
	 * @since Administrator @ 2013-11-7
	 */
	public static <T> TagAware<T> newInstance(IAccessor<T> accessor) {
		DefaultTagAware<T> defaultTagAware = new DefaultTagAware<T>();
		defaultTagAware.accessor = accessor;
		return defaultTagAware;
	}

}
