/*
 * updated: liushen @ Mar 17, 2009
 */
package com.trs.dev4.jdk16.dao.hb3;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.exception.DataException;
import org.hibernate.id.IdentifierGenerator;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.persister.entity.AbstractEntityPersister;
import org.hibernate.persister.entity.SingleTableEntityPersister;
import org.hibernate.tuple.entity.EntityMetamodel;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.trs.dev4.jdk16.dao.DBSummary;
import com.trs.dev4.jdk16.dao.DBSummaryUtil;
import com.trs.dev4.jdk16.dao.HQLBuilder;
import com.trs.dev4.jdk16.dao.HQLBuilder.Condition;
import com.trs.dev4.jdk16.dao.IAccessor;
import com.trs.dev4.jdk16.dao.MetricPagedList;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.exception.DAOException;
import com.trs.dev4.jdk16.exception.DataConstraintException;
import com.trs.dev4.jdk16.exception.DataInvalidException;
import com.trs.dev4.jdk16.exception.ExceptionUtil;
import com.trs.dev4.jdk16.model.BaseEntity;
import com.trs.dev4.jdk16.utils.AssertUtil;
import com.trs.dev4.jdk16.utils.CloseUtil;
import com.trs.dev4.jdk16.utils.CollectionUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 领域对象数据持久化基类.
 * 
 * @see com.trs.dev4.jdk16.dao.IAccessorTest
 */
public class GenericBaseDAO<T> extends HibernateDaoSupport implements
		IAccessor<T> {

	private final static Logger LOG = Logger.getLogger(GenericBaseDAO.class);

	/**
	 *
	 */
	public GenericBaseDAO(Class<T> classType) {
		this.classType = classType;
		if (LOG.isDebugEnabled()) {
			LOG.debug("ClassType(" + classType + ")DAO created,callers: " + ExceptionUtil.getMainCaller(5));
		}
	}

	/**
	 * 
	 */
	protected GenericBaseDAO() {
		if (LOG.isDebugEnabled()) {
			LOG.debug("no-argument constructor invoked, callers: " + ExceptionUtil.getMainCaller(5));
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#insert(java.lang.Object)
	 */
	@Override
	public Serializable insert(T object) throws DAOException {
		AssertUtil.notNull(object, "cannot insert null object!");

		Session session = null;
		Transaction tx = null;
		Serializable serialedId = null;
		QueryTimer timer = new QueryTimer(this.getClassType());
		try {
			session = getHibernateSession();
			tx = session.beginTransaction();
			serialedId = session.save(object);
			tx.commit();
			return serialedId;
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			Throwable rootCause = ExceptionUtil.calcRootCause(ex);
			if (rootCause == null) {
				rootCause = ex;
			}
			// 对于org.hibernate.exception.ConstraintViolationException，抛出DAOException的新子类;
			// 异常堆栈见http://dev4.trs.net.cn/pages/viewpage.action?pageId=337674267
			if (ex instanceof ConstraintViolationException) {
				throw new DataConstraintException(ex.getMessage() + " because " + rootCause.getMessage(), rootCause);
			}
			if (ex instanceof DataException) {
				throw new DataInvalidException(ex.getMessage() + " because " + rootCause.getMessage(), rootCause);
			}
			LOG.error("fail to save [" + object + "] because " + rootCause, ex);
			throw new DAOException("fail to save [" + object + "] because " + rootCause, rootCause);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(object, "insert");
		}

	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#delete(java.lang.Object)
	 */
	@Override
	public void delete(T object) throws DAOException {
		if (object == null) {
			throw new DAOException("cannot delete null object!");
		}
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Transaction tx = null;
		try {
			session = this.getHibernateSession();
			tx = session.beginTransaction();
			session.delete(object);
			tx.commit();
		} catch (Throwable e) {
			LOG.error("fail to delete [" + object + "]", e);
			Hb3Util.rollback(tx);
			throw new DAOException("fail to delete [" + object + "]", e);
		} finally {
			this.releaseHibernateSession(session);
			timer.stopWatch(object, "delete");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#update(java.lang.Object)
	 */
	@Override
	public void update(T object) throws DAOException {
		if (object == null) {
			throw new DAOException("cannot update null object!");
		}
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Transaction tx = null;
		try {
			session = getHibernateSession();
			tx = session.beginTransaction();
			session.saveOrUpdate(object);
			tx.commit();
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			Throwable rootCause = ExceptionUtil.calcRootCause(ex);
			LOG.error("fail to saveOrUpdate [" + object + "] because " + rootCause, ex);
			throw new DAOException("fail to saveOrUpdate [" + object + "] because " + rootCause, rootCause);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(object, "saveOrUpdate");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#getObject(java.lang.String)
	 */
	@Override
	public T getObject(int objectId) throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		try {
			return this.getHibernateTemplate().get(getClassType(),
					new Integer(objectId));
		} catch (Throwable ex) {
			LOG.error("fail to get " + getGenericClassName() + " (id= " + objectId + ")", ex);
			throw new DAOException("fail to get " + getGenericClassName() + " (id= " + objectId + ")", ex);
		} finally {
			timer.stopWatch(objectId);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#listObjects()
	 */
	@Override
	public List<T> listObjects() throws DAOException {
		// liushen@Feb 13, 2012: 设定上限，避免大数据量下内存溢出
		SearchFilter sf = SearchFilter.getNoPagedFilter();
		return listObjects(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#listObjects(java.lang.String,
	 *      java.lang.Object)
	 * @creator liushen @ Jan 25, 2010
	 */
	@Override
	public List<T> listObjects(String fieldName, Object value)
			throws DAOException {
		SearchFilter sf = SearchFilter.getNoPagedFilter();
		sf.addEqCondition(fieldName, value);
		return listObjects(sf);
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.dao.IAccessor#listObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@Override
	public List<T> listObjects(SearchFilter sf) throws DAOException {
		StringBuilder sb = buildFromAndWhere(sf);
		sb = appendOrderbyClause(sf, sb);
		final String whereExpression = sb.toString();
		return _getPageItems(whereExpression, sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#listSelectedFieldsObjects(com.trs.dev4.jdk16.dao.SearchFilter,
	 *      java.lang.String)
	 * @since js @ 2015年4月9日
	 */
	@Override
	public List<Object[]> listSelectedFieldsObjects(SearchFilter sf, String indicators, String tableEntityName)
			throws DAOException {
		StringBuilder sb = new StringBuilder(160);
		if (!StringHelper.isEmpty(indicators)) {
			sb.append("select ").append(indicators).append(" ");
		}
		sb.append("from ").append(tableEntityName);
		sb.append(sf.buildWhere());

		sb = appendOrderbyClause(sf, sb);
		final String whereExpression = sb.toString();

		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(whereExpression);
			HqlGenerator.bindParameters(query, sf);
			query.setFirstResult(sf.getStartPos());
			if (sf.getMaxResults() > 0) {
				query.setMaxResults(sf.getMaxResults());
			}
			@SuppressWarnings("unchecked")
			List<Object[]> list = query.list();
			// LOG.info("hibernate query: " + Hb3Util.getQueryInfoForDump(query)
			// + ", result size: " + list.size());
			timer.stopWatch(sf);
			return list;
		} catch (Throwable ex) {
			LOG.error("fail to query " + getGenericClassName() + " [" + sf + "]", ex);
			timer.stopWatch(sf, ex);
			if (ex instanceof DAOException) {
				throw (DAOException) ex;
			} else {
				throw new DAOException("fail to query " + getGenericClassName() + " [" + sf + "]", ex);
			}
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#listSelectedFieldsObjects(com.trs.dev4.jdk16.dao.SearchFilter,
	 *      java.lang.String)
	 * @since js @ 2015年4月13日
	 */
	@Override
	public List<Object[]> listSelectedFieldsObjects(SearchFilter sf, String indicators) throws DAOException {
		StringBuilder sb = buildFromAndWhere(sf, indicators);
		sb = appendOrderbyClause(sf, sb);
		final String whereExpression = sb.toString();

		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(whereExpression);
			HqlGenerator.bindParameters(query, sf);
			query.setFirstResult(sf.getStartPos());
			if (sf.getMaxResults() > 0) {
				query.setMaxResults(sf.getMaxResults());
			}
			@SuppressWarnings("unchecked")
			List<Object[]> list = query.list();
			// LOG.info("hibernate query: " + Hb3Util.getQueryInfoForDump(query)
			// + ", result size: " + list.size());
			timer.stopWatch(sf);
			return list;
		} catch (Throwable ex) {
			LOG.error("fail to query " + getGenericClassName() + " [" + sf + "]", ex);
			timer.stopWatch(sf, ex);
			if (ex instanceof DAOException) {
				throw (DAOException) ex;
			} else {
				throw new DAOException("fail to query " + getGenericClassName() + " [" + sf + "]", ex);
			}
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * @param whereExpression
	 * @param sf
	 * @return
	 * @since fangxiang @ Jan 8, 2011
	 */
	private List<T> _getPageItems(String whereExpression, SearchFilter sf) {
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(whereExpression);
			HqlGenerator.bindParameters(query, sf);
			query.setFirstResult(sf.getStartPos());
			if (sf.getMaxResults() > 0) {
				query.setMaxResults(sf.getMaxResults());
			}
			@SuppressWarnings("unchecked")
			List<T> list = query.list();
			// LOG.info("hibernate query: " + Hb3Util.getQueryInfoForDump(query)
			// + ", result size: " + list.size());
			timer.stopWatch(sf);
			return list;
		} catch (Throwable ex) {
			LOG.error("fail to query " + getGenericClassName() + " [" + sf + "]", ex);
			timer.stopWatch(sf, ex);
			if (ex instanceof DAOException) {
				throw (DAOException) ex;
			} else {
				throw new DAOException("fail to query " + getGenericClassName() + " [" + sf + "]", ex);
			}
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#pagedAll()
	 * @creator liushen @ Feb 15, 2010
	 */
	@Override
	public PagedList<T> pagedAll() throws DAOException {
		return pagedObjects(SearchFilter.getDefault());
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#pagedObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@Override
	public PagedList<T> pagedObjects(SearchFilter sf) throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		StringBuilder sb = buildFromAndWhere(sf);
		if (sf.isDebugMode()) {
			LOG.info("query count for " + getClassType() + " [" + sb + "]");
		}
		List<T> objs = null;
		int total = -1;
		try {
			total = total(sf);
			sb = appendOrderbyClause(sf, sb);
			objs = _getPageItems(sb.toString(), sf);
			if (sf.isDebugMode()) {
				LOG.info("query " + getClassType() + " [" + sb + "]");
			}

		} catch (DAOException ex) {
			throw ex;
		} catch (Throwable ex) {
			LOG.error("fail to query " + getGenericClassName() + " [" + sb + "]", ex);
			throw new DAOException("fail to query " + getGenericClassName() + " [" + sb + "]", ex);
		} finally {
			timer.stopWatch(sf);
		}

		return new MetricPagedList<T>(objs, sf.getStartPos() / sf.getMaxResults(), sf.getMaxResults(), total,
				timer.getTimeUsedMillis());
	}

	/**
	 * 在生成查询条件的HQL过程中，追加排序条件：如已设排序条件，则按设置加入HQL；如未设，则按ID倒排(仅对BaseEntity的子孙对象)。
	 * <b>要特别注意<b>：对于count查询以及group
	 * by/having等统计类HQL的执行过程，因为灵活多变，应自行酌情设置排序，不要调用本方法，以免造成错误。
	 * 
	 * @param sf
	 *            查询条件对象
	 * @param sb
	 *            传递保存生成的HQL（并同时返回）
	 */
	private StringBuilder appendOrderbyClause(SearchFilter sf, StringBuilder sb) {
		if (sf.hasSetOrderBy()) {
			sb.append(" order by ").append(sf.getOrderBy());
		} else {
			// liushen@2013-1-30: BaseEntity的子孙对象，如未设排序条件，则按ID倒排(For TRSMAS-1485)
			if (classType != null && BaseEntity.class.isAssignableFrom(classType)) { // see ClassTest.testAssignableFrom()
				sb.append(" order by ").append("id desc");
			}
		}
		return sb;
	}

	/**
	 * 构建from和where子句.
	 * 
	 */
	private StringBuilder buildFromAndWhere(SearchFilter sf) {
		return buildFromAndWhere(sf, null);
	}

	/**
	 * 构建from和where子句.
	 * 
	 */
	private StringBuilder buildFromAndWhere(SearchFilter sf, String selectFields) {
		StringBuilder sb = new StringBuilder(160);
		if (!StringHelper.isEmpty(selectFields)) {
			sb.append("select ").append(selectFields).append(" ");
		}
		sb.append("from ").append(this.getClassType().getName());
		sb.append(sf.buildWhere());
		return sb;
	}

	/**
	 * TODO liushen @ Apr 16, 2009: extract to {
	 * {@link HqlGenerator#bindParameters(Query, SearchFilter)} with same base!
	 *
	 * @param query
	 * @param parameters
	 * @creator fangxiang @ Mar 17, 2009
	 */
	static void bindParameters(Query query, List<Condition> parameters) {
		for (int i = 0; i < parameters.size(); i++) {
			Condition condition = parameters.get(i);
			try {
				// 支持HQLBuilder传入值为Object[]或Collection
				Object value = condition.getValue();
				if (value == null) {
					query.setParameter(condition.getParameterName(), value);
				} else {
					if (value.getClass().isArray()) {
						query.setParameterList(condition.getField(), (Object[]) value);
					} else if (Collection.class.isAssignableFrom(value.getClass())) {
						query.setParameterList(condition.getField(), (Collection<?>) value);
					} else {
						query.setParameter(condition.getParameterName(), value);
					}
				}
			} catch (org.hibernate.HibernateException e) {
				LOG.error("fail to bind parameters (" + condition + ") to query " + query + "!", e);
				throw e;
			}
		}
	}

	private String buildCountSQL(SearchFilter sf) {
		StringBuilder sCountExp = new StringBuilder(256);
		sCountExp.append("select count(*) ");
		sCountExp.append("from ").append(this.getClassType().getName());
		sCountExp.append(sf.buildWhere());
		return sCountExp.toString();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchInsert(java.util.List)
	 * @since liushen @ Jan 10, 2015
	 */
	@Override
	public int batchInsert(List<T> objects) throws DAOException {
		if (CollectionUtil.isEmpty(objects)) {
			return 0;
		}
		final int size = objects.size();
		int nAdded = 0;
		StatelessSession noStateSession = null;
		Transaction tx = null;
		QueryTimer timer = new QueryTimer(this.getClassType());
		try {
			// StatelessSession和批量处理可参见https://docs.jboss.org/hibernate/orm/3.3/reference/en/html/batch.html
			noStateSession = openStatelessSession();
			tx = noStateSession.beginTransaction();

			for (int i = 0; i < size; i++) {
				final T entity = objects.get(i);
				if (entity == null) {
					continue;
				}
				if (entity instanceof BaseEntity) {
					BaseEntity bo = (BaseEntity) entity;
					final long now = System.currentTimeMillis();
					if (bo.getCreatedTime() == 0) {
						bo.setCreatedTime(now);
					}
				}
				try {
					noStateSession.insert(entity);
					nAdded++;
				} catch (DataInvalidException e) {
					final Throwable rootCause = ExceptionUtil.calcRootCause(e);
					final String exInfo = ", ex: " + e + ((rootCause == null) ? "" : ", and rootCause: " + rootCause);
					LOG.error("invalid data for db, the entity(i=" + i + ", total=" + size + "): " + entity + exInfo);
				} catch (ConstraintViolationException e) {
					final Throwable rootCause = ExceptionUtil.calcRootCause(e);
					final String exInfo = ", ex: " + e + ((rootCause == null) ? "" : ", and rootCause: " + rootCause);
					LOG.error("fail to insert the entity(i=" + i + ", total=" + size + "): " + entity + exInfo);
				}
			}

			tx.commit();
			return nAdded;
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			final Throwable rootCause = ExceptionUtil.calcRootCause(ex);
			LOG.error("fail to batchInsert " + size + "[" + getClassType() + "] because " + rootCause, ex);
			throw new DAOException("fail to batchInsert [" + getClassType() + "]", rootCause);
		} finally {
			releaseStatelessSession(noStateSession);
			timer.stopWatch(objects.get(0), "batchInsert");
		}
	}

	/**
	 * @return
	 * @since liushen @ Apr 29, 2015
	 */
	StatelessSession openStatelessSession() {
		return getSessionFactory().openStatelessSession();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchInsert(T[])
	 */
	@Override
	public int batchInsert(T[] objects) throws DAOException {
		if (objects == null) {
			return -1;
		}
		int nAdded = 0;
		final int total = objects.length;
		for (int i = 0; i < total; i++) {
			// 跳过null对象
			if (objects[i] == null) {
				continue;
			}
			if (objects[i] instanceof BaseEntity) {
				BaseEntity bo = (BaseEntity) objects[i];
				final long now = System.currentTimeMillis();
				if (bo.getCreatedTime() == 0) {
					bo.setCreatedTime(now);
				}
			}
			try {
				this.getHibernateTemplate().save(objects[i]);
				nAdded++;
			} catch (Throwable e) {
				throw new DAOException("fail to batchInsert " + i + " of " + total + ": " + objects[i], e);
			}
		}
		return nAdded;
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#createIndex(java.lang.String)
	 */
	@Override
	public int createIndex(String sql) throws DAOException {
		if (StringHelper.isEmpty(sql)) {
			return -1;
		}
		final String lowerCaseSQL = sql.trim().toLowerCase();
		if (false == StringHelper.startsWith(lowerCaseSQL, "create index ", "create unique index ")) {
			return -1;
		}
		Connection conn = null;
		Statement stmt = null;
		StatelessSession noStateSession = null;
		QueryTimer timer = new QueryTimer(this.getClassType());
		try {
			noStateSession = openStatelessSession();
			conn = noStateSession.connection();
			try {
				stmt = conn.createStatement();
				int affectedRows = stmt.executeUpdate(sql);
				LOG.info("OK: " + sql + ", and jdbc return(DML affectedRows)=" + affectedRows);
				return affectedRows;
			} catch (SQLException e) {
				LOG.error("fail to create index because " + e + ", sql=" + sql);
				return -2;
			}
		} catch (Throwable ex) {
			Throwable rootCause = ExceptionUtil.calcRootCause(ex);
			if (rootCause == null) {
				rootCause = ex;
			}
			LOG.error("fail to create index :" + sql + " because " + rootCause, ex);
			throw new DAOException("fail to executeUpdate " + sql, rootCause);
		} finally {
			CloseUtil.closeStatement(stmt);
			CloseUtil.close(conn);
			releaseStatelessSession(noStateSession);
			timer.stopWatch(sql);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchUpdate(com.trs.dev4.jdk16.dao.HQLBuilder)
	 */
	@Override
	public int batchUpdate(HQLBuilder builder) throws DAOException {
		return batchWithBuilder(builder);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchDelete(com.trs.dev4.jdk16.dao.HQLBuilder)
	 */
	@Override
	public int batchDelete(HQLBuilder builder) throws DAOException {
		return batchWithBuilder(builder);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#delete(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@Override
	public int delete(SearchFilter searchFilter) {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		StringBuilder sb = new StringBuilder("delete ");
		sb.append(buildFromAndWhere(searchFilter));
		Session session = null;
		Transaction tx = null;
		int count;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(sb.toString());
			HqlGenerator.bindParameters(query, searchFilter);
			tx = session.beginTransaction();
			count = query.executeUpdate();
			tx.commit();
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			throw new DAOException("fail to execute [" + sb + "]", ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(searchFilter);
		}

		return count;
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#executeNativeUpdateSQL(java.lang.String)
	 */
	@Override
	public int executeNativeUpdateSQL(String sql) {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		Session session = null;
		Transaction tx = null;
		int result = 0;
		try {
			session = getHibernateSession();
			tx = session.beginTransaction();
			result = session.createSQLQuery(sql).executeUpdate();
			tx.commit();
			return result;
		} catch (HibernateException e) {
			tx.rollback();
			LOG.error("fail to executeNativeUpdateSQL [" + sql + "], and rollbacked.", e);
			throw new DAOException("fail to executeNativeUpdateSQL", e);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(sql);
		}
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.dao.IAccessor#executeNativeQuerySQL(java.lang.String, int, int)
	 * @since zoumei @ 2013-5-13
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<? extends Object> executeNativeQuerySQL(String sql, int startPos, int maxResult) throws DAOException {
		if (startPos < 0) {
			startPos = 0;
		}
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		try {
			session = getHibernateSession();
			SQLQuery query = session.createSQLQuery(sql);
			if (maxResult > 0) {
				query.setMaxResults(maxResult);
				query.setFirstResult(startPos);
			}
			return query.list();
		} catch (Throwable ex) {
			LOG.error("fail to executeNativeQuerySQL [" + sql + "], startPos=" + startPos + ", maxResult=" + maxResult,
					ex);
			throw new DAOException("fail to executeNativeQuerySQL", ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(sql);
		}
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.dao.IAccessor#executeNativeQuerySQL(java.lang.String)
	 * @since zoumei @ 2013-5-13
	 */
	@Override
	public List<? extends Object> executeNativeQuerySQL(String sql) throws DAOException {
		return executeNativeQuerySQL(sql, 0, -1);
	}

	/**
	 * @param builder
	 * @return
	 */
	private int batchWithBuilder(HQLBuilder builder) {
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Transaction tx = null;
		int count;
		String preparedHQL = "";
		try {
			session = getHibernateSession();
			preparedHQL = builder.getPreparedHQL();
			Query query = session.createQuery(preparedHQL);
			bindParameters(query, builder.getParameterValues());
			if (LOG.isDebugEnabled()) {
				LOG.debug("query: " + query.getQueryString() + "; params: "
						+ Arrays.toString(query.getNamedParameters())
						+ ", called by " + ExceptionUtil.getMainCaller());
			}
			tx = session.beginTransaction();
			count = query.executeUpdate();
			tx.commit();
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(preparedHQL);
		}

		return count;
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.dao.IAccessor#exists(java.lang.String,
	 *      java.lang.Object)
	 */
	@Override
	public boolean exists(String field, Object value) throws DAOException {
		return exists(field, value, -1);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#findFirst(java.lang.String,
	 *      java.lang.Object)
	 * @since liushen @ Apr 22, 2010
	 */
	@Override
	public T findFirst(String field, Object value) throws DAOException {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition(field, value);
		return findFirst(sf);
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.dao.IAccessor#exists(java.lang.String,
	 *      java.lang.Object, int)
	 */
	@Override
	public boolean exists(String field, Object value, int excludedId)
			throws DAOException {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition(field, value);
		sf.addNotEqCondition("id", new Integer(excludedId));
		return (total(sf) != 0);
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.dao.IAccessor#total()
	 */
	@Override
	public int total() throws DAOException {
		Session session = null;
		try {
			session = getHibernateSession();
			Query countQry = session.createQuery("select count(*) from "
					+ getClassType().getName());
			return Hb3Util.uniqueResultAsInt(countQry);
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#total(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@Override
	public int total(SearchFilter sf) {
		Session session = getHibernateSession();
		try {
			String countHQL = buildCountSQL(sf);
			Query countQry = session.createQuery(countHQL);
			HqlGenerator.bindParameters(countQry, sf);
			return Hb3Util.uniqueResultAsInt(countQry);
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * HQL目前不能支持update ClassA set fieldX=fieldX+delta这种形式, 因此通过update table XX
	 * set fieldX=fieldX+delta这类SQL语句实现.
	 * 
	 * @see com.trs.dev4.jdk16.dao.IAccessor#deltaUpdate(java.lang.String, long,
	 *      int)
	 * @since liushen @ Apr 29, 2010
	 */
	@Override
	public int deltaUpdate(String field, long delta, int whichId) {
		if (delta == 0) {
			return 0;
		}
		// 构造+X还是-X
		String deltaExpression = (delta > 0) ? field + "+" + delta : field
				+ delta;
		// 拼SQL语句
		StringBuilder sb = new StringBuilder();
		sb.append("update ").append(getTableName()).append(" set ").append(
				field).append("=").append(deltaExpression);
		sb.append(" where ").append(getIdFieldName()).append("=").append(
				whichId);

		return executeNativeUpdateSQL(sb.toString());
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#getgetClassType()()
	 */
	@Override
	public Class<T> getClassType() {
		return this.classType;
	}

	/**
	 * 获取该DAO管理的实际的领域对象的类名（也就是注入的泛型的实际型别）。
	 * 
	 * @since liushen @ Aug 2, 2013
	 */
	String getGenericClassName() {
		Class<T> clazz = getClassType();
		return (clazz == null) ? "Unknown" : clazz.getName();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#getTableName()
	 * @since liushen @ Apr 29, 2010
	 */
	@Override
	public String getTableName() {
		ClassMetadata metadata = getHibernateClassMetadata();
		if (metadata instanceof SingleTableEntityPersister) {
			return ((SingleTableEntityPersister) metadata).getTableName();
		}
		throw new DAOException("ClassMetadata of " + getGenericClassName()
				+ " is not a SingleTableEntityPersister, it's " + metadata);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#getIdFieldName()
	 * @since liushen @ Apr 29, 2010
	 */
	@Override
	public String getIdFieldName() {
		ClassMetadata metadata = getHibernateClassMetadata();
		return metadata.getIdentifierPropertyName();
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.dao.IAccessor#retriveDBSummary()
	 * @creator liushen @ Jun 1, 2009
	 */
	@SuppressWarnings("deprecation")
	@Override
	public DBSummary retriveDBSummary() {
		Session session = null;
		try {
			session = getHibernateSession();
			Connection conn = session.connection();
			return DBSummaryUtil.retriveSummary(conn);
		} catch (Throwable ex) {
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * @param session
	 * @throws HibernateException
	 */
	protected void releaseHibernateSession(Session session)
			throws HibernateException {
		if (session != null) {
			try {
				session.close();
			} catch (Throwable e) {
				LOG.error("fail to close session", e);
				throw new HibernateException(e.getMessage(), e);
			}
		}
	}

	protected void releaseStatelessSession(StatelessSession noStateSession) throws HibernateException {
		if (noStateSession != null) {
			try {
				noStateSession.close();
			} catch (Throwable e) {
				LOG.warn("fail to close StatelessSession, ignored: " + noStateSession, e);
			}
		}
	}

	/**
	 * @return
	 * @throws HibernateException
	 */
	protected Session getHibernateSession() throws HibernateException {
		return this.getSessionFactory().openSession();
	}

	// 以下为hibernate相关的方法，仅供诊断使用；接口中并没有这些方法的定义！
	/**
	 *
	 * @return
	 * @since liushen @ Mar 22, 2010
	 */
	public Map<String, ClassMetadata> getAllEntityClassMetadata() {
		SessionFactory sessionFactory = getSessionFactory();
		return Hb3Util.getAllEntityClassMetadata(sessionFactory);
	}

	/**
	 *
	 * @return
	 * @since liushen @ Jun 23, 2010
	 */
	public IdentifierGenerator getHibernateIdGenerator() {
		SessionFactory sessionFactory = getSessionFactory();
		return Hb3Util.getIdGenerator(sessionFactory, getClassType().getName());
	}

	/**
	 * @return
	 * @since liushen @ Apr 29, 2010
	 */
	ClassMetadata getHibernateClassMetadata() {
		Map<String, ClassMetadata> maps = getAllEntityClassMetadata();
		ClassMetadata metadata = maps.get(getClassType().getName());
		AssertUtil.notNull(metadata, "ClassMetadata of " + getClassType()
				+ " not exist.");
		return metadata;
	}

	/**
	 *
	 * @return
	 * @since liushen @ Jun 23, 2010
	 */
	EntityMetamodel getHibernateEntityMetamodel() {
		ClassMetadata metadata = getHibernateClassMetadata();
		if (false == metadata instanceof AbstractEntityPersister) {
			throw new DAOException("not a AbstractEntityPersister!");
		}
		AbstractEntityPersister persister = (AbstractEntityPersister) metadata;
		return persister.getEntityMetamodel();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#executeNativeUpdateSQL(java.lang.String[])
	 * @since fangxiang @ Jul 1, 2010
	 */
	@Override
	public int executeNativeUpdateSQL(String[] statements) {
		Session session = null;
		Transaction tx = null;
		int result = 0;
		try {
			session = getHibernateSession();
			tx = session.beginTransaction();
			for (int i = 0; i < statements.length; i++) {
				result += session.createSQLQuery(statements[i]).executeUpdate();
			}
			tx.commit();
			return result;
		} catch (HibernateException e) {
			tx.rollback();
			throw new DAOException(e);
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * 领域对象类型.
	 */
	private Class<T> classType;

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Jul 26, 2010
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString()).append(" (T=");
		builder.append(getClassType().getName());
		builder.append(")");
		return builder.toString();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchDelete(T[])
	 * @since fangxiang @ Nov 16, 2010
	 */
	@Override
	public void batchDelete(T[] objects) throws DAOException {
		if (objects == null) {
			throw new DAOException("cannot delete null object!");
		}
		QueryTimer timer = new QueryTimer(this.getClassType());
		try {

			this.getHibernateTemplate().deleteAll(Arrays.asList(objects));
		} catch (Throwable ex) {
			LOG.error("fail on getHibernateTemplate().deleteAll, total objects: " + objects.length, ex);
			throw new DAOException(ex);
		} finally {
			timer.stopWatch(objects, "delete");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchUpdate(T[])
	 * @since fangxiang @ Nov 16, 2010
	 */
	@Override
	public void batchUpdate(T[] objects) throws DAOException {
		this.batchUpdate(Arrays.asList(objects));
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchUpdate(java.util.List)
	 */
	@Override
	public void batchUpdate(List<T> objects) throws DAOException {
		if (objects == null) {
			throw new DAOException("cannot update null object!");
		}
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Transaction tx = null;
		try {
			session = getHibernateSession();
			tx = session.beginTransaction();
			for (T entity : objects) {
				session.saveOrUpdate(entity);
			}
			session.flush();
			session.clear();
			tx.commit();
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			LOG.error("fail to batchUpdate, total objects: " + objects.size(), ex);
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(objects, "batchUpdate");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#truncate()
	 * @throws DAOException
	 * @since fangxiang @ Nov 16, 2010
	 */
	@Override
	public int truncate() throws DAOException {
		return executeNativeUpdateSQL("TRUNCATE TABLE " + getTableName());
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.IAccesor#findUnique(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public T findUnique(SearchFilter sf) {
		if (sf == null) {
			sf = SearchFilter.getDefault();
		}
		PagedList<T> entities = this.pagedObjects(sf);
		if (entities.getPageItems().size() > 1) {
			throw new DAOException("not unique " + getGenericClassName() + ", sf: " + sf);
		}
		return (entities.getPageItems().size() > 0) ? entities.get(0) : null;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.IAccesor#findFirst(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public T findFirst(SearchFilter sf) {
		if (sf == null) {
			sf = SearchFilter.getDefault();
		}
		sf.setMaxResults(1);
		List<T> objs = this.listObjects(sf);
		return (objs.size() > 0) ? objs.get(0) : null;
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#pagedObjectIds(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Jan 8, 2011
	 */
	@SuppressWarnings("unchecked")
	@Override
	public PagedList<Integer> pagedObjectIds(SearchFilter sf)
			throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		StringBuilder sb = buildFromAndWhere(sf, "id");
		try {
			int total = total(sf);
			sb = appendOrderbyClause(sf, sb);
			List<Integer> objects = (List<Integer>) _getPageItems(
					sb.toString(), sf);
			return new PagedList<Integer>(objects,
					sf.getStartPos()
					/ sf.getMaxResults(), sf.getMaxResults(), total);
		} catch (DAOException ex) {
			LOG.error("query failed: [" + sb + "]", ex);
			throw ex;
		} catch (Throwable ex) {
			LOG.error("query failed: [" + sb + "]", ex);
			throw new DAOException(ex);
		} finally {
			timer.stopWatch(sf);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#update(int, java.util.Map)
	 * @since liushen @ Dec 2, 2011
	 */
	@Override
	public int update(int id, Map<String, Object> updatedFields) {
		if (CollectionUtil.isEmpty(updatedFields)) {
			// AssertUtil.notNullOrEmpty(objs, message)
			return 0;
		}
		HQLBuilder hqlBuilder = HQLBuilder.UPDATE(classType);
		for (String field : updatedFields.keySet()) {
			hqlBuilder.setNewValue(field, updatedFields.get(field));
		}
		hqlBuilder.addEqCondition("id", id);
		return batchWithBuilder(hqlBuilder);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#update(int, java.lang.String,
	 *      java.lang.Object)
	 * @since liushen @ Dec 2, 2011
	 */
	@Override
	public int update(int id, String field, Object value) {
		Map<String, Object> updatedFields = new HashMap<String, Object>();
		updatedFields.put(field, value);
		return update(id, updatedFields);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#executeQuery(java.lang.String)
	 * @creator liushen @ May 5, 2009
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<? extends Object> executeQuery(String hql) throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(hql);
			return query.list();
		} catch (Throwable ex) {
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(hql);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#executeQuery(java.lang.String, int)
	 * @since zhangshi @ 2012-6-28
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<? extends Object> executeQuery(String hql, int startPos, int maxResult) throws DAOException {
		if (false == (maxResult > 0)) {
			return executeQuery(hql);
		}
		if (startPos < 0) {
			startPos = 0;
		}
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(hql);
			query.setMaxResults(maxResult);
			query.setFirstResult(startPos);
			return query.list();
		} catch (Throwable ex) {
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(hql);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#uniqueResultAsInt(java.lang.String)
	 * @since liushen @ Oct 15, 2013
	 */
	@Override
	public int uniqueResultAsInt(String hql) throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Object obj = null;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(hql);
			obj = query.uniqueResult();
			if (obj == null) {
				return 0;
			}
			if (obj instanceof Number) {
				return ((Number) obj).intValue();
			}
		} catch (Throwable ex) {
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(hql);
		}
		LOG.error("result of hql[" + hql + "] not an integer: " + obj);
		throw new DAOException("不是整数: " + obj);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#uniqueResultAsLongBySql(java.lang.String)
	 */
	@Override
	public long uniqueResultAsLongBySql(String sql) throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		try {
			session = getHibernateSession();
			SQLQuery query = session.createSQLQuery(sql);
			return Hb3Util.uniqueResultAsLong(query);

		} catch (Throwable ex) {
			LOG.error("fail to uniqueResultAsLongBySql: [" + sql + "]" + ex);
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(sql);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#uniqueResultAsLong(java.lang.String)
	 * @since yirongyi @ 2014年10月11日
	 */
	@Override
	public long uniqueResultAsLong(String hql) throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Object obj = null;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(hql);
			obj = query.uniqueResult();
			if (obj == null) {
				return 0;
			}
			if (obj instanceof Number) {
				return ((Number) obj).longValue();
			}
		} catch (Throwable ex) {
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(hql);
		}
		LOG.error("result of hql[" + hql + "] not an long: " + obj);
		throw new DAOException("不是long型: " + obj);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#uniqueResultAsFloat(java.lang.String)
	 * @since yirongyi @ 2015年6月19日
	 */
	@Override
	public Float uniqueResultAsFloat(String hql) throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Object obj = null;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(hql);
			obj = query.uniqueResult();
			if (obj == null) {
				return 0f;
			}
			if (obj instanceof Number) {
				return ((Number) obj).floatValue();
			}
		} catch (Throwable ex) {
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(hql);
		}
		LOG.error("result of hql[" + hql + "] not an float: " + obj);
		throw new DAOException("不是float型: " + obj);
	}

	/**
	 * 仅供单元测试用，用纯JDBC操作以对比分析truncate语句的返回值。
	 * 
	 * @return
	 * @since liushen @ Sep 21, 2012
	 */
	Connection openConnection() {
		return openStatelessSession().connection();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#bulkUpdate(java.lang.String,
	 *      java.lang.Object, java.lang.Object)
	 * @since xuyan @ 2012-9-29
	 */
	@Override
	public int bulkUpdate(String field, Object oldValue, Object newValue) {
		HQLBuilder hqlBuilder = HQLBuilder.UPDATE(classType);
		hqlBuilder.setNewValue(field, newValue).addEqCondition(field, oldValue);
		return batchUpdate(hqlBuilder);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#bulkUpdate(java.lang.String, java.lang.Object[])
	 * @since liushen @ Jan 7, 2015
	 */
	@Override
	public int bulkUpdate(String hql, Object... values) {
		// QueryTimer timer = new QueryTimer(this.getClassType());
		try {
			return this.getHibernateTemplate().bulkUpdate(hql, values);
		} catch (Throwable ex) {
			LOG.error(
					"fail on HibernateTemplate.bulkUpdate, hql: " + hql + ", bindParameters: "
							+ StringHelper.toString(values), ex);
			throw new DAOException(ex);
			// } finally {
			// timer.stopWatch(objects, "bulkUpdate");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#byMaxId()
	 * @since liushen @ Apr 29, 2015
	 */
	@Override
	public T byMaxId() {
		SearchFilter sf = SearchFilter.getDefault();
		sf.setOrderBy("id desc");
		return findFirst(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#byMinId()
	 * @since liushen @ Apr 29, 2015
	 */
	@Override
	public T byMinId() {
		SearchFilter sf = SearchFilter.getDefault();
		sf.setOrderBy("id asc");
		return findFirst(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#countByIdMaxToMin()
	 * @since liushen @ Apr 29, 2015
	 */
	@Override
	public long countByIdMaxToMin() {
		@SuppressWarnings("unchecked")
		final List<Object[]> list = (List<Object[]>) executeQuery("select max(id), min(id) from "
				+ getGenericClassName());
		if (list.size() < 1) {
			return -2;
		}
		Object[] row = list.get(0);
		if (row[0] == null) {
			return -1;
		}
		final long max = ((Number) row[0]).longValue();
		final long min = ((Number) row[1]).longValue();
		return max - min + 1;
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#max(String)
	 * @since liushen @ Apr 29, 2015
	 */
	@Override
	public long max(String fieldName) {
		StringBuilder sb = new StringBuilder(48);
		sb.append("select max(").append(fieldName).append(") from ");
		sb.append(getGenericClassName());
		return uniqueResultAsLong(sb.toString());
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#min(String)
	 * @since liushen @ Apr 29, 2015
	 */
	@Override
	public long min(String fieldName) {
		StringBuilder sb = new StringBuilder(48);
		sb.append("select min(").append(fieldName).append(") from ");
		sb.append(getGenericClassName());
		return uniqueResultAsLong(sb.toString());
	}

}
