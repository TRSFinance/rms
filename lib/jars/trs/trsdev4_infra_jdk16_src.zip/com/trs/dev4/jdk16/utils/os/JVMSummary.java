/*
 * Created: liushen@May 30, 2009 2:41:57 PM
 */
package com.trs.dev4.jdk16.utils.os;

import java.lang.management.OperatingSystemMXBean;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.exec.CommandExecUtil;
import com.trs.dev4.jdk16.exec.ExecuteResult;
import com.trs.dev4.jdk16.utils.EnvConst;
import com.trs.dev4.jdk16.utils.JMXUtil;
import com.trs.dev4.jdk16.utils.NetUtil;
import com.trs.dev4.jdk16.utils.NumberUtil;
import com.trs.dev4.jdk16.utils.SortedProperties;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * JVM主要信息.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class JVMSummary {

	private static final Logger LOG = Logger.getLogger(JVMSummary.class);

	/**
	 * @since liushen @ Feb 10, 2011
	 */
	public static final String UNKNOWN = "unknown";

	/**
	 * Java运行环境的厂商名称.
	 */
	private String jreVendor;

	/**
	 * Java运行环境的版本.
	 */
	private String jreVersion;

	/**
	 * JavaHome目录.
	 */
	private String homeDir;
	
	/**
	 * 
	 */
	private String vmVendor;
	
	/**
	 * 
	 */
	private String vmName;
	
	/**
	 * 
	 */
	private String vmInfo;

	/**
	 * 
	 */
	private String jniLibraryPath;

	/**
	 * JVM临时目录.
	 */
	private String tmpDir;

	/**
	 * 操作系统名称.
	 */
	private String osName;

	/**
	 * 操作系统版本.
	 */
	private String osVersion;

	/**
	 * JVM的架构位数(如x86、i386、x86_64等); 但并不能代表操作系统的位数.
	 */
	private String jvmArch;

	/**
	 * 程序运行用户.
	 */
	private String userName;

	/**
	 * 程序运行目录.
	 */
	private String workingDir;

	/**
	 * 程序运行用户的主目录.
	 */
	private String userHome;

	/**
	 * 默认字符编码.
	 */
	private String defEncoding;

	/**
	 * 对JVM可见的CPU数.
	 */
	private int availableProcessors;

	/**
	 * 操作系统的物理内存.
	 */
	private long osPhysicalMemory;

	/**
	 * 操作系统更新包的版本.
	 */
	private String osPackVersion;

	/**
	 * 该JVM进程的启动时刻.
	 */
	private long startTime;

	/**
	 * 该JVM所在机器的主机名.
	 */
	private String hostname;

	/**
	 * 该JVM所在机器的IP.
	 */
	private String ip;

	/**
	 * Linux发行版信息.
	 */
	private String linuxDistributionInfo;

	/**
	 * CPU类型.
	 */
	private String processorType;

	private int maxOpenFile;

	/**
	 * 
	 */
	public JVMSummary() {
		try {
			reinit();
		} catch (Exception e) {
			LOG.warn("failed to retrive some info because Not Sun/Oracle/IBM JDK, can ignore", e);
		}
	}

	/**
	 * 重新获取JVM各项信息。
	 * 
	 * @creator liushen @ May 30, 2009
	 */
	private void reinit() {
		reinitProperties();
		
		hostname = NetUtil.getLocalHostName();
		ip = NetUtil.getLocalHostIP();
		
		availableProcessors = Runtime.getRuntime().availableProcessors();
		
		if (false == EnvConst.isWindows()) {
			try {
				maxOpenFile = (int) JMXUtil.getAttrAsLong(
						"java.lang:type=OperatingSystem",
						"MaxFileDescriptorCount");
			} catch (Throwable e) {
				LOG.warn("failed to retrive maxOpenFile, because " + e);
			}
		}

		startTime = JMXUtil.getAttrAsLong("java.lang:type=Runtime",
				"StartTime");
		try {
			osPhysicalMemory = JMXUtil.getAttrAsLong("java.lang:type=OperatingSystem", "TotalPhysicalMemorySize");
		} catch (Exception e) {
			// TRSMAS-2310 IBM JDK上，此属性名为TotalPhysicalMemory
			try {
				osPhysicalMemory = JMXUtil.getAttrAsLong("java.lang:type=OperatingSystem", "TotalPhysicalMemory");
			} catch (Exception e1) {
				LOG.warn("neither Sun/Oracle JRE, nor IBM JRE, so not found TotalPhysicalMemory by JMX, skiped(" + e1
						+ ")");
			}
		}
	}

	/**
	 * 获取内存状态信息.
	 * 
	 * @since liushen @ May 30, 2009
	 */
	public JVMMemoryStatus getCurrentJVMMemoryStatus() {
		return new JVMMemoryStatus();
	}

	/**
	 * 获取CPU占用率. 以下说明来自 {@link OperatingSystemMXBean#getSystemLoadAverage()}： Returns the system load average for the
	 * last minute. The system load average is the sum of the number of runnable entities queued to the available
	 * processors and the number of runnable entities running on the available processors averaged over a period of
	 * time. The way in which the load average is calculated is operating system specific but is typically a damped
	 * time-dependent average.
	 * 
	 * If the load average is not available, a negative value is returned.
	 * 
	 * This method is designed to provide a hint about the system load and may be queried frequently. The load average
	 * may be unavailable on some platform where it is expensive to implement this method.
	 * 
	 * @since liushen @ Jun 4, 2009
	 */
	public double getCurrentSystemLoadAverage() {
		// 在Windows上没有实现，总是返回-1.0; 原因见:
		// http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=6336608
		double sysLoad = JMXUtil.getAttrAsDouble("java.lang:type=OperatingSystem",
				"SystemLoadAverage");
		return NumberUtil.roundHalfUp(sysLoad, 3);
	}

	/**
	 * 获取友好显示的操作系统概要信息, 格式：名称(CPU架构) 版本号 (Linux发行版信息) 补丁
	 * 
	 * @since liushen @ Feb 10, 2011
	 */
	public String getOSInfo() {
		String result = osName;
		if (false == StringHelper.isEmpty(processorType)) {
			result += "(" + processorType + ")";
		}
		if (false == StringHelper.isEmpty(linuxDistributionInfo)) {
			result += " (" + linuxDistributionInfo + ")";
		}
		result += "; " + osVersion;
		if (false == StringHelper.isEmpty(osPackVersion)
				&& false == UNKNOWN.equals(osPackVersion)) {
			result += " " + osPackVersion;
		}
		return result;
	}

	/**
	 * 获取友好显示的JVM概要信息.
	 * 
	 * @since liushen @ Feb 10, 2011
	 */
	public String getJVMInfo() {
		return jreVersion + " (" + jvmArch + ")";
	}

	private void reinitProperties() {
		Properties props = System.getProperties();
		
		jreVendor = props.getProperty("java.vendor");
		jreVersion = props.getProperty("java.version");
		homeDir = props.getProperty("java.home");
		tmpDir = props.getProperty("java.io.tmpdir");
		jniLibraryPath = props.getProperty("java.library.path");
		vmName = props.getProperty("java.vm.name");
		vmInfo = props.getProperty("java.vm.info");
		vmVendor = props.getProperty("java.vm.vendor");
		
		osName = props.getProperty("os.name");
		jvmArch = props.getProperty("os.arch");
		osVersion = props.getProperty("os.version");
		guessLinuxDistribution();
		if (false == EnvConst.isWindows()) {
			processorType = retrieveStdoutIfProcessSuccess("uname -p");
		}
		
		userName = props.getProperty("user.name");
		userHome = props.getProperty("user.home");
		workingDir = props.getProperty("user.dir");
		
		defEncoding = props.getProperty("file.encoding");
		osPackVersion = props.getProperty("sun.os.patch.level");
	}

	/**
	 * 
	 * @since liushen @ Feb 10, 2011
	 */
	void guessLinuxDistribution() {
		if (EnvConst.isLinux()) {
			try {
				LinuxLSBRelease lsbRelease = LinuxLSBRelease.realtimeGet();
				linuxDistributionInfo = lsbRelease.getDistributorID() + " " + lsbRelease.getRelease() + " ("
						+ lsbRelease.getCodename() + ")";
				return;
			} catch (Exception e) {
				LOG.warn("fail to call lsb_release, so guess with xxx-release file instead.", e);
				linuxDistributionInfo = retrieveStdoutIfProcessSuccess(linuxDistrubInfoCmds());
			}
		}
	}

	/**
	 * 
	 * @param list
	 * @since liushen @ Feb 10, 2011
	 */
	static String retrieveStdoutIfProcessSuccess(List<String> list) {
		for (Iterator<String> iterator = list.iterator(); iterator.hasNext();) {
			String cmd = iterator.next();
			ExecuteResult cmdResult = CommandExecUtil.executeCommand(cmd);
			if (cmdResult.getExitValue() == 0) {
				return cmdResult.firstLinesOfStdout(0);
			}
		}

		return null;
	}

	/**
	 * 
	 * @param cmds
	 * @return
	 * @since liushen @ Feb 10, 2011
	 */
	static String retrieveStdoutIfProcessSuccess(String... cmds) {
		for (String cmd : cmds) {
			ExecuteResult cmdResult = CommandExecUtil.executeCommand(cmd);
			if (cmdResult.getExitValue() == 0) {
				return cmdResult.firstLinesOfStdout(0);
			}
		}

		return null;
	}

	static List<String> linuxDistrubInfoCmds() {
		List<String> patterns = new ArrayList<String>();
		patterns.add("cat /etc/redhat-release");
		patterns.add("cat /etc/redflag-release");
		patterns.add("cat /etc/asianux-release");
		return patterns;
	}

	/**
	 * 
	 * @return
	 * @creator liushen @ Sep 3, 2009
	 */
	public String getJVMInputArguments() {
		return JMXUtil.getJVMInputArguments();
	}

	/**
	 * @return
	 * @creator liushen @ Jun 5, 2009
	 */
	public Properties getSortedSystemProperties() {
		return new SortedProperties(System.getProperties());
	}

	/**
	 * 以友好可读的方式返回物理内存，比如：512MB、8GB、7.9GB等。
	 * 
	 * @since liushen @ Oct 30, 2014
	 */
	public String getOsPhysicalMemoryFriendly() {
		if (osPhysicalMemory <= 0) {
			return "N/A(" + osPhysicalMemory + ")";
		}
		final long GIGA = 1048576 * 1024;
		if (osPhysicalMemory >= GIGA) {
			if (osPhysicalMemory % GIGA == 0) {
				return (osPhysicalMemory / GIGA) + "GB";
			} else {
				return NumberUtil.dividedAndHalfUp(osPhysicalMemory, GIGA, 1) + "GB";
			}
		} else {
			return (osPhysicalMemory / 1048576) + "MB";
		}
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Feb 18, 2014
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(super.toString()).append(" JVM: ").append(getJVMInfo());
		sb.append("; OS: ").append(getOSInfo());
		sb.append("; CPU Cores=").append(getAvailableProcessors());
		sb.append("; JVM encoding=").append(getDefEncoding());
		sb.append(", JVM Params=").append(getJVMInputArguments());
		return sb.toString();
	}

	/**
	 * Get the {@link #jreVendor}.
	 * 
	 * @return the {@link #jreVendor}.
	 */
	public String getJreVendor() {
		return jreVendor;
	}

	/**
	 * Get the {@link #jreVersion}.
	 * 
	 * @return the {@link #jreVersion}.
	 */
	public String getJreVersion() {
		return jreVersion;
	}

	/**
	 * Get the {@link #homeDir}.
	 * 
	 * @return the {@link #homeDir}.
	 */
	public String getHomeDir() {
		return homeDir;
	}

	/**
	 * Get the {@link #vmVendor}.
	 * 
	 * @return the {@link #vmVendor}.
	 */
	public String getVmVendor() {
		return vmVendor;
	}

	/**
	 * Get the {@link #vmName}.
	 * 
	 * @return the {@link #vmName}.
	 */
	public String getVmName() {
		return vmName;
	}

	/**
	 * Get the {@link #vmInfo}.
	 * 
	 * @return the {@link #vmInfo}.
	 */
	public String getVmInfo() {
		return vmInfo;
	}

	/**
	 * Get the {@link #jniLibraryPath}.
	 * 
	 * @return the {@link #jniLibraryPath}.
	 */
	public String getJniLibraryPath() {
		return jniLibraryPath;
	}

	/**
	 * Get the {@link #tmpDir}.
	 * 
	 * @return the {@link #tmpDir}.
	 */
	public String getTmpDir() {
		return tmpDir;
	}

	/**
	 * Get the {@link #osName}.
	 * 
	 * @return the {@link #osName}.
	 */
	public String getOsName() {
		return osName;
	}

	/**
	 * Get the {@link #osVersion}.
	 * 
	 * @return the {@link #osVersion}.
	 */
	public String getOsVersion() {
		return osVersion;
	}

	/**
	 * Get the {@link #jvmArch}.
	 * 
	 * @return the {@link #jvmArch}.
	 */
	public String getJvmArch() {
		return jvmArch;
	}

	/**
	 * Get the {@link #userName}.
	 * 
	 * @return the {@link #userName}.
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Get the {@link #workingDir}.
	 * 
	 * @return the {@link #workingDir}.
	 */
	public String getWorkingDir() {
		return workingDir;
	}

	/**
	 * Get the {@link #userHome}.
	 * 
	 * @return the {@link #userHome}.
	 */
	public String getUserHome() {
		return userHome;
	}

	/**
	 * Get the {@link #defEncoding}.
	 * 
	 * @return the {@link #defEncoding}.
	 */
	public String getDefEncoding() {
		return defEncoding;
	}

	/**
	 * Get the {@link #availableProcessors}.
	 * 
	 * @return the {@link #availableProcessors}.
	 */
	public int getAvailableProcessors() {
		return availableProcessors;
	}

	/**
	 * Get the {@link #osPhysicalMemory}.
	 * 
	 * @return the {@link #osPhysicalMemory}.
	 */
	public long getOsPhysicalMemory() {
		return osPhysicalMemory;
	}

	/**
	 * Get the {@link #osPackVersion}.
	 * 
	 * @return the {@link #osPackVersion}.
	 */
	public String getOsPackVersion() {
		return osPackVersion;
	}

	/**
	 * Get the {@link #startTime}.
	 * 
	 * @return the {@link #startTime}.
	 */
	public long getStartTime() {
		return startTime;
	}

	/**
	 * 获得本机主机名和IP.
	 * 
	 * @creator liushen @ Jun 2, 2009
	 */
	public String getHostNameAndIP() {
		return NetUtil.getLocalHost();
	}

	/**
	 * Get the {@link #hostname}.
	 * 
	 * @return the {@link #hostname}.
	 */
	public String getHostname() {
		return hostname;
	}

	/**
	 * Get the {@link #ip}.
	 * 
	 * @return the {@link #ip}.
	 */
	public String getIp() {
		return ip;
	}

	/**
	 * Get the {@link #osFreePhysicalMemory}.
	 * 
	 * @return the {@link #osFreePhysicalMemory}.
	 */
	public long getOsFreePhysicalMemory() {
		try{
			return JMXUtil.getAttrAsLong("java.lang:type=OperatingSystem",
			"FreePhysicalMemorySize");
		} catch (Throwable e) {
			// TRSMAS-2334 
			LOG.warn("failed to get free physical memory info because " + e);
			return -2;
		}
	}

	/**
	 * Get the {@link #maxOpenFile}.
	 * 
	 * @return the {@link #maxOpenFile}.
	 */
	public int getMaxOpenFile() {
		return maxOpenFile;
	}

	/**
	 * Get the {@link #currentOpenFile}.
	 * 
	 * @return the {@link #currentOpenFile}.
	 */
	public int getCurrentOpenFile() {
		if (EnvConst.isWindows()) {
			return 0;
		}
		try {
			return (int) JMXUtil
					.getAttrAsLong("java.lang:type=OperatingSystem",
							"OpenFileDescriptorCount");
		} catch (Throwable e) {
			System.err.println(e.getMessage());
			return 0;
		}
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 17, 2011
	 */
	public int getJVMCurrentThreadCount() {
		return (int) JMXUtil.getAttrAsLong("java.lang:type=Threading",
				"ThreadCount");
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 17, 2011
	 */
	public int getJVMPeakThreadCount() {
		return (int) JMXUtil.getAttrAsLong("java.lang:type=Threading",
				"PeakThreadCount");
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 17, 2011
	 */
	public int getJVMTotalStartedThreadCount() {
		return (int) JMXUtil.getAttrAsLong("java.lang:type=Threading",
				"TotalStartedThreadCount");
	}

}
