/*
 * Created: liushen@Jul 17, 2013 1:12:27 PM
 */
package com.trs.dev4.jdk16.exception;

/**
 * FTP操作异常。<br>
 * 
 */
@SuppressWarnings("serial")
public class FTPException extends RootException {

	/**
	 * @param msg
	 * @param cause
	 */
	public FTPException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public FTPException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public FTPException(Throwable cause) {
		super(cause);
	}

}
