/*
 * Created: TRS@Feb 13, 2012 9:52:54 PM
 */
package com.trs.dev4.jdk16.model.impl;

import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.trs.dev4.jdk16.cacheserver.impl.LocalCacheServer;
import com.trs.dev4.jdk16.model.Configuration;
import com.trs.dev4.jdk16.model.IConfigurable;
import com.trs.dev4.jdk16.model.IConfigurationManager;
import com.trs.dev4.jdk16.model.IPageService;
import com.trs.dev4.jdk16.model.ValidationErrors;
import com.trs.dev4.jdk16.session.RequestContext;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: 实现{@link IPageService}接口，提供前台页面和地址相关的服务 <br>
 * 
 */
public class PageService implements IPageService, ApplicationContextAware, IConfigurable {
	/**
	 * 
	 */
	private IConfigurationManager configurationManager;

	/**
	 * @see com.trs.dev4.jdk16.model.IPageService#findPageCache(com.trs.dev4.jdk16.session.RequestContext,
	 *      java.lang.String)
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public String findPageCache(RequestContext requestContext, String pageKey) {
		String pageContent = (String) LocalCacheServer.getInstance("pageContent").get(pageKey);
		return pageContent;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IPageService#updatePageCache(com.trs.dev4.jdk16.session.RequestContext, java.lang.String, java.lang.String)
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public void updatePageCache(RequestContext requestContext, String pageKey, String pageContent) {
		String cacheCount = (String) LocalCacheServer.getInstance("urlCacheServer").get(pageKey);
		if (cacheCount != null) {
			LocalCacheServer.getInstance("pageContent").set(pageKey, pageContent);
		}
	}

	/**
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#getPrefix()
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public String getPrefix() {
		return this.getClass().getSimpleName();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#refreshConfigs()
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public void refreshConfigs() {
		String[] cacheUrls = StringHelper.split(configurationManager.getConfiguration(this, "cacheUrls"),";");
		LocalCacheServer.getInstance("urlCacheServer").clearAll();
		for (String cacheUrl : cacheUrls) {
			LocalCacheServer.getInstance("urlCacheServer").add(cacheUrl, -1, "");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#validateConfigs(java.util.Map)
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public ValidationErrors validateConfigs(Map<String, Configuration> configs) {
		return null;
	}

	/**
	 * @param configurationManager
	 *            the {@link #configurationManager} to set
	 */
	public void setConfigurationManager(IConfigurationManager configurationManager) {
		this.configurationManager = configurationManager;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IPageService#convertReadableUrl(java.lang.String)
	 * @since TRS @ Feb 14, 2012
	 */
	@Override
	public String convertReadableUrl(RequestContext requestContext, String relativePath) {
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IPageService#convertDynamicUrl(java.lang.String)
	 * @since TRS @ Feb 14, 2012
	 */
	@Override
	public String convertDynamicUrl(RequestContext requestContext, String relativePath) {
		return null;
	}
}
