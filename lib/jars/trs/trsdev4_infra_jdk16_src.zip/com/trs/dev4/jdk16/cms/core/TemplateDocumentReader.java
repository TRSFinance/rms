package com.trs.dev4.jdk16.cms.core;

import java.util.List;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.bo.ScanContext;
import com.trs.dev4.jdk16.cms.bo.TagItem;
import com.trs.dev4.jdk16.cms.bo.TemplateDocument;
import com.trs.dev4.jdk16.cms.exp.TemplateException;

/**
 * 
 * 用于从模板{@link ITemplate}中读取模板解析结果{@link TemplateDocument}
 * 
 */
public class TemplateDocumentReader {
	/** debug modal switch */
	public static boolean IS_DEBUG = false;

	/** logger */
	private final static Logger logger = Logger.getLogger(TemplateDocumentReader.class.getName());

	// to define the runnning status
	/** status: on reading tag name */
	public final static int ST_TAGNAME = 1;

	/** status: on tag name end */
	public final static int ST_TAGNAME_END = 2;

	/** status: on reading attribute name */
	public final static int ST_ATTRNAME = 3;

	/** status: on attribute name end */
	public final static int ST_ATTRNAME_END = 4;

	/** status: on reading attribute value having quote */
	public final static int ST_ATTRVALUE_HASQUOTE = 5;

	/** status: on reading attribute value with no quote */
	public final static int ST_ATTRVALUE_NOQUOTE = 6;

	/** status: on attribute value end */
	public final static int ST_ATTRVALUE_END = 7;

	/** status: on start-tag end */
	public final static int ST_STARTTAG_END = 8;

	/** status: on begining to read a child */
	public final static int ST_CHILD_BEGIN = 9;

	/** status: on reading TagItem child */
	public final static int ST_CHILD_TAGITEM = 10;

	/** status: on reading String child */
	public final static int ST_CHILD_STRING = 11;

	/** status: on a String child end */
	public final static int ST_CHILD_STRING_END = 12;

	/** status: on to check the endtag */
	public final static int ST_ENDTAG_CHECK = 93;

	/** status: on to check the self-closed tag */
	public final static int ST_SELFCLOSEDTAG_CHECK = 95;

	/** status: on begining to read attribute value having quote */
	public final static int ST_ATTRVALUE_HASQUOTE_BEGIN = 13;

	/** status: on to check attribute value end having quote */
	public final static int ST_ATTRVALUE_HASQUOTE_ENDCHECK = 14;

	/**
	 * reading map in format: <BR>
	 * [1]Level 1: the whole reading map <Br>
	 * array index=Current Status; <BR>
	 * value=next step route mapping <BR>
	 * [2]Level 2: next step route mapping <BR>
	 * item from the second one = a route for a condition <BR>
	 * first item = the next status for other condition <BR>
	 * [3]Level 3: a route for a condition <BR>
	 * char before the last one = the condition <BR>
	 * the last one char = next step status <BR>
	 * <BR>
	 * <BR>
	 * reading map data: <BR>
	 * 1 blanks / > 2 <BR>
	 * 1 * 1 <BR>
	 * 2 > 8 <BR>
	 * 2 /> 95 <BR>
	 * 2 * 3 <BR>
	 * 3 = / > blanks 4 <BR>
	 * 3 * 3 <BR>
	 * 4 blanks / > 7 <BR>
	 * 4 " ' 13 <BR>
	 * 4 * 6 <BR>
	 * 5 " ' 14 <BR>
	 * 5 * 5 <BR>
	 * 6 / > blanks 7 <BR>
	 * 6 * 6 <BR>
	 * 7 > 8 <BR>
	 * 7 /> 95 <BR>
	 * 7 * 3 <BR>
	 * 8 </ 13 <BR>
	 * 8 * 9 <BR>
	 * 9 </ 93 <BR>
	 * 9 <TRS_ 10 <BR>
	 * 9 * 11 <BR>
	 * 11 </ or <TRS_ 12 <BR>
	 * 12 <TRS_ 9 <BR>
	 * 12 </ 93 <BR>
	 * 12 * 11 <BR>
	 */
	private static char[][][] READING_MAP = { { { 1 } }, // 0
			{ { 1 }, { ' ', 2 }, { '/', 2 }, { '>', 2 } }, // 1
			{ { 3 }, { '>', 8 }, { '/', 95 } }, // 2
			{ { 3 }, { '=', 4 }, { '/', 4 }, { '>', 4 } }, // 3
			{ { 6 }, { ' ', 7 }, { '/', 7 }, { '>', 7 }, { '"', 13 }, { '\'', 13 } }, // 4
			{ { 5 }, { '"', 14 }, { '\'', 14 } }, // 5
			{ { 6 }, { '/', 7 }, { '>', 7 }, { ' ', 7 } }, // 6
			{ { 3 }, { '>', 8 }, { '/', 95 } }, // 7
			{ { 9 }, { '<', '/', 93 } }, // 8
			{ { 11 }, { '<', '/', 'T', 'R', 'S', '_', 93 }, { '<', 'T', 'R', 'S', '_', 10 } }, // 9
			{ { 9 } }, // 10
			{ { 11 }, { '<', '/', 'T', 'R', 'S', '_', 12 }, { '<', 'T', 'R', 'S', '_', 12 } }, // 11
			{ { 'x' }, { '<', '/', 93 }, { '<', 9 } }, // 12
	};

	/**
	 * constructor: forbid to call
	 */
	private TemplateDocumentReader() {

	}

	/**
	 * read a tag document from the specified content.
	 * 
	 * @param _text
	 *            the tag document content.
	 * @return Returns the tag document read.
	 * @throws Exception
	 *             if failed to parse the document content.
	 */
	public static void read(String _text, TemplateDocument aDoc) {
		if (_text == null) {
			throw new TemplateException("Tag document content required.");
		}
		if (aDoc == null) {
			throw new TemplateException("TemplateDocument required.");
		}

		// else
		ScanContext sCtx = new ScanContext(_text);
		if (!sCtx.hasChar()) {
			return;
		}

		// else
		StringBuffer buffResult = new StringBuffer();
		int nCurrStatus = ST_CHILD_BEGIN;
		int nCurrTagStartPos = 0;
		char aChar;
		while (sCtx.hasChar()) {
			aChar = sCtx.getChar();
			if (IS_DEBUG) {
				System.out.print("CS=" + nCurrStatus + "; Char=" + aChar + "; nPos=" + sCtx.getOffset());
			}
			nCurrStatus = lookupNextStatus(nCurrStatus, sCtx);
			if (IS_DEBUG) {
				System.out.println("; NS=" + nCurrStatus);
			}

			switch (nCurrStatus) {
			case ST_ENDTAG_CHECK: {
				throw new TemplateException("非预期的结束置标! " + sCtx.lookAround(nCurrTagStartPos));
			}
			case ST_CHILD_STRING: {
				buffResult.append(aChar);
				sCtx.skipChar();
				break;
			}
			case ST_CHILD_BEGIN: {
				// do nothing
				break;
			}
			case ST_CHILD_TAGITEM: {
				nCurrTagStartPos = sCtx.getOffset();
				TagItem aChild = readItem(sCtx);
				aDoc.addItem(aChild);
				break;
			}
			case ST_CHILD_STRING_END: {
				aDoc.addItem(buffResult.toString());
				buffResult.setLength(0);
				break;
			}
			default: {
				throw new TemplateException("未知的转移状�?:" + nCurrStatus + sCtx.lookAround(nCurrTagStartPos));
			}
			}
		}// endwhile

		// deal with the tail
		if (buffResult.length() > 0) {
			aDoc.addItem(buffResult.toString());
			buffResult.setLength(0);
		}

		// format all items
		int nSize = aDoc.getItemCount();
		for (int i = 0; i < nSize; i++) {
			Object item = aDoc.getItemAt(i);
			if (!(item instanceof TagItem))
				continue;

			formateItem((TagItem) item);
		}

		// successfully
		return;
	}

	/**
	 * 
	 * @param _item
	 * @throws TemplateException
	 * @since TRS @ Feb 16, 2011
	 */
	private static void formateItem(TagItem _item) throws TemplateException {
		if (_item == null)
			return;

		// standardizeTagItem(_item);

		List<TagItem> lChildren = _item.getChildren();
		if (lChildren == null || lChildren.isEmpty())
			return;

		int nSize = lChildren.size();
		for (int i = 0; i < nSize; i++) {
			Object item = lChildren.get(i);
			if (!(item instanceof TagItem))
				continue;

			formateItem((TagItem) item);
		}
	}

	/**
	 * read a tag item from the specified content
	 * 
	 * @param _textChars
	 *            the content to read
	 * @param _nStartPos
	 *            the start position
	 * @param _lastPos
	 *            the last position after reading
	 * @return Returns the tag item read.
	 * @throws Exception
	 *             if the tag item is not intact.
	 */
	private static TagItem readItem(ScanContext sCtx) {
		TagItem aItem = new TagItem();
		aItem.setBeginColumn(sCtx.getColumn());
		aItem.setBeginLineNo(sCtx.getLineNo());

		if (!sCtx.hasChar()) {
			return aItem;
		}

		// else
		int nStartPos = sCtx.getOffset();
		int nCurrStatus = ST_TAGNAME;
		sCtx.skipChar(); // skip '<'
		char aChar, chrQuote = ' ';
		StringBuffer buffResult = new StringBuffer();
		String sAttributeName = null;

		try {
			while (sCtx.hasChar()) {
				aChar = sCtx.getChar();
				if (IS_DEBUG) {
					System.out.print("CS=" + nCurrStatus + "; Char=" + aChar + "; nPos=" + sCtx.getOffset());
				}
				nCurrStatus = lookupNextStatus(nCurrStatus, sCtx);
				if (IS_DEBUG) {
					System.out.println("; NS=" + nCurrStatus);
				}
				switch (nCurrStatus) {
				case ST_TAGNAME:
				case ST_ATTRNAME:
				case ST_ATTRVALUE_HASQUOTE:
				case ST_ATTRVALUE_NOQUOTE:
				case ST_CHILD_STRING: {
					buffResult.append(aChar);
					sCtx.skipChar();
					break;
				}
				case ST_TAGNAME_END: {
					if (buffResult.length() == 0) {
						throw new TemplateException("缺少置标名称! " + sCtx.lookAround(nStartPos));
					}
					aItem.setName(buffResult.toString());
					buffResult.setLength(0);
					// skip blanks
					while (sCtx.hasChar() && Character.isWhitespace(sCtx.getChar())) {
						sCtx.skipChar();
					}
					break;
				}
				case ST_ATTRNAME_END: {
					if (aChar != '=') {
						throw new TemplateException("置标属�?�[" + buffResult.toString() + "]缺少'='! " + sCtx.lookAround(nStartPos));
					}
					if (buffResult.length() == 0) {
						throw new TemplateException("缺少置标属�?�名�?! " + sCtx.lookAround(nStartPos));
					}
					sAttributeName = buffResult.toString().trim();
					buffResult.setLength(0);
					sCtx.skipChar(); // skip '='

					// skip blanks
					while ((sCtx.hasChar() && Character.isWhitespace(sCtx.getChar()))) {
						sCtx.skipChar();
					}
					break;
				}
				case ST_ATTRVALUE_HASQUOTE_BEGIN: {
					chrQuote = aChar;
					nCurrStatus = ST_ATTRVALUE_HASQUOTE;
					sCtx.skipChar(); // skip quote
					break;
				}
				case ST_ATTRVALUE_HASQUOTE_ENDCHECK: {
					if (aChar != chrQuote || sCtx.prevChar() == '\\') {
						buffResult.append(aChar);
						sCtx.skipChar();
						nCurrStatus = ST_ATTRVALUE_HASQUOTE;
						break;
					}

					// else
					nCurrStatus = ST_ATTRVALUE_END;
					sCtx.skipChar(); // skip quote
					// continue to save the attribute value
				}
				case ST_ATTRVALUE_END: {
					aItem.setAttribute(sAttributeName, buffResult.toString());
					buffResult.setLength(0);
					// skip blanks
					while ((sCtx.hasChar() && Character.isWhitespace(sCtx.getChar()))) {
						sCtx.skipChar();
					}
					break;
				}
				case ST_STARTTAG_END: {
					sCtx.skipChar(); // skip '>'
					break;
				}
				case ST_CHILD_BEGIN: {
					// do nothing
					break;
				}
				case ST_CHILD_TAGITEM: {
					TagItem aChild = readItem(sCtx);
					aItem.addChild(aChild);
					// wenyh@2006-8-14 15:39:47 add comment:记录父TagItem
					aChild.setParent(aItem);
					break;
				}
				case ST_CHILD_STRING_END: {
					aItem.addChild(buffResult.toString());
					buffResult.setLength(0);
					break;
				}
				case ST_ENDTAG_CHECK: {
					// skip "</"
					sCtx.skipChar();
					sCtx.skipChar();
					char[] charsToMatch = (aItem.getName() + '>').toCharArray();
					boolean bMatched = true;
					int nMatchedLength;
					char chr1, chr2;

					sCtx.mark();

					for (nMatchedLength = 0; nMatchedLength < charsToMatch.length; nMatchedLength++) {
						if (!sCtx.hasChar()) {
							throw new TemplateException("置标 " + aItem.getDescWithPos() + " 没有结束! " + sCtx.lookAround(nStartPos));
						}

						chr1 = sCtx.getChar();
						sCtx.skipChar();
						chr2 = charsToMatch[nMatchedLength];
						if (chr1 != chr2 && Character.toUpperCase(chr1) != chr2) {
							bMatched = false;
							break;
						}
					}// endfor
					if (bMatched) {
						// caohui@2005-11-16 remove
						// standardizeTagItem(aItem);
						aItem.setCloseColumn(sCtx.getColumn());
						aItem.setCloseLineNo(sCtx.getLength());
						return aItem;
					}

					// else
					nCurrStatus = ST_CHILD_STRING;
					buffResult.append("</");
					sCtx.reset();
					break;
				}
				case ST_SELFCLOSEDTAG_CHECK: {
					sCtx.skipChar(); // skip '/'
					if (sCtx.hasChar() && sCtx.getChar() == '>') {
						sCtx.skipChar(); // skip '>'
						// caohui@2005-11-16 remove
						// standardizeTagItem(aItem);
						aItem.setCloseColumn(sCtx.getColumn());
						aItem.setCloseLineNo(sCtx.getLength());
						return aItem;
					}

					// else
					throw new TemplateException("置标 " + aItem.getDescWithPos() + " 缺少结束字符'>'! " + sCtx.lookAround(nStartPos));
				}
				default: {
					throw new TemplateException("未知的转移状�?:" + nCurrStatus + sCtx.lookAround(nStartPos));
				}
				}
			}// endwhile

			// to check if successful
			String sError = null;
			switch (nCurrStatus) {
			case ST_TAGNAME:
				aItem.setName(buffResult.toString());
			case ST_TAGNAME_END: {
				sError = "close tag required. ";
				break;
			}
			case ST_ATTRNAME:
			case ST_ATTRNAME_END: {
				sError = "value of attribute [" + sAttributeName + "] is required. ";
				break;
			}

			case ST_ATTRVALUE_HASQUOTE:
			case ST_ATTRVALUE_NOQUOTE:
			case ST_ATTRVALUE_END:
			case ST_ATTRVALUE_HASQUOTE_ENDCHECK: {
				sError = "value of attribute [" + sAttributeName + "] is not closed. ";
				break;
			}

			case ST_STARTTAG_END:
			case ST_CHILD_BEGIN:
			case ST_CHILD_STRING:
			case ST_CHILD_STRING_END: {
				sError = "缺少结束置标!";
				break;
			}

			case ST_CHILD_TAGITEM: {
				sError = "tag item child is not closed. ";
				break;
			}
			}// endcase

			if (sError != null) {
				throw new TemplateException("置标 " + aItem.getDescWithPos() + " 有错�?:" + sError + sCtx.lookAround(nStartPos) + " [状�??=" + nCurrStatus + "] ");
			}

			// successfully
			// to check if the tag name is stored in property "id"
			// caohui@2005-11-16 remove
			// standardizeTagItem(aItem);
			aItem.setCloseColumn(sCtx.getColumn());
			aItem.setCloseLineNo(sCtx.getLength());
			return aItem;
		} catch (Exception ex) {
			logger.error("Failed to read tag item while parsed result is: " + aItem.toString(), ex);
			aItem.clear();
			buffResult.setLength(0);
			throw new TemplateException(aItem.toString(), ex);
		}
	}

	/**
	 * lookup the next status at the current condition.
	 * 
	 * @param _nCurrentStatus
	 *            the current status.
	 * @param _chars
	 *            the text characters.
	 * @param _nPos
	 *            the current position in the characters.
	 * @return Returns the next status if found.
	 * @throws Exception
	 *             if no route is defined for the current status.
	 */
	public static int lookupNextStatus(int _nCurrentStatus, ScanContext sCtx) {
		if (_nCurrentStatus >= READING_MAP.length) {
			throw new TemplateException("No route is found for status " + _nCurrentStatus);
		}

		// to lookup in the related route
		char[][] map = READING_MAP[_nCurrentStatus];
		char[] aRoute;
		int nRouteIndex, nCharIndex;
		char char1, char2;
		boolean bFound;

		for (nRouteIndex = 1; nRouteIndex < map.length; nRouteIndex++) {
			aRoute = map[nRouteIndex];
			bFound = true;
			sCtx.mark();
			for (nCharIndex = 0; nCharIndex < aRoute.length - 1; nCharIndex++) {
				if (sCtx.hasChar()) {
					char1 = aRoute[nCharIndex];
					char2 = sCtx.getChar();
					sCtx.skipChar();
					if ((char1 == char2) || (char1 == ' ' && Character.isWhitespace(char2)) || (char1 == Character.toUpperCase(char2)))
						continue;
				}

				// else
				bFound = false;
				break;
			}
			sCtx.reset();
			if (bFound) {
				return aRoute[nCharIndex];
			}
		}// endfor

		// other character
		return map[0][0];
	}

}