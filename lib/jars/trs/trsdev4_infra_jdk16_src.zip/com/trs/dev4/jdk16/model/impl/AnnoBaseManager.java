/*
 * created by liuyou @ 2010-4-22
 */
package com.trs.dev4.jdk16.model.impl;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.ListableBeanFactory;

import com.trs.dev4.jdk16.dao.IAccessor;
import com.trs.dev4.jdk16.model.BaseManager;
import com.trs.dev4.jdk16.model.ISerializableEntity;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 自动注解的BaseManager的基类
 * 
 * @author liuyou
 * 
 */
public class AnnoBaseManager<T extends ISerializableEntity> extends BaseManager<T> implements InitializingBean, BeanFactoryAware {

	/**
	 * 通过检查父类泛型的类型自动设置领域对象的类型
	 */
	public AnnoBaseManager() {
		// setClassType(((Class<T>) ((java.lang.reflect.ParameterizedType)
		// this.getClass().getGenericSuperclass()).getActualTypeArguments()[0]));
	}

	/**
	 * 也可以由子类覆盖构造函数时显式的指定类型
	 * 
	 * @param classType
	 */
	public AnnoBaseManager(Class<T> classType) {
		setClassType(classType);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#addNew(com.trs.dev4.jdk16.model.IEntity)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public int addNew(T t) {
		return super.addNew(t);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#delete(com.trs.dev4.jdk16.model.IEntity)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void delete(T t) {
		super.delete(t);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#saveOrUpdate(com.trs.dev4.jdk16.model.IEntity)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void saveOrUpdate(T t) {
		super.saveOrUpdate(t);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.BaseManager#update(com.trs.dev4.jdk16.model.IEntity)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void update(T t) {
		super.update(t);
	}

	/**
	 * 自动注入同类型的DAO
	 * 
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 * @since liuyou@2010-4-20
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void afterPropertiesSet() throws Exception {
		if (getAccessor() != null)
			return;
		if (classType == null) {
			setClassType(((Class<T>) ((java.lang.reflect.ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[0]));
		}
		if (beanFactory instanceof ListableBeanFactory) {
			ListableBeanFactory listBeanFactory = (ListableBeanFactory) beanFactory;
			Map<?, ?> beans = listBeanFactory.getBeansOfType(IAccessor.class);
			for (Object bean : beans.values()) {
				if (bean == null) {
					logger.error("Bean == null ");
					continue;
				}
				IAccessor<?> accessor = (IAccessor<?>) bean;
				if (classType != null && accessor != null) {
					if (accessor.getClassType().equals(classType)) {
						setAccessor((IAccessor<T>) accessor);
						logger.debug("Bean (" + bean + ") found by " + this.getClass().getName() + ". Accessor:" + accessor + ",ClassType:"
								+ classType.getSimpleName());
					}
				}
			}
			if (this.getAccessor() == null) {
				logger.warn("Class " + this.getClass().getName() + "'s accessor is null ,ClassType:" + classType);
			}
			return;
		}
		String beanName = StringHelper.uncapitalize(classType.getName());
		Object bean = beanFactory.getBean(beanName + "DAO", IAccessor.class);
		if (bean == null) {
			logger.error("Class " + this.getClass().getName() + "'s accessor is null ,ClassType:" + classType);
			return;
		}
		setAccessor((IAccessor<T>) bean);
	}

	/**
	 * 设置领域对象的泛型的类型
	 * 
	 * @param classType
	 * @since liuyou @ 2010-5-23
	 */
	public void setClassType(Class<T> classType) {
		this.classType = classType;
		if (logger.isInfoEnabled()) {
			logger.info("setClassType:" + classType + " with bean:" + this);
		}
	}

	/**
	 * 返回领域对象的泛型的类型
	 * 
	 * @return
	 * @since liuyou @ 2010-5-23
	 */
	protected Class<T> getClassType() {
		return classType;
	}

	/**
	 * @see org.springframework.beans.factory.BeanFactoryAware#setBeanFactory(org.springframework.beans.factory.BeanFactory)
	 * @since liuyou@2010-4-20
	 */
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		this.beanFactory = beanFactory;
	}

	/**
	 *
	 */
	protected Logger logger = Logger.getLogger(getClass());
	/**
	 *
	 */
	private Class<T> classType;
	/**
	 *
	 */
	private BeanFactory beanFactory;
}
