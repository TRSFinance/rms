package com.trs.dev4.jdk16.cms.tag;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.trs.dev4.jdk16.cms.TagAware;
import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.enu.LoopType;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.cms.expression.FilterByFieldTagExpression;
import com.trs.dev4.jdk16.cms.expression.OrderByTagExpresion;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.exception.DAOException;

public class ObjectsTagParser implements TagParser {

	@SuppressWarnings("unchecked")
	@Override
	public String parse(final TagContext tagContext) {

		TagAware<?> tagAware = tagContext.getTagAware("obj");

		SearchFilter sf = SearchFilter.getNoPagedFilter();
		
		int startItem = 0;
		int toItem = 0;
		int pageStep = 10;

		if (tagContext.existAttribute("from") && tagContext.existAttribute("to")) {
			int to = tagContext.getIntValue("to");
			int from = tagContext.getIntValue("from");
			sf = SearchFilter.getSearchFilter(0, to);
			startItem = from - 1;
			toItem = to - 1;
		}

		if (tagContext.existAttribute("pageNo") && tagContext.existAttribute("pageSize")) {
			sf = SearchFilter.getSearchFilter(tagContext.getIntFunctionValue("pageNo", 1) - 1, tagContext.getIntFunctionValue("pageSize"));
		}
		if (tagContext.existAttribute("pageStep")) {
			pageStep = tagContext.getIntValue("pageStep");
		}
		if (tagContext.existAttribute("filterByField")) {
			List<FilterByFieldTagExpression> filterByFieldTagExpressions = tagContext.getFilterByFieldValues("filterByField");
			for (FilterByFieldTagExpression filterByFieldTagExpression : filterByFieldTagExpressions) {
				filterByFieldTagExpression.getExpressionOperator().buildSearchFilter(sf, filterByFieldTagExpression);
			}
		}
		if (tagContext.existAttribute("orderBy")) {
			List<OrderByTagExpresion> orderByTagExpresions = tagContext.getOrderByValue("orderBy");
			StringBuilder orderBuilder = new StringBuilder();
			for (OrderByTagExpresion orderByTagExpresion : orderByTagExpresions) {
				if (orderByTagExpresion.getOrderby().equalsIgnoreCase("rand")) {
					int count = tagAware.total(sf);
					if (count > 0) {
						int randomPage = new Random().nextInt(count);
						sf.setStartPos(randomPage);
						sf.setMaxResults(1);
					}
				} else {
					orderBuilder.append(orderByTagExpresion.getEntityProperty()).append(" ").append(orderByTagExpresion.getOrderby()).append(",");
				}
			}
			if (orderBuilder.toString().endsWith(",")) {
				orderBuilder.deleteCharAt(orderBuilder.lastIndexOf(","));
			}
			sf.setOrderBy(orderBuilder.toString());
		}
		PagedList<?> queryResult = null;

		try {
			queryResult = tagAware.pagePublishObjects(sf);
		} catch (DAOException e) {
			throw new TemplateException("FilterByField条件表达式构造有误，前后类型不一致", tagContext);
		}
		
		List<?> publishObjects = queryResult.getPageItems();

		if (startItem > 0 && toItem > 0) {
			int length = publishObjects.size();
			if (startItem > length) {
				publishObjects = new ArrayList();
			} else {
				publishObjects = publishObjects.subList(startItem, (toItem < length) ? toItem + 1 : length);				
			}
		}

		StringBuilder content = new StringBuilder();

		LoopType loopType = tagContext.getLoopTypeValue("loopType", LoopType.NOLOOP);

		String parsedResult = "";

		if (loopType.needLoop()) {
			parsedResult = TagExpressionHelper.parseLoopTemplate(tagContext, publishObjects);
		} else {
			parsedResult = TagExpressionHelper.parseInternalTemplate(tagContext, new PublishObject(new PagedList(queryResult.getPageIndex(), queryResult
					.getPageSize(), queryResult.getTotalItemCount(), publishObjects, pageStep)));
		}
		content.append(parsedResult);
		return content.toString();
	}

}
