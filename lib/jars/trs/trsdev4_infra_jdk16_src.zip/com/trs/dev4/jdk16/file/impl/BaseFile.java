/*
 * Created: liushen@Apr 6, 2011 12:00:14 PM
 */
package com.trs.dev4.jdk16.file.impl;

import com.trs.dev4.jdk16.file.IFile;
import com.trs.dev4.jdk16.file.IFileResource;
import com.trs.dev4.jdk16.utils.DateUtil;
import com.trs.dev4.jdk16.utils.FileUtil;
import com.trs.dev4.jdk16.utils.JSONBuilder;

/**
 * 抽象基类. <br>
 * 
 */
public abstract class BaseFile implements IFile {

	/**
	 * @see com.trs.dev4.jdk16.file.IFile#getExtensionName()
	 * @since liushen @ Apr 6, 2011
	 */
	@Override
	public String getExtensionName() {
		return FileUtil.getFileExtension(getName());
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Apr 6, 2011
	 */
	@Override
	public String toString() {
		return getClass().getSimpleName() + ": " + toJSON();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#toJSON()
	 * @since liushen @ Apr 6, 2011
	 */
	@Override
	public String toJSON() {
		return toJSON(this);
	}

	/**
	 * 
	 * @param fileResource
	 * @return
	 * @since liushen @ Apr 6, 2011
	 */
	static String toJSON(IFileResource fileResource) {
		JSONBuilder builder = new JSONBuilder();
		builder.add("name", fileResource.getName());
		builder.add("lastModified",
				DateUtil.formatMillis(fileResource.lastModified()));
		if (fileResource instanceof IFile) {
			final IFile file = (IFile) fileResource;
			builder.add("size", file.length());
		}
		return builder.toJSONObjString();
	}

}
