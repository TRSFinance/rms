package com.trs.dev4.jdk16.cms.exp;

import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

public class RequestParameterNotFoundException extends RuntimeException{

	public RequestParameterNotFoundException(String message) {
		super(message);
	}
	
	/**
	 * @param string
	 * @param tagContext
	 */
	public RequestParameterNotFoundException(String msg, TagContext tagContext) {
		super(TagExpressionHelper.buildTemplateException(tagContext, msg));
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
