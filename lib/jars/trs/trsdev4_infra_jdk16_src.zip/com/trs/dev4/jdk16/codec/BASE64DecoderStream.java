/*
 * Created on 2004-5-16 by Martin (Fu Chengrui)
 */
package com.trs.dev4.jdk16.codec;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * BASE64 解码输入流。 线程不安全。
 */
public class BASE64DecoderStream extends FilterInputStream {

	/**
	 * 解码码表
	 */
	final static byte detable[] = new byte[256];

	/**
	 * cache of decoded bytes
	 */
	private byte[] buffer = new byte[3];

	/**
	 * size of the cache
	 */
	private int bufsize = 0;

	/**
	 * 解码缓冲区
	 */
	private byte[] decode_buffer = new byte[4];

	/**
	 * index into the cache
	 */
	private int index = 0;

	/**
	 * 初始化解码码表
	 */
	static {
		for (int i = 0; i < 255; i++) {
			detable[i] = -1;
		}

		// for (int i = 0; i < BASE64EncoderStream.entable.length; i++)
		for (int i = 0; i < 64; i++) {
			detable[BASE64EncoderStream.entable[i]] = (byte) i;
		}
	}

	/**
	 * 解码BASE64数组，输入的字节数组中不能含有BASE64字符以外的字符。该方法适用于解码少量数据。
	 * 
	 * @param inbuff
	 *            待解码的字节数组
	 * @return 解码结果数组
	 */
	public final static byte[] decode(byte[] inbuff) {
		int iSize = (inbuff.length / 4) * 3;
		if (iSize == 0) {
			return inbuff;
		}

		if (inbuff[inbuff.length - 1] == '=') {
			if (inbuff[inbuff.length - 2] == '=') {
				iSize--;
			}
			iSize--;
		}

		int inposi = 0;
		int outpos = 0;
		byte[] outbuf = new byte[iSize];

		for (iSize = inbuff.length; iSize > 0; iSize -= 4) {
			byte a = detable[inbuff[inposi++] & 0xff];
			byte b = detable[inbuff[inposi++] & 0xff];

			// The first decoded byte
			outbuf[outpos++] = (byte) (((a << 2) & 0xfc) | ((b >>> 4) & 3));
			if (inbuff[inposi] == '=') {
				break; // End of this BASE64 encoding
			}

			// The second decoded byte
			a = b;
			b = detable[inbuff[inposi++] & 0xff];
			outbuf[outpos++] = (byte) (((a << 4) & 0xf0) | ((b >>> 2) & 0xf));
			if (inbuff[inposi] == '=') {
				break; // End of this BASE64 encoding
			}

			// The third decoded byte
			a = b;
			b = detable[inbuff[inposi++] & 0xff];
			outbuf[outpos++] = (byte) (((a << 6) & 0xc0) | (b & 0x3f));
		}
		return outbuf;
	}

	/**
	 * 解码BASE64编码的字符串，输入的字符串中不能含有BASE64字符以外的字符。该方法适用于解码少量数据。
	 * 
	 * @param encoded
	 *            BASE64编码的字符串
	 * @return 解码结果数组
	 */
	public final static byte[] decode(String encoded) {
		char[] charbuff = encoded.toCharArray();
		byte[] bytebuff = new byte[charbuff.length];
		for (int i = charbuff.length - 1; i >= 0; i--) {
			bytebuff[i] = (byte) charbuff[i];
		}
		return decode(bytebuff);
	}

	/**
	 * 使用指定的输入流创建<code>BASE64DecoderStream</code>对象， 即对输入流<code>in</code>进行解码。
	 * 
	 * @param in
	 *            待解码的输入流
	 */
	public BASE64DecoderStream(InputStream in) {
		super(in);
	}

	/**
	 * @see java.io.InputStream#available()
	 */
	@Override
	public int available() throws IOException {
		return ((in.available() * 3) / 4 + (bufsize - index));
	}

	/**
	 * @see java.io.InputStream#markSupported()
	 */
	@Override
	public boolean markSupported() {
		return false;
	}

	/**
	 * @see java.io.InputStream#read()
	 */
	@Override
	public int read() throws IOException {
		if (index >= bufsize) {
			decode(); // Fills up buffer
			if (bufsize == 0) // buffer is empty
				return -1;
			index = 0; // reset index into buffer
		}
		return buffer[index++] & 0xff; // Zero off the MSB
	}

	/**
	 * @see java.io.InputStream#read(byte[], int, int)
	 */
	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		int i, c;
		try {
			for (i = 0; i < len; i++) {
				if ((c = read()) == -1) {
					if (i == 0) // At end of stream, so we should
						i = -1; // return -1 , NOT 0.
					break;
				}
				b[off + i] = (byte) c;
			}
		} catch (IOException e) {
			i = -1;
		}

		return i;
	}

	private void decode() throws IOException {
		bufsize = 0;
		int i;
		// Skip CR,LF CRLF
		do {
			i = in.read();
			if (i == -1) {
				// End of stream
				return;
			}
		} while (i == '\n' || i == '\r');
		decode_buffer[0] = (byte) i;

		/*
		 * A BASE64 atom has 4 characters. We have obtained the the first
		 * character above (in i). Now, get the remaining 3 characters.
		 */
		int need = 3;
		int start = 1;
		int got;
		while ((got = in.read(decode_buffer, start, need)) != need) {
			// Need to do this looping to insure that we did get
			// 3 bytes !
			if (got == -1)
				throw new IOException("Error in encoded stream");
			need -= got;
			start += got;
		}

		byte a, b;
		a = detable[decode_buffer[0] & 0xff];
		b = detable[decode_buffer[1] & 0xff];
		// The first decoded byte
		buffer[bufsize++] = (byte) (((a << 2) & 0xfc) | ((b >>> 4) & 3));

		if (decode_buffer[2] == '=') // End of this BASE64 encoding
			return;
		a = b;
		b = detable[decode_buffer[2] & 0xff];
		// The second decoded byte
		buffer[bufsize++] = (byte) (((a << 4) & 0xf0) | ((b >>> 2) & 0xf));

		if (decode_buffer[3] == '=') // End of this BASE64 encoding
			return;
		a = b;
		b = detable[decode_buffer[3] & 0xff];
		// The third decoded byte
		buffer[bufsize++] = (byte) (((a << 6) & 0xc0) | (b & 0x3f));
	}

}
