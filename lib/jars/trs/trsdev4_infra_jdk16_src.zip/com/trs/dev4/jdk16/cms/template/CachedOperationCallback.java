package com.trs.dev4.jdk16.cms.template;

/**
 * 缓存操作模板的回调函数
 * 
 * @author yangyu
 * @since Mar 4, 2013 11:35:44 AM
 */
public abstract class CachedOperationCallback {

	/**
	 * 缓存中没有数据，需要从外部资源获取数据
	 * 
	 * 这个方法用于怎样从外部获取（大多是数据库）数据
	 * 
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public abstract Object doTakeCachingData();

}
