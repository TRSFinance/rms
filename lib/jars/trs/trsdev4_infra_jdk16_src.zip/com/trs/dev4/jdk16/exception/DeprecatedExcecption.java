/*
 * Created: liushen@Oct 12, 2010 1:11:24 PM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 用于强调已过期的方法. <br>
 * 
 */
@SuppressWarnings("serial")
public class DeprecatedExcecption extends RootException {

	public DeprecatedExcecption() {
		super(ExceptionUtil.getMainCaller());
	}

	/**
	 * @param msg
	 */
	public DeprecatedExcecption(String msg) {
		super(msg);
	}

	/**
	 * @param msg
	 * @param cause
	 */
	public DeprecatedExcecption(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param cause
	 */
	public DeprecatedExcecption(Throwable cause) {
		super(cause);
	}

}
