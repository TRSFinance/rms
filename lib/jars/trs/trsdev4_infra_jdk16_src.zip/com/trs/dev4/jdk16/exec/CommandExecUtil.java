/*
 * Created: fengjianhua@2009-3-26 上午09:51:52
 */
package com.trs.dev4.jdk16.exec;

import java.util.HashMap;
import java.util.Map;

import com.trs.dev4.jdk16.utils.EnvConst;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 执行命令行外部进程的工具类, 对 {@link ProcessHelper} 的便捷包装.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class CommandExecUtil {

	/**
	 * 执行给定的命令行，并获取其返回值和输出。
	 * 
	 * @param cmd
	 *            要执行的命令行
	 * @param workDir
	 *            在哪个目录执行该命令；如果为<code>null</code>或<code>""</code>则为JVM进程的当前工作路径.
	 * @param env
	 *            要补充的环境变量
	 * @return 执行结果
	 * @since liushen @ May 16, 2010
	 */
	public static ExecuteResult executeCommand(String cmd, String workDir,
			Map<String, String> env) {
		ProcessHelper ph = new ProcessHelper(cmd, workDir);
		ph.setEnv(env);
		ph.startAndWait();
		return new ExecuteResult(ph);
	}

	/**
	 * 执行给定的命令行，并获取其返回值和输出。
	 * 
	 * @param cmd
	 *            要执行的命令行
	 * @param workDir
	 *            在哪个目录执行该命令；如果为<code>null</code>或<code>""</code>则为JVM进程的当前工作路径.
	 * @param pathEnv
	 *            补充寻找可执行文件路径的环境变量(即PATH变量). 如果为<code>null</code>或
	 *            <code>""</code>则为该JVM进程设置(默认为操作系统设置). 暂不支持多个路径.
	 * @param libPathEnv
	 *            补充寻找库文件路径的环境变量(在Linux/Unix上即LD_LIBRARY_PATH变量；在Windows上待确认).
	 *            如果为<code>null</code>或<code>""</code>则为该JVM进程设置(默认为操作系统设置).
	 *            暂不支持多个路径.
	 * @return 执行结果
	 * @since liushen @ Jun 2, 2010
	 */
	public static ExecuteResult executeCommand(String cmd, String workDir,
			String pathEnv, String libPathEnv) {
		ProcessHelper ph = new ProcessHelper(cmd, workDir);
		Map<String, String> env = new HashMap<String, String>();
		if (false == StringHelper.isEmpty(pathEnv)) {
			env.put(EnvConst.PATH, pathEnv);
		}
		if (false == StringHelper.isEmpty(libPathEnv)) {
			env.put(EnvConst.LIBRARY_PATH_LINUX, libPathEnv);
		}
		ph.setEnv(env);
		ph.startAndWait();
		return new ExecuteResult(ph);
	}

	/**
	 * 执行给定的命令行，获取其返回值，但不获取输出。可能不适用于要较长时间执行的程序，因为可能会由于输出缓冲满了自动退出。
	 * 
	 * @param cmd
	 *            要执行的命令行
	 * @param workDir
	 *            在哪个目录执行该命令；如果为<code>null</code>则为JVM进程的当前工作路径。
	 * @param env
	 *            要补充的环境变量
	 * @return 执行结果
	 * @since liushen @ May 16, 2010
	 */
	public static ExecuteResult justWaitCommand(String cmd, String workDir,
			Map<String, String> env) {
		ProcessHelper ph = new ProcessHelper(cmd, workDir);
		ph.setEnv(env);
		ph.setOmitOutput(true);
		ph.startAndWait();
		return new ExecuteResult(ph);
	}

	/**
	 * 启动给定的命令行，但并不获取其返回值和输出；即不等待其执行结束，用于启动服务类进程。 不适用于要较长时间执行的程序，因为可能会由于输出缓冲满了自动退出（见JIRA TRSMAS-1033）。
	 * 
	 * @param cmd
	 *            要执行的命令行
	 * @param workDir
	 *            在哪个目录执行该命令；如果为<code>null</code>则为JVM进程的当前工作路径。
	 * @param env
	 *            要补充的环境变量
	 * @return 进程执行助手，可用于后续控制
	 * @since liushen @ May 16, 2010
	 */
	public static ProcessHelper justStartCommand(String cmd, String workDir,
			Map<String, String> env) {
		ProcessHelper ph = new ProcessHelper(cmd, workDir);
		ph.setEnv(env);
		return ph.startProcess();
	}

	/**
	 * @see #executeCommand(String, String, Map)
	 * @since liushen @ Jan 28, 2010
	 */
	public static ExecuteResult executeCommand(String cmd) {
		return executeCommand(cmd, null, null);
	}

	/**
	 * @see #executeCommand(String, String, Map)
	 * @since liushen @ Jan 28, 2010
	 */
	public static ExecuteResult executeCommand(String cmd, String workDir) {
		return executeCommand(cmd, workDir, null);
	}

}