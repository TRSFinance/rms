package com.trs.dev4.jdk16.cms.expression;

import com.trs.dev4.jdk16.cms.bo.ExpressionResult;
import com.trs.dev4.jdk16.cms.enu.ExpressionOperator;

/**
 * 用于解析FilterByField属性
 * 
 * @author yangyu
 * @since Mar 19, 2013 2:58:45 PM
 */
public class FilterByFieldTagExpression {

	private String key;

	private ExpressionOperator expressionOperator;

	private ExpressionResult expressionResult;

	private String searchString;

	public FilterByFieldTagExpression() {

	}

	/**
	 * @param expressionOperator
	 * @param expressionValue
	 * @param key
	 * @param searchString
	 */
	public FilterByFieldTagExpression(String key, ExpressionOperator expressionOperator, ExpressionResult expressionResult, String searchString) {
		super();
		this.expressionOperator = expressionOperator;
		this.expressionResult = expressionResult;
		this.key = key;
		this.searchString = searchString;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public ExpressionOperator getExpressionOperator() {
		return expressionOperator;
	}

	public void setExpressionOperator(ExpressionOperator expressionOperator) {
		this.expressionOperator = expressionOperator;
	}

	public ExpressionResult getExpressionResult() {
		return expressionResult;
	}

	public void setExpressionResult(ExpressionResult expressionResult) {
		this.expressionResult = expressionResult;
	}

	public String getSearchString() {
		return searchString;
	}

	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

}
