/*
 * Created: dujie@2011-10-12 下午04:15:33
 */
package com.trs.dev4.jdk16.verifycode.impl;

import javax.annotation.Resource;

import com.trs.dev4.jdk16.model.example.Captcha;
import com.trs.dev4.jdk16.verifycode.ICaptchaService;
import com.trs.dev4.jdk16.verifycode.IVerifyCodeProvider;

/**
 * 职责: <br>
 * 问答式验证码提供类实现
 */
public class QuestionAnswerVerifyCodeProvider implements IVerifyCodeProvider {

	@Resource(name = "captchaService")
	private ICaptchaService captchaService;
	/**
	 * @see com.trs.dev4.jdk16.verifycode.IVerifyCodeProvider#getRandomVerifyCode(int, java.lang.String)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public Captcha getRandomVerifyCode(int length, String verifyCodeType) {
		Captcha captcha = this.captchaService.getRandomCaptcha();
		return captcha;
	}
	/**
	 * @return the {@link #captchaService}
	 */
	public ICaptchaService getCaptchaService() {
		return captchaService;
	}

	/**
	 * @param captchaService
	 *            the {@link #captchaService} to set
	 */
	public void setCaptchaService(ICaptchaService captchaService) {
		this.captchaService = captchaService;
	}

}
