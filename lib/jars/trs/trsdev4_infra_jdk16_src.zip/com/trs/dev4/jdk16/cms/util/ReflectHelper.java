package com.trs.dev4.jdk16.cms.util;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.TreeSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.exp.TemplateException;

/**
 * 
 * 
 * @author yangyu
 * @since Jan 25, 2013 2:31:30 PM
 */
public class ReflectHelper {
	
	protected static Logger LOG = Logger.getLogger(ReflectHelper.class);
	
	@SuppressWarnings("unchecked")
	public static Class classForName(String name) throws ClassNotFoundException {
		try {
			ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
			if (contextClassLoader != null)
				return contextClassLoader.loadClass(name);
		} catch (Throwable t) {
		}
		return Class.forName(name);
	}

	@SuppressWarnings("unchecked")
	public static Class classForName(String name, Class caller) throws ClassNotFoundException {
		try {
			ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
			if (contextClassLoader != null)
				return contextClassLoader.loadClass(name);
		} catch (Throwable e) {
		}
		return Class.forName(name, true, caller.getClassLoader());
	}

	/**
	 * 获取给定对象的给定名称的field.
	 * 
	 * @param clazz
	 *            给定对象
	 * @param fieldName
	 *            要获取的field的名称
	 * @return 符合条件的field对象. 如不存在则返回<code>null</code>
	 * @creator liushen @ Jun 8, 2009
	 */
	public static Field getField(Class<?> clazz, String fieldName) {
		for (Class<?> superClass = clazz; superClass != Object.class; superClass = superClass.getSuperclass()) {
			try {
				return superClass.getDeclaredField(fieldName);
			} catch (Exception e) {
				// SecurityException, NoSuchFieldException
			}
		}
		throw new TemplateException("no such field: " + fieldName + " in " + clazz + " and it's super classes.");
	}


	@SuppressWarnings("unchecked")
	public static List<Class> listClassesInPackage(String packageName) {
		ArrayList<Class> classList = new ArrayList<Class>();
		try {
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			assert classLoader != null;
			String path = packageName.replace('.', '/');
			Enumeration<URL> resources = classLoader.getResources(path);
			List<String> dirs = new ArrayList<String>();
			while (resources.hasMoreElements()) {
				URL resource = resources.nextElement();
				dirs.add(URLDecoder.decode(resource.getFile(), "UTF-8"));
			}
			TreeSet<String> classes = new TreeSet<String>();
			for (String directory : dirs) {
				classes.addAll(findClasses(directory, packageName));
			}
			classList = new ArrayList<Class>();
			for (String clazz : classes) {
				classList.add(Class.forName(clazz));
			}
		} catch (Exception e) {
			LOG.error("not exist package");
		} 

		return classList;
	}

	private static TreeSet<String> findClasses(String path, String packageName) throws MalformedURLException,
			IOException {
		TreeSet<String> classes = new TreeSet<String>();
		if (path.startsWith("file:") && path.contains("!")) {
			String[] split = path.split("!");
			URL jar = new URL(split[0]);
			ZipInputStream zip = new ZipInputStream(jar.openStream());
			ZipEntry entry;
			while ((entry = zip.getNextEntry()) != null) {
				if (entry.getName().endsWith(".class")) {
					String className = entry.getName().replaceAll("[$].*", "").replaceAll("[.]class", "").replace('/',
							'.');
					if (className.startsWith(packageName)) {
						classes.add(className);
			}
		}
	}
		}
		File dir = new File(path);
		if (!dir.exists()) {
			return classes;
		}
		File[] files = dir.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				assert !file.getName().contains(".");
				classes.addAll(findClasses(file.getAbsolutePath(), packageName + "." + file.getName()));
			} else if (file.getName().endsWith(".class")) {
				String className = packageName + '.' + file.getName().substring(0, file.getName().length() - 6);
				classes.add(className);
			}
		}
		return classes;
	}
	
}
