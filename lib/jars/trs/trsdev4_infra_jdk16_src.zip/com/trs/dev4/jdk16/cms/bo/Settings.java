package com.trs.dev4.jdk16.cms.bo;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

import org.apache.commons.lang.StringUtils;

import com.trs.dev4.jdk16.cms.BaseurlExtractor;
import com.trs.dev4.jdk16.cms.CacheProvider;
import com.trs.dev4.jdk16.cms.CurrentUsernameExtractor;
import com.trs.dev4.jdk16.cms.FunctionExtractor;
import com.trs.dev4.jdk16.cms.PageLinkManager;
import com.trs.dev4.jdk16.cms.PageletsScheduler;
import com.trs.dev4.jdk16.cms.SiteManager;
import com.trs.dev4.jdk16.cms.TagAware;
import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.TemplateInterpreter;
import com.trs.dev4.jdk16.cms.TemplateManager;
import com.trs.dev4.jdk16.cms.cache.CachablePageLinkManager;
import com.trs.dev4.jdk16.cms.cache.CachableSiteManager;
import com.trs.dev4.jdk16.cms.core.PageletsSchedulerImpl;
import com.trs.dev4.jdk16.cms.core.TagAnalyser;
import com.trs.dev4.jdk16.cms.impl.NoBaseurlExtractor;
import com.trs.dev4.jdk16.cms.impl.NoCacheProvider;
import com.trs.dev4.jdk16.cms.tag.ParserConf;
import com.trs.dev4.jdk16.cms.template.CachedOperationTemplate;
import com.trs.dev4.jdk16.model.BaseEntity;

/**
 * 
 * 置标组件的全局配置
 * 
 * @author yangyu
 * @since Jan 24, 2013 2:07:31 PM
 */
public class Settings {

	/**
	 * 使用的TemplateManager
	 */
	private TemplateManager templateManager;

	/**
	 * 使用的SiteManager，置标组件会为其生成缓存代理
	 */
	private SiteManager siteManager;

	/**
	 * 使用的PageLinkManager，置标组件会为其生成缓存代理
	 */
	private PageLinkManager pageLinkManager;

	/**
	 * 使用的缓存操作类，默认为NoCacheProvider
	 */
	private CacheProvider cacheProvider;

	/**
	 * 使用的Pagelet解析引擎
	 */
	private PageletsScheduler pageletsScheduler;

	/**
	 * 多线程解析Pagelet的线程数
	 */
	private int threadPoolSize;

	/**
	 * 使用的BaseurlExtractor，用于找到站点资源路径，外部配置
	 */
	private BaseurlExtractor baseurlExtractor;

	/**
	 * 使用的CurrentUsernameExtractor，用于当前用户如何获取，外部配置
	 */
	private CurrentUsernameExtractor currentUsernameExtractor;

	/**
	 * 模板的解释器
	 */
	private TemplateInterpreter templateInterpreter;

	/**
	 * 缓存操作的模版
	 */
	private CachedOperationTemplate cachedOperationTemplate;

	/**
	 * PagelinkManager的缓存代理
	 */
	private CachablePageLinkManager cachablePageLinkManager;

	/**
	 * siteManager的缓存代理
	 */
	private CachableSiteManager cachableSiteManager;
	/**
	 * 置标表达式的函数抽取类
	 */
	private FunctionExtractor functionExtractor;

	/**
	 * 模板校验
	 */
	private TagAnalyser tagAnalyser;

	/**
	 * pagelink可以包括的参数，比如list.do?action=...或者list.do?method=...中的action和method
	 */
	private String methodPart;

	/**
	 * 置标组件中所使用的所有标签
	 */
	private Map<String, TagParser> tagParsers = new ConcurrentHashMap<String, TagParser>();

	/**
	 * 
	 */
	private Map<String, ParserConf> parserConfs = new ConcurrentHashMap<String, ParserConf>();

	/**
	 * 置标组件中所使用的所有数据源
	 */
	private Map<String, TagAware<? extends BaseEntity>> tagAwares = new ConcurrentHashMap<String, TagAware<? extends BaseEntity>>();

	private Map<String, TagAware<?>> cachableTagAwares = new ConcurrentHashMap<String, TagAware<?>>();

	/**
	 * 存储可以缓存解析结果的标签，这类标签因为会话不同而影响解析结果
	 */
	private Set<String> cachableSet = new CopyOnWriteArraySet<String>();

	/**
	 * 
	 */
	public Settings() {
		cacheProvider = new NoCacheProvider();
		pageletsScheduler = new PageletsSchedulerImpl();
		cachedOperationTemplate = new CachedOperationTemplate();
		cachablePageLinkManager = new CachablePageLinkManager();
		cachableSiteManager = new CachableSiteManager();
		baseurlExtractor = new NoBaseurlExtractor();
		tagAnalyser = new TagAnalyser();
		methodPart = "method";
	}

	public CacheProvider getCacheProvider() {
		return cacheProvider;
	}

	public void setCacheProvider(CacheProvider cacheProvider) {
		this.cacheProvider = cacheProvider;
	}

	public int getThreadPoolSize() {
		return threadPoolSize;
	}

	public void setThreadPoolSize(int threadPoolSize) {
		this.threadPoolSize = threadPoolSize;
	}

	public BaseurlExtractor getBaseurlExtractor() {
		return baseurlExtractor;
	}

	public void setBaseurlExtractor(BaseurlExtractor baseurlExtractor) {
		this.baseurlExtractor = baseurlExtractor;
	}

	public PageletsScheduler getPageletsScheduler() {
		return pageletsScheduler;
	}

	public void setPageletsScheduler(PageletsScheduler pageletsScheduler) {
		this.pageletsScheduler = pageletsScheduler;
	}

	public TemplateManager getTemplateManager() {
		return templateManager;
	}

	public void setTemplateManager(TemplateManager templateManager) {
		this.templateManager = templateManager;
	}

	public SiteManager getSiteManager() {
		return siteManager;
	}

	public void setSiteManager(SiteManager siteManager) {
		this.siteManager = siteManager;
	}

	public PageLinkManager getPageLinkManager() {
		return pageLinkManager;
	}

	public void setPageLinkManager(PageLinkManager pageLinkManager) {
		this.pageLinkManager = pageLinkManager;
	}

	/**
	 * @return the {@link #templateInterpreter}
	 */
	public TemplateInterpreter getTemplateInterpreter() {
		return templateInterpreter;
	}

	/**
	 * @param templateHandller
	 *            the {@link #templateInterpreter} to set
	 */
	public void setTemplateHandller(TemplateInterpreter templateHandller) {
		this.templateInterpreter = templateHandller;
	}

	public CachedOperationTemplate getCachedOperationTemplate() {
		return cachedOperationTemplate;
	}

	public void setCachedOperationTemplate(CachedOperationTemplate cachedOperationTemplate) {
		this.cachedOperationTemplate = cachedOperationTemplate;
	}

	public CachablePageLinkManager getCachablePageLinkManager() {
		return cachablePageLinkManager;
	}

	public void setCachablePageLinkManager(CachablePageLinkManager cachablePageLinkManager) {
		this.cachablePageLinkManager = cachablePageLinkManager;
	}

	public CachableSiteManager getCachableSiteManager() {
		return cachableSiteManager;
	}

	public void setCachableSiteManager(CachableSiteManager cachableSiteManager) {
		this.cachableSiteManager = cachableSiteManager;
	}

	public Map<String, TagParser> getTagParsers() {
		return tagParsers;
	}

	public TagParser getTagParser(String key) {
		return tagParsers.get(key);
	}

	public void setTagParsers(Map<String, TagParser> tagParsers) {
		this.tagParsers = tagParsers;
	}

	/**
	 * 根据obj的值获取TagAware
	 * 
	 * @param obj
	 * @return
	 */
	public TagAware<?> getTagAware(String obj) {
		return tagAwares.get(StringUtils.upperCase(obj));
	}

	/**
	 * @return the tagAwares
	 */
	public Map<String, TagAware<? extends BaseEntity>> getTagAwares() {
		return tagAwares;
	}

	/**
	 * @param tagAwares
	 *            the tagAwares to set
	 */
	public void setTagAwares(Map<String, TagAware<? extends BaseEntity>> tagAwares) {
		this.tagAwares = tagAwares;
	}

	public FunctionExtractor getFunctionExtractor() {
		return functionExtractor;
	}

	public void setFunctionExtractor(FunctionExtractor functionExtractor) {
		this.functionExtractor = functionExtractor;
	}

	public void setCurrentUsernameExtractor(CurrentUsernameExtractor currentUsernameExtractor) {
		this.currentUsernameExtractor = currentUsernameExtractor;
	}

	public CurrentUsernameExtractor getCurrentUsernameExtractor() {
		return currentUsernameExtractor;
	}

	/**
	 * @return
	 * @since yangyu @ Mar 28, 2013
	 */
	public String getMethodPart() {
		return methodPart;
	}

	public void setMethodPart(String methodPart) {
		this.methodPart = methodPart;
	}

	public TagAnalyser getTagAnalyser() {
		return tagAnalyser;
	}

	public void setTagAnalyser(TagAnalyser tagAnalyser) {
		this.tagAnalyser = tagAnalyser;
	}

	/**
	 * @return the {@link #cachableTagAwares}
	 */
	public Map<String, TagAware<?>> getCachableTagAwares() {
		return cachableTagAwares;
	}

	/**
	 * @param cachableTagAwares
	 *            the {@link #cachableTagAwares} to set
	 */
	public void setCachableTagAwares(Map<String, TagAware<?>> cachableTagAwares) {
		this.cachableTagAwares = cachableTagAwares;
	}

	/**
	 * @return
	 * @since yangyu @ Aug 12, 2013
	 */
	public Set<String> getCachableTags() {
		return cachableSet;
	}

	/**
	 * @param tagItem
	 * @return
	 * @since Administrator @ 2013-11-12
	 */
	public boolean isCachedTag(TagItem tagItem) {
		return cachableSet.contains(tagItem.getName());
	}

	/**
	 * @param parserConfs
	 *            the {@link #parserConfs} to set
	 */
	public void setParserConfs(Map<String, ParserConf> parserConfs) {
		this.parserConfs = parserConfs;
	}

	/**
	 * @param name
	 * @return
	 * @since Administrator @ 2013-12-6
	 */
	public ParserConf getParserConfig(String name) {
		return parserConfs.get(name);
	}

	/**
	 * @param tagParser
	 * @since Administrator @ 2013-12-6
	 */
	public void addCachableTagParser(String tagParserName) {
		cachableSet.add(tagParserName);
	}
}
