package com.trs.dev4.jdk16.cms.exp;

/**
 * 当前模板不存在的异常
 * 
 * @author yangyu
 * @since Jan 31, 2013 4:32:37 PM
 */
public class CurrentTemplateNotFoundException extends TemplateException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CurrentTemplateNotFoundException(String mesg) {
		super(mesg);
	}


}
