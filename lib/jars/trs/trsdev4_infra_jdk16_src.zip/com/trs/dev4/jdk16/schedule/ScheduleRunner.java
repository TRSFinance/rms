/*
 * Created: liushen@May 5, 2011 7:33:23 PM
 */
package com.trs.dev4.jdk16.schedule;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.schedule.RunCondition.Type;
import com.trs.dev4.jdk16.utils.ObjectUtil;

/**
 * 运行器, 负责执行并统计运行情况. <br>
 * 
 */
public class ScheduleRunner implements Runnable {

	private static final Logger LOG = Logger.getLogger(ScheduleRunner.class);

	/**
	 * 运行状态.<br>
	 */
	public static enum RunStatus {
		/**
		 * .
		 */
		IDLE,
		/**
		 * 
		 */
		RUNNING;
	}

	private ISchedulable schedulable;

	// ISchedulerListener listener;

	private RunStatus status = RunStatus.IDLE;

	private long failureTimes;

	private long successTimes;

	private long currRunTimestamp;

	private long lastRunTimestamp;

	private long lastRunDuration;

	private long maxDuration;

	/**
	 * 实际运行时间最长的那次的时刻；该时刻为开始时刻。
	 */
	private long maxDurationTimestamp;

	/**
	 * 
	 * 触发运行的条件。
	 */
	private RunCondition runCondition;

	private Throwable lastException;

	private long lastErrorTimestamp;

	/**
	 * 
	 */
	ScheduleRunner(ISchedulable schedulable, int fixedDelaySeconds) {
		this.schedulable = schedulable;
		// 兼容：以前只有固定间隔，且时间单位固定为秒
		this.runCondition = new RunCondition(Type.FIXEDDELAY, fixedDelaySeconds, TimeUnit.SECONDS);
	}

	/**
	 * @param schedulable
	 * @param runCondition
	 */
	ScheduleRunner(ISchedulable schedulable, RunCondition runCondition) {
		this.schedulable = schedulable;
		this.runCondition = runCondition;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public String getDisplayName() {
		return schedulable.getDisplayName();
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public String getSchedulabeClassName() {
		return schedulable.getClass().getName();
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public boolean isRunning() {
		return RunStatus.RUNNING.equals(status);
	}

	/**
	 * @return the {@link #runCondition}
	 */
	public RunCondition getRunCondition() {
		return runCondition;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public long getLastRunDuration() {
		return lastRunDuration;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public long getLastRunTimestamp() {
		return lastRunTimestamp;
	}

	/**
	 * 获取下次运行的时刻(估计值)，为毫秒数。
	 * 
	 * @since liushen @ May 5, 2011
	 */
	public long getNextRunTimestamp() {
		// 固定间隔需要增加一次运行的时间
		if (runCondition.isAtFixedRate()) {
			return currRunTimestamp + runCondition.getFixedDeltaAsMilliSeconds();
		} else {
			return currRunTimestamp + lastRunDuration + runCondition.getFixedDeltaAsMilliSeconds();
		}
	}

	/**
	 * 
	 * @since liushen @ May 5, 2011
	 */
	public long getSuccessTimes() {
		return successTimes;
	}

	/**
	 * 
	 * @since liushen @ May 5, 2011
	 */
	public long getRanTimes() {
		return successTimes + failureTimes;
	}

	/**
	 * 
	 * @since liushen @ May 5, 2011
	 */
	public long getFailureTimes() {
		return failureTimes;
	}

	/**
	 * 
	 * @since liushen @ May 5, 2011
	 */
	public long getMaxDuration() {
		return maxDuration;
	}

	/**
	 * @see java.lang.Runnable#run()
	 * @since liushen @ May 5, 2011
	 */
	@Override
	public void run() {
		status = RunStatus.RUNNING;
		currRunTimestamp = System.currentTimeMillis();
		try {
			schedulable.runOnce();
			successTimes++;
		} catch (Throwable t) {
			lastErrorTimestamp = System.currentTimeMillis();
			failureTimes++;
			lastException = t;
			LOG.error("error in this turn of " + schedulable, t);
		}
		lastRunDuration = getCurrEstimated();
		lastRunTimestamp = currRunTimestamp;
		status = RunStatus.IDLE;
		if (maxDuration < lastRunDuration) {
			maxDuration = lastRunDuration;
			maxDurationTimestamp = currRunTimestamp;
		}
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 6, 2011
	 */
	public long getCurrEstimated() {
		return System.currentTimeMillis() - currRunTimestamp;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 * @since liushen @ May 5, 2011
	 */
	@Override
	public boolean equals(Object obj) {
		if (false == obj instanceof ScheduleRunner) {
			return false;
		}
		ScheduleRunner another = (ScheduleRunner) obj;
		return ObjectUtil.equals(schedulable, another.schedulable);
	}

	/**
	 * @return the {@link #schedulable}
	 */
	public ISchedulable getSchedulable() {
		return schedulable;
	}

	/**
	 * @return the {@link #lastException}
	 */
	public Throwable getLastException() {
		return lastException;
	}

	/**
	 * @return the {@link #lastErrorTimestamp}
	 */
	public long getLastErrorTimestamp() {
		return lastErrorTimestamp;
	}

	/**
	 * @return the {@link #maxDurationTimestamp}
	 */
	public long getMaxDurationTimestamp() {
		return maxDurationTimestamp;
	}

}
