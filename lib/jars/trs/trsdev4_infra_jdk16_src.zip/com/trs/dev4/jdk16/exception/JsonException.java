/*
 * Created: liushen@Mar 31, 2011 8:18:00 PM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 表示JSON处理错误; Json小写是为了区别于各JSON类库. <br>
 * 
 */
@SuppressWarnings("serial")
public class JsonException extends RootException {

	/**
	 * @param msg
	 */
	public JsonException(String msg) {
		super(msg);
	}

	/**
	 * @param msg
	 * @param cause
	 */
	public JsonException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param cause
	 */
	public JsonException(Throwable cause) {
		super(cause);
	}

}
