package com.trs.dev4.jdk16.cms.tag;

import java.util.List;

import com.trs.dev4.jdk16.cms.TagAware;
import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.cms.expression.FilterByFieldTagExpression;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;
import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * TRS_OBJECT标签
 * 
 * @author yangyu
 * @since Mar 8, 2013 5:15:29 PM
 */
public class ObjectTagParser implements TagParser {

	public String parse(final TagContext tagContext) {

		Object object = null;

		TagAware<?> tagAware = tagContext.getTagAware("obj");
		if (tagContext.existAttribute("id")) {
			object = tagAware.getPublishObjectById(tagContext.getIntFunctionValue("id"));
		} else if (tagContext.existAttribute("filterByField")) {
			
			SearchFilter searchFilter = SearchFilter.getDefault();
			List<FilterByFieldTagExpression> filterByFieldTagExpressions = tagContext.getFilterByFieldValues("filterByField");
			for (FilterByFieldTagExpression filterByFieldTagExpression : filterByFieldTagExpressions) {
				filterByFieldTagExpression.getExpressionOperator().buildSearchFilter(searchFilter, filterByFieldTagExpression);
			}
			object = tagAware.getPublishObject(searchFilter);
		} else {
			throw new TemplateException("OBJECT标签需要指定id或者filterByfield属性任意一个", tagContext);
		}

		if (object != null) {
			return TagExpressionHelper.parseInternalTemplate(tagContext, new PublishObject(object));
		} else {
			return "";
		}

	}

	public String getTagName() {
		return "TRS_OBJECT";
	}

}
