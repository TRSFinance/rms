package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.RequestWrapper;
import com.trs.dev4.jdk16.cms.bo.Site;

/**
 * 映射管理统一接口
 * 
 * @author yangyu
 * @since Jan 16, 2013 3:18:05 PM
 */
public interface PageLinkManager {

	/**
	 * 根据传入的HttpRequest请求，获取当前站点下与之对应的PageLink映射
	 * 
	 * 置标组件会自己缓存PageLink映射
	 * 
	 * @param site
	 *            当前站点
	 * @param requestWrapper
	 *            httpRequest请求封装
	 * @param actionMethodParam
	 *            可识别的请求method标识
	 * 
	 * @return 当前请求对应的PageLink映射
	 * 
	 */
	PageLink getFromRequestURI(Site site, RequestWrapper requestWrapper, String actionMethodParam);

	/**
	 * 增加新的映射，如果是当前站点下的映射，添加到缓存
	 * 
	 * @param pageLink
	 * @return
	 */
	int addNew(PageLink pageLink);

	/**
	 * 更新映射，如果是当前站点下的映射，更新缓存对应值
	 * 
	 * @param pageLink
	 * @return
	 */
	void update(PageLink pageLink);

	/**
	 * 如果是当前站点下的映射，删除缓存中的数据
	 * 
	 * @param pageLink
	 * @return
	 */
	void delete(PageLink pageLink);

	/**
	 * @param siteId
	 * @param name
	 * @return
	 * @since yangyu @ Aug 7, 2013
	 */
	PageLink get(int siteId, String name);

}
