package com.trs.dev4.jdk16.cms.cache;

import com.trs.dev4.jdk16.cms.CacheProvider;
import com.trs.dev4.jdk16.cms.PageLinkManager;
import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.RequestWrapper;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.cms.template.CachedOperationCallback;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * PageLink缓存代理类，为PagelinkManager实现类添加缓存功能
 * 
 * @author yangyu
 * @since Mar 5, 2013 5:14:15 PM
 */
public class CachablePageLinkManager implements PageLinkManager {

	private CacheProvider cacheProvider;

	private PageLinkManager pageLinkManager;

	private Settings settings;

	@Override
	public int addNew(PageLink pageLink) {
		int times = pageLinkManager.addNew(pageLink);
		cacheProvider.set(this.getCacheKey(pageLink.getSiteId(), pageLink.getUrlPattern()), pageLink);
		return times;
	}
	@Override
	public void delete(PageLink pageLink) {
		pageLinkManager.delete(pageLink);
		cacheProvider.remove(getCacheKey(pageLink.getSiteId(), pageLink.getUrlPattern()));
	}

	@Override
	public PageLink getFromRequestURI(final Site site, final RequestWrapper requestWrapper, String actionMethodParam) {
		return (PageLink) settings.getCachedOperationTemplate().obtainCachedData(
				getCacheKey(site.getId(), requestWrapper.getRequestURI()
						+ parseSpringMultiActionMethodPart(requestWrapper, actionMethodParam)), 30,
				new CachedOperationCallback() {
			@Override
			public Object doTakeCachingData() {
				return pageLinkManager.getFromRequestURI(site, requestWrapper, settings.getMethodPart());
			}
		});
	}

	private String parseSpringMultiActionMethodPart(RequestWrapper requestWrapper, String actionMethodParam) {
		if (StringHelper.isEmpty(actionMethodParam)) {
			return null;
		}

		String actionMethodValue = requestWrapper.getParameter(actionMethodParam);
		if (StringHelper.isEmpty(actionMethodValue)) {
			return null;
		}
		return "?" + actionMethodParam + "=" + actionMethodValue;
	}
	
	@Override
	public void update(PageLink pageLink) {
		pageLinkManager.update(pageLink);
		cacheProvider.set(this.getCacheKey(pageLink.getSiteId(), pageLink.getUrlPattern()), pageLink);
	}


	public void setSettings(Settings settings) {
		this.setCacheProvider(settings.getCacheProvider());
		this.setPageLinkManager(settings.getPageLinkManager());
		this.settings = settings;
	}

	/**
	 * 构造缓存键值
	 * 
	 * @param siteId
	 * @param requestURI
	 * @return
	 * @since yangyu @ Aug 7, 2013
	 */
	private String getCacheKey(int siteId, String requestURI) {
		return "Pagelink_Site_" + siteId + "_RequestURI_" + requestURI;
	}

	public void setCacheProvider(CacheProvider cacheProvider) {
		this.cacheProvider = cacheProvider;
	}

	public void setPageLinkManager(PageLinkManager pageLinkManager) {
		this.pageLinkManager = pageLinkManager;
	}
	/**
	 * @see com.trs.dev4.jdk16.cms.PageLinkManager#get(int, java.lang.String)
	 * @since yangyu @ Aug 7, 2013
	 */
	@Override
	public PageLink get(int siteId, String name) {
		return pageLinkManager.get(siteId, name);
	}
}
