package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.bo.Settings;

/**
 * 用于创建GeneratorSession，应用中用且只有一个GeneratorSessionFactory
 * 
 * 每个请求线程从GeneratorSessionFactory获取GeneratorSession，
 * 
 * 并将全局的配置信息Settings交个每个创建的GeneratorSession
 * 
 * @author yangyu
 * @since Feb 19, 2013 9:39:48 AM
 */
public interface GeneratorSessionFactory {

	/**
	 * 用于创建GeneratorSession，应用中用且只有一个GeneratorSessionFactory
	 * 
	 * 每个请求线程从GeneratorSessionFactory获取GeneratorSession
	 * 
	 * @return
	 * @since yangyu @ Apr 11, 2013
	 */
	GeneratorSession getCurrentSession();

	/**
	 * 获取组件全局配置信息Settings
	 * 
	 * @return
	 * @since yangyu @ Apr 11, 2013
	 */
	Settings getSettings();

}
