/*
 * Created: liushen@Mar 17, 2009 11:06:02 AM
 */
package com.trs.dev4.jdk16.dao.hb3;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.id.IdentifierGenerator;
import org.hibernate.jmx.StatisticsService;
import org.hibernate.metadata.ClassMetadata;

import com.trs.dev4.jdk16.utils.JMXUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * Hibernate 3工具类.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class Hb3Util {

	/**
	 * Convenience method to return the int value that matches the query.
	 * @param qry the Hibernate Query Object. must not be null.
	 * @return the int value or <tt>-1</tt> if the query returns no results.
	 * @throws HibernateException if there is more than one matching result
	 * @see Query#uniqueResult()
	 */
	@SuppressWarnings("rawtypes")
	public static int uniqueResultAsInt(Query qry) {
		List results = qry.list();
	    if (results == null || results.size() == 0) {
	        return 0;
	    }
	    int result = 0;
	    Object obj;
	    for (Iterator iter = results.iterator(); iter.hasNext();) {
	        obj = iter.next();
	        // ls@07-1118 在32位mysql 5/JDK6@Win2k3上，hibernate 3.2.5执行select
			// count(*) from 某个表(只有几条记录)的返回结果是Long, 所以需要转型为Number!
	        if (obj instanceof Number) {
	            result += ((Number) obj).intValue();
	        }
	    }
	    return result;
	
	}

	/**
	 * Convenience method to return the int value that matches the query.
	 * @param qry the Hibernate Query Object. must not be null.
	 * @return the int value or <tt>-1</tt> if the query returns no results.
	 * @throws HibernateException if there is more than one matching result
	 * @see Query#uniqueResult()
	 */
	@SuppressWarnings("rawtypes")
	public static long uniqueResultAsLong(Query qry) {
	    List results = qry.list();
	    if (results == null || results.size() == 0) {
	        return 0;
	    }
	    long result = 0;
	    Object obj;
	    for (Iterator iter = results.iterator(); iter.hasNext();) {
	        obj = iter.next();
	        if (obj instanceof Number) {
	            result += ((Number) obj).longValue();
	        }
	    }
	    return result;
	}

	/**
	 * 回滚事务.
	 * 
	 * @param tx
	 *            待回滚的事务
	 */
	public static void rollback(Transaction tx) {
	    if (tx != null) {
	    	tx.rollback();
	    }
	}

	/**
	 * 获取所有由Hibernate持久的实体类的映射元数据.
	 * 
	 * @since liushen @ Mar 22, 2010
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, ClassMetadata> getAllEntityClassMetadata(
			SessionFactory sf) {
		return sf.getAllClassMetadata();
	}

	/**
	 * @param sessionFactory
	 * @param rootEntityName
	 * @return
	 * @since liushen @ Jun 23, 2010
	 */
	public static IdentifierGenerator getIdGenerator(
			SessionFactory sessionFactory, String rootEntityName) {
		// AssertUtil.instanceOf(sessionFactory, );
		if (false == sessionFactory instanceof SessionFactoryImplementor) {
			throw new IllegalArgumentException("this sessionFactory ["
					+ sessionFactory + "] not a ["
					+ SessionFactoryImplementor.class.getName() + "] instance.");
		}
		SessionFactoryImplementor sfImpl = (SessionFactoryImplementor) sessionFactory;
		return sfImpl.getIdentifierGenerator(rootEntityName);
	}

	/**
	 * 
	 * @param qry
	 * @return
	 * @since liushen @ Feb 13, 2012
	 */
	public static String getQueryInfoForDump(Query qry) {
		if (qry == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder(128);
		sb.append(qry.getClass().getName()).append("@").append(Integer.toHexString(qry.hashCode()));
		sb.append(": queryString: ").append(qry.getQueryString());
		sb.append("; NamedParameters: ").append(StringHelper.toString(qry.getNamedParameters(), true)).append(".");
		return sb.toString();
	}

	/**
	 * Register this MBean in your JMX server for a specific session factory；
	 * 技术细节参见org.hibernate.jmx.StatisticsService的Javadoc。
	 * 
	 * @since liushen @ Feb 28, 2013
	 */
	public static void registerStatMBean(SessionFactory sessionFactory) {
		// build the ObjectName you want
		Hashtable<String, String> tb = new Hashtable<String, String>();
		tb.put("type", "statistics");
		tb.put("sessionFactory", "hbSF");

		StatisticsService stats = new StatisticsService();
		stats.setSessionFactory(sessionFactory);
		// server.registerMBean(stats, on);
		// Hibernate:application=Statistics
		JMXUtil.registerMBean("Hibernate", tb, stats);
	}

}
