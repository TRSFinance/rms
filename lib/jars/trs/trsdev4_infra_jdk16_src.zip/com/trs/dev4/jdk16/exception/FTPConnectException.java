/*
 * Created: liushen@Jul 17, 2013 1:12:27 PM
 */
package com.trs.dev4.jdk16.exception;

/**
 * FTP网络连接方面的异常。<br>
 * 
 */
@SuppressWarnings("serial")
public class FTPConnectException extends FTPException {

	/**
	 * @param msg
	 * @param cause
	 */
	public FTPConnectException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public FTPConnectException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public FTPConnectException(Throwable cause) {
		super(cause);
	}

}
