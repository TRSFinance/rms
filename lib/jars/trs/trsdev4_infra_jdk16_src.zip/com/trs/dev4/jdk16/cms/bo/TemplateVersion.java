package com.trs.dev4.jdk16.cms.bo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Parameter;

/**
 * 用于描述模板历史版本
 */
@Entity
@Table(name = "trsTemplateVersion")
@org.hibernate.annotations.GenericGenerator(name = "idStrategy", strategy = "native", parameters = { @Parameter(name = "sequence", value = "SEQ_TEMPLATE_VERSION_ID") })
public class TemplateVersion extends Template {

	/**
	 * 对应模板的ID
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 23, 2012
	 */
	@Column(name = "`templateId`")
	private int templateId;

	/**
	 * 是否已删
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 23, 2012
	 */
	@Column(name = "`isDeleted`")
	private boolean isDeleted;

	/**
	 * 修改模板的备注
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 23, 2012
	 */
	@Column(name = "`comment`")
	private String comment;

	/**
	 * 版本号。从1开始记录，记录正整数
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 23, 2012
	 */
	@Column(name = "`version`")
	private int version;
	/**
	 * @since TRS @ Feb 16, 2011
	 */
	private static final long serialVersionUID = 1L;

	// 构造函数
    public TemplateVersion() {
        super();
    }

	/**
	 * 通过模板构造模板版本
	 * 
	 * @param template
	 *            模板，参见{@link Template}
	 */
	public TemplateVersion(Template template) {
		super.setName(template.getName());
		super.setContent(template.getContent());
		super.setObjectId(template.getObjectId());
		super.setSize(template.getSize());
		this.createdTime = System.currentTimeMillis();
		this.templateId = template.getId();
		this.createdUser = template.getLastModifiedUser();
		this.createdUserId = template.getLastModifiedUserId();
		this.isDeleted = false;
	}

	/**
	 * @return the {@link #templateId}
	 */
	public int getTemplateId() {
		return templateId;
	}

	/**
	 * @param templateId
	 *            the {@link #templateId} to set
	 */
	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	/**
	 * @return the {@link #isDeleted}
	 */
	public boolean isDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted
	 *            the {@link #isDeleted} to set
	 */
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the {@link #comment}
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment
	 *            the {@link #comment} to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the {@link #version}
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version
	 *            the {@link #version} to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}
	
}