/**
 * SimpleNode.java. created on 2006-6-1  
 */
package com.trs.dev4.jdk16.xml.node;

import com.trs.dev4.jdk16.xml.AbstractNode;


/**
 * 简单的Node，不能包含子Node。
 * 
 * 
 * @author liu kaixuan
 * @date 2006-6-1 16:28:50
 */
public class SimpleNode extends AbstractNode {
	protected String nodeValue ;
	
	private boolean CDATANeeded = false ;
		
	/**
	 * @param nodeName 节点名称
	 * @param nodeValue 节点值，可以为空
	 */
	public SimpleNode(String nodeName, String nodeValue){
		super(nodeName) ;
		this.nodeValue = nodeValue ;
		CDATANeeded = true ;
	}
	
	/**
	 * @param nodeName 节点名称
	 * @param nodeValue 节点值，可以为空
	 * @param CDATANeeded 是否需要添加CDATA标记。
	 */
	public SimpleNode(String nodeName, String nodeValue, boolean CDATANeeded){
		super(nodeName) ;
		this.nodeValue = nodeValue ;
		this.CDATANeeded = CDATANeeded ;
	}
	
	/**
	 * @param nodeName 节点名称
	 * @param nodeValue 节点值
	 */
	public SimpleNode(String nodeName, int nodeValue){
		super(nodeName) ;
		this.nodeValue = String.valueOf(nodeValue) ;
		CDATANeeded = false ;
	}
	
	protected boolean hasNodeValue(){
		return nodeValue != null && nodeValue.length() > 0 ;
	}
	
	protected String getNodeValue(){
		if(!CDATANeeded){
			return nodeValue ;
		}else{
			StringBuffer sb = new StringBuffer(nodeValue.length() + 20) ;
			sb.append("<![CDATA[").append(nodeValue).append("]]>") ;
			
			return sb.toString() ;
		}
	}

	public boolean isCDATANeeded() {
		return CDATANeeded;
	}

	/**设置是否在产生xml串时添加CDATA*/
	public void setCDATANeeded(boolean needed) {
		CDATANeeded = needed;
	}

	public void setNodeValue(String nodeValue) {
		this.nodeValue = nodeValue;
	}	

}
