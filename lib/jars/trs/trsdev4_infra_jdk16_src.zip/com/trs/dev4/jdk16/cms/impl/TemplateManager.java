/*
 * Created: TRS@Feb 16, 2011 9:12:39 PM
 */
package com.trs.dev4.jdk16.cms.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.ITemplateManager;
import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.cms.bo.Template;
import com.trs.dev4.jdk16.cms.bo.TemplateDocument;
import com.trs.dev4.jdk16.cms.bo.TemplateVersion;
import com.trs.dev4.jdk16.cms.exp.CurrentTemplateNotFoundException;
import com.trs.dev4.jdk16.dao.HQLBuilder;
import com.trs.dev4.jdk16.dao.IAccessor;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.BaseManager;

/**
 * 用于模板{@link ITemplate}管理
 * 
 */
public class TemplateManager extends BaseManager<Template> implements
		ITemplateManager {
	/**
	 * 
	 */
	private Map<String, Template> templates = new HashMap<String, Template>();

	private IAccessor<TemplateVersion> templateVersionAccessor;
	
	protected static Logger LOG = Logger.getLogger(TemplateManager.class);

	/**
	 * @param pageLink
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#getTemplate(java.lang.String)
	 * @since TRS @ Feb 16, 2011
	 */
	@Override
	public Template getTemplate(String templateName, PageLink pageLink) {
		Template template = templates.get(templateName);
		if (template == null) {
			SearchFilter sf = SearchFilter.getDefault();
			sf.addEqCondition("name", templateName);
			sf.addEqCondition("objectId", pageLink.getSiteId());
			sf.setOrderBy("objectId desc");
			template = super.findFirst(sf);
		}
		return template;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#parseTemplateDocument(java.lang.String)
	 * @since TRS @ Feb 16, 2011
	 */
	@Override
	public TemplateDocument parseTemplateDocument(String templateContent) {
		return new TemplateDocument(templateContent);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#getTemplateByObjectType(java.lang.String,
	 *      int)
	 */
	@Override
	public Template getTemplateByObjectType(String objectType, int objectId) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("objectType", objectType);
		sf.addEqCondition("objectId", objectId);
		return super.findFirst(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#addTemplateVersion(com.trs.dev4.jdk16.cms.bo.Template)
	 * @since TRS信息技术股份有限公司 @ Oct 25, 2012
	 */
	@Override
	public TemplateVersion addTemplateVersion(Template template) {
		TemplateVersion templateVersion = new TemplateVersion(template);
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("templateId", template.getId());
		templateVersion.setVersion(templateVersionAccessor.total(sf) + 1);
		templateVersionAccessor.insert(templateVersion);
		return templateVersion;
	}

	/**
	 * @return the {@link #templateVersionAccessor}
	 */
	public IAccessor<TemplateVersion> getTemplateVersionAccessor() {
		return templateVersionAccessor;
	}

	/**
	 * @param templateVersionAccessor
	 *            the {@link #templateVersionAccessor} to set
	 */
	public void setTemplateVersionAccessor(IAccessor<TemplateVersion> templateVersionAccessor) {
		this.templateVersionAccessor = templateVersionAccessor;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#pagedVersions(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since TRS信息技术股份有限公司 @ Oct 25, 2012
	 */
	@Override
	public PagedList<TemplateVersion> pagedVersions(SearchFilter sf) {
		return this.templateVersionAccessor.pagedObjects(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#batchUpdateVersion(com.trs.dev4.jdk16.dao.HQLBuilder)
	 * @since TRS信息技术股份有限公司 @ Oct 25, 2012
	 */
	@Override
	public int batchUpdateVersion(HQLBuilder builder) {
		return this.templateVersionAccessor.batchUpdate(builder);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#getTemplateVersion(int)
	 * @since TRS信息技术股份有限公司 @ Oct 25, 2012
	 */
	@Override
	public TemplateVersion getTemplateVersion(int id) {
		return this.templateVersionAccessor.getObject(id);
	}

	@Override
	public int addNew(Template template) {
		int result = super.addNew(template);
		addTemplateVersion(template);
		return result;
	}

	@Override
	public void update(Template template) {
		super.update(template);
		addTemplateVersion(template);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#getFormPageLink(com.trs.dev4.jdk16.cms.bo.PageLink)
	 * @since yangyu @ Nov 29, 2012
	 */
	@Override
	public Template getFormPageLink(PageLink pageLink) {
		String templateName = pageLink.getTemplateName();
		int siteId = pageLink.getSiteId();
		Template template = getBySiteAndTemplateName(templateName, siteId);
		if (template == null) {
			
			throw new CurrentTemplateNotFoundException("映射（" + pageLink.getName() + "）相应模板不存在");
		}
		return template;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#getTemplateDocument(java.lang.String,
	 *      int)
	 * @since yangyu @ Nov 30, 2012
	 */
	@Override
	public TemplateDocument getTemplateDocument(String templateName, int siteId) {
		Template template = getBySiteAndTemplateName(templateName, siteId);
		return new TemplateDocument(template.getContent());
	}

	public Template getBySiteAndTemplateName(String templateName, int siteId) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("name", templateName);
		sf.addEqCondition("objectId", siteId);
		return this.findFirst(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITemplateManager#countUnderSite(com.trs.dev4.jdk16.cms.bo.Site)
	 * @since yangyu @ Dec 17, 2012
	 */
	@Override
	public int countUnderSite(Site site) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("objectId", site.getId());
		return getAccessor().total(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TemplateManager#listTemplatesUnderSite(com.trs.dev4.jdk16.cms.bo.Site)
	 * @since yangyu @ Mar 28, 2013
	 */
	@Override
	public List<Template> listTemplatesUnderSite(Site site) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("objectId", site.getId());
		return getAccessor().listObjects(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TemplateManager#existTemplate(int,
	 *      java.lang.String)
	 * @since yangyu @ May 16, 2013
	 */
	@Override
	public boolean existTemplate(int siteId, String templateName) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("objectId", siteId);
		sf.addEqCondition("name", templateName);
		return getAccessor().total(sf) > 0;
	}
	
}
