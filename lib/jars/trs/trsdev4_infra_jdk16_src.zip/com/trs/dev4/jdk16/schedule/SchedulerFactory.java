/*
 * Created: liushen@Jun 24, 2010 7:51:10 AM
 */
package com.trs.dev4.jdk16.schedule;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 构建计划调度器的工厂，统一从此处构造 {@link ScheduledExecutorService}. <br>
 */
class SchedulerFactory {

	/**
	 * 根据线程池名称和容量，构造定时调度器.
	 * 
	 * @param poolName
	 *            定时调度器名称
	 * @param poolSize
	 *            定时调度器使用的线程数量
	 * @return 定时调度器
	 * @since liushen @ Jun 24, 2010
	 */
	static ScheduledExecutorService newScheduler(String poolName,
			int poolSize) {
		poolName = StringHelper.avoidEmpty(poolName, "noname-");
		ThreadFactory threadFactory = new SimpleThreadFactory(poolName);
		return Executors.newScheduledThreadPool(poolSize, threadFactory);
	}

}

/**
 * 在默认的ThreadFactory的基础上，开放了线程前缀的可配置；由于DefaultThreadFactory是JDK
 * Executors类的内部类，不可见，无法继承，因此本类将其内部实现重写了一遍。 <br>
 * 
 * @see Executors#defaultThreadFactory()
 */
class SimpleThreadFactory implements ThreadFactory {

	static final AtomicInteger poolNumber = new AtomicInteger(1);
	final ThreadGroup group;
	final AtomicInteger threadNumber = new AtomicInteger(1);
	final String namePrefix;
	String poolName;

	/**
	 * 
	 */
	public SimpleThreadFactory(String poolName) {
		SecurityManager s = System.getSecurityManager();
		group = (s != null) ? s.getThreadGroup() : Thread.currentThread()
				.getThreadGroup();
		namePrefix = poolName + "-" + poolNumber.getAndIncrement() + "-thread-";
	}

	/**
	 * @see java.util.concurrent.ThreadFactory#newThread(java.lang.Runnable)
	 * @since liushen @ Jun 24, 2010
	 */
	@Override
	public Thread newThread(Runnable r) {
		Thread t = new Thread(group, r, namePrefix
				+ threadNumber.getAndIncrement(), 0);
		if (t.isDaemon()) {
			t.setDaemon(false);
		}
		if (t.getPriority() != Thread.NORM_PRIORITY) {
			t.setPriority(Thread.NORM_PRIORITY);
		}
		return t;
	}

}
