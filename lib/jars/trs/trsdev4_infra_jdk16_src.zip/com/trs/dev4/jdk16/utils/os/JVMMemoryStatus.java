/**
 * Created: liushen@May 31, 2009 2:33:37 PM
 */
package com.trs.dev4.jdk16.utils.os;

/**
 * Java虚拟机的内存状况.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class JVMMemoryStatus {

	/**
	 * 空闲内存.
	 */
	private long freeMemory;
	
	/**
	 * 已分配内存.
	 */
	private long totalMemory;
	
	/**
	 * 最大可分配内存.
	 */
	private long maxMemory;
	
	/**
	 * 
	 */
	JVMMemoryStatus() {
		Runtime runtime = Runtime.getRuntime();
		freeMemory = runtime.freeMemory();
		totalMemory = runtime.totalMemory();
		maxMemory = runtime.maxMemory();
	}

	/**
	 * Get the {@link #freeMemory}.
	 * 
	 * @return the {@link #freeMemory}.
	 */
	public long getFreeMemory() {
		return freeMemory;
	}

	/**
	 * Get the {@link #totalMemory}.
	 * 
	 * @return the {@link #totalMemory}.
	 */
	public long getTotalMemory() {
		return totalMemory;
	}

	/**
	 * Get the {@link #maxMemory}.
	 * 
	 * @return the {@link #maxMemory}.
	 */
	public long getMaxMemory() {
		return maxMemory;
	}

}
