package com.trs.dev4.jdk16.cms;

import java.util.Set;

import com.trs.dev4.jdk16.cms.bo.Pagelet;

/**
 * Pagelet处理类
 * 
 * @author yangyu
 * @since Feb 4, 2013 3:15:27 PM
 */
public interface PageletsScheduler {

	/**
	 * 解析单个Pagelet适用于单线程解析模板，COMMON
	 * 
	 * @param generatorSession
	 * @param pagelet
	 * @return
	 * @since yangyu @ Aug 12, 2013
	 */
	String parse(GeneratorSession generatorSession, Pagelet pagelet);

	/**
	 * 解析多个模板，适用于多线程解析模板，PAGELET
	 * 
	 * @param generatorSession
	 * @param pagelets
	 * @since yangyu @ Aug 12, 2013
	 */
	void parse(GeneratorSession generatorSession, Set<Pagelet> pagelets);

}
