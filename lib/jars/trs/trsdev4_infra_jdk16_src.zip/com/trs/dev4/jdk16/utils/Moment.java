/*
 * Created: liushen@Dec 17, 2010 6:02:21 PM
 */
package com.trs.dev4.jdk16.utils;

import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.joda.time.Period;
import org.joda.time.format.PeriodFormatterBuilder;

/**
 * 对一个时刻(时间点)的封装；采用不可变对象模式. <br>
 * 后续视需要再加入对不同Locale的支持.
 */
public class Moment {

	private DateTime dt;

	/**
	 * 以当前时间构造.
	 */
	public Moment() {
		dt = new DateTime(System.currentTimeMillis());
	}

	/**
	 * 
	 * @param milliSeconds
	 *            毫秒数
	 */
	public Moment(long milliSeconds) {
		dt = new DateTime(milliSeconds);
	}

	/**
	 * 根据年、月、日、小时、分、秒、毫秒来构造时间点.
	 */
	public Moment(int year, int monthOfYear, int dayOfMonth, int hourOfDay,
			int minuteOfHour, int secondOfMinute, int millisOfSecond) {
		dt = new DateTime(year, monthOfYear, dayOfMonth, hourOfDay,
				minuteOfHour, secondOfMinute, millisOfSecond);
	}

	/**
	 * 返回该时刻的毫秒数(相对于1970年1月1日以来的毫秒数，Unix习俗).
	 * 
	 * @return 毫秒数
	 * @since liushen @ Dec 17, 2010
	 */
	public long getTimeMillis() {
		return dt.getMillis();
	}

	// Short, Medium, Long, Full基本按照Mac OS X的四种风格
	/**
	 * 
	 * @return
	 * @since liushen @ Dec 17, 2010
	 */
	// yyyy-MM-dd HH:mm:ss.S E Z
	public String toShortForm() {
		return DateUtil.formatMillis(getTimeMillis(), "yy-M-d H:m");
	}

	public String toMediumForm() {
		return DateUtil.formatMillis(getTimeMillis(), "yyyy-M-d HH:mm:ss");
	}

	public String toMonthDateWeekForm() {
		return DateUtil.formatMillis(getTimeMillis(), "M-d E");
	}

	public String toLongForm() {
		return DateUtil.formatMillis(getTimeMillis(), "yyyy-MM-dd HH:mm:ss.SSS");
	}

	public String toFullForm() {
		return DateUtil.formatMillis(getTimeMillis(), "yyyy-MM-dd HH:mm:ss.SSS E");
	}

	/**
	 * 以相对于当前时间的方式显示该时刻(一般应该是已过去的时刻)；比如: 3秒前.
	 * 
	 * @return 友好的字符串表示；比如: 3小时前.
	 * @since liushen @ Dec 17, 2010
	 */
	public String toRelativeForm() {
		return toRelativeForm(System.currentTimeMillis());
	}

	/**
	 * 以相对于给定时间的方式显示该时刻(一般应该是已过去的时刻)；比如: 3秒前.
	 * 
	 * @param refer
	 * @return 友好的字符串表示；比如: 3小时前.
	 * @since liushen @ Dec 17, 2010
	 */
	public String toRelativeForm(long refer) {
		Duration duration = new Duration(getTimeMillis(), refer);
		if (duration.getMillis() == 0) {
			return "此刻";
		}
		// Period period = duration.toPeriod(PeriodType.standard());
		Period period;
		String suffix;
		if (duration.getMillis() > 0) {
			period = new Period(getTimeMillis(), refer);
			suffix = "前";
		} else {
			period = new Period(refer, getTimeMillis());
			suffix = "后";
		}
		PeriodFormatterBuilder pfBuilder = calcFormatter(period);
		pfBuilder.appendSuffix(suffix);
		return period.toString(pfBuilder.toFormatter());

	}

	/**
	 * 算出合适的Formatter.
	 * 
	 * @since liushen @ Dec 17, 2010
	 */
	PeriodFormatterBuilder calcFormatter(Period period) {
		PeriodFormatterBuilder pfBuilder = new PeriodFormatterBuilder();

		if (period.getYears() > 0) {
			pfBuilder.appendYears().appendSuffix("年").printZeroNever();
		}
		if (period.getMonths() > 0) {
			pfBuilder.appendMonths().appendSuffix("个月").printZeroNever();
			return pfBuilder;
		}

		if (period.getWeeks() > 0) {
			pfBuilder.appendWeeks().appendSuffix("周").printZeroNever();
		}
		if (period.getDays() > 0) {
			pfBuilder.appendDays().appendSuffix("天").printZeroNever();
			return pfBuilder;
		}

		if (period.getHours() > 0) {
			pfBuilder.appendHours().appendSuffix("小时").printZeroNever();
			return pfBuilder;
		}

		if (period.getMinutes() > 0) {
			pfBuilder.appendMinutes().appendSuffix("分钟").printZeroNever();
			return pfBuilder;
		}

		pfBuilder.appendSeconds().appendSuffix("秒");
		return pfBuilder;
	}

	// public String toHumanReadable() {
	// return null;
	// }

	/**
	 * 获取该时刻隐含的时区(当前默认时区).
	 * 
	 * @since liushen @ Dec 17, 2010
	 */
	public String getTimeZone() {
		return dt.getZone().toTimeZone().getDisplayName();
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Dec 17, 2010
	 */
	@Override
	public String toString() {
		return toLongForm();
	}

}
