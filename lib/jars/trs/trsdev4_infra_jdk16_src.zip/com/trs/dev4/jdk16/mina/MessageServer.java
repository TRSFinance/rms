/*
 * Created: dujie@Oct 26, 2010 3:34:38 PM
 */
package com.trs.dev4.jdk16.mina;

import java.io.IOException;
import java.net.InetSocketAddress;

import javax.management.InstanceAlreadyExistsException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.management.ObjectName;

import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.serialization.ObjectSerializationCodecFactory;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.trs.dev4.jdk16.mina.impl.MessageServerSessionHandler;

/**
 * 职责: 消息服务器端<br>
 * 
 */
public class MessageServer extends Thread implements MessageServerMBean {

	/**
	 * 日志logger
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private final static Logger logger = LoggerFactory
			.getLogger(MessageServer.class);

	/**
	 * 是否运行
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private boolean running = true;

	/**
	 * 要注入的messageServerSessionHandler
	 * 
	 * @since dujie @ Nov 1, 2010
	 */
	private MessageServerSessionHandler messageServerSessionHandler;
	/**
	 * 端口
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private int port;

	/**
	 * @param port
	 *            监听的端口
	 * @since dujie @ Oct 26, 2010
	 */
	protected void listener() {

		// 创建NIO的连接
		NioSocketAcceptor acceptor = new NioSocketAcceptor();

		// 设置过滤器
		// 1、ObjectSerializationCodecFactory一般发送/接收的是对象等形象,以对象形式读取
		// 2、TextLineCodecFactory设置这个过滤器一行一行(/r/n)的发送/读取数据
		acceptor.getFilterChain().addLast("codec",
				new ProtocolCodecFilter(new ObjectSerializationCodecFactory()));

		// 设置日志过滤器，对IoSession 对象上发生的各种事件进行日志记录
		acceptor.getFilterChain().addLast("logger", new LoggingFilter());

		// 设定服务器端消息处理器
		acceptor.setHandler(this.messageServerSessionHandler);

		try {
			// 绑定端口
			acceptor.bind(new InetSocketAddress(this.port));
			logger.info("Listening on port :" + port + ",server is start!");
		} catch (IOException e) {
			logger.error("Bind on port " + port + " failed: " + e.getMessage(),
					e);
		}
	}

	/**
	 * @see java.lang.Thread#start()
	 * @since dujie @ Oct 29, 2010
	 */
	@Override
	public void start() {
		listener();
	}

	/**
	 * 注册 JMX
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	public void registerJMX() {

		MBeanServer server = MBeanServerFactory.createMBeanServer();
		try {
			ObjectName MessageServer = new ObjectName("trs.UC:name=TRSUC");
			server.registerMBean(this, MessageServer);
		} catch (MalformedObjectNameException e) {
			logger.error("registerJMX MalformedObjectNameException: ", e
					.getMessage(), e);
		} catch (InstanceAlreadyExistsException e) {
			logger.error("registerJMX InstanceAlreadyExistsException: ", e
					.getMessage(), e);
		} catch (MBeanRegistrationException e) {
			logger.error("registerJMX MBeanRegistrationException: ", e
					.getMessage(), e);
		} catch (NotCompliantMBeanException e) {
			logger.error("registerJMX NotCompliantMBeanException:", e
					.getMessage(), e);
		} catch (NullPointerException e) {
			logger
					.error("registerJMX NullPointerException:", e.getMessage(),
							e);
		}
	}

	/**
	 * @see java.lang.Thread#run()
	 * @since dujie @ Oct 27, 2010
	 */
	@Override
	public void run() {
		this.registerJMX();
		while (this.running) {
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				logger.error("Server sleep exception: " + e.getMessage(), e);
			}
		}
	}

	/**
	 * 关闭Server
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	public void shutdown() {
		this.running = false;
	}

	/**
	 * @param port
	 *            the {@link #port} to set
	 */
	public void setPort(int port) {
		this.port = port;
	}

	/**
	 * @return the {@link #messageServerSessionHandler}
	 */
	public MessageServerSessionHandler getMessageServerSessionHandler() {
		return messageServerSessionHandler;
	}

	/**
	 * @param messageServerSessionHandler
	 *            the {@link #messageServerSessionHandler} to set
	 */
	public void setMessageServerSessionHandler(
			MessageServerSessionHandler messageServerSessionHandler) {
		this.messageServerSessionHandler = messageServerSessionHandler;
	}

}
