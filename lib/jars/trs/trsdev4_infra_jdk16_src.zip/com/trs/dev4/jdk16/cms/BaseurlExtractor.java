package com.trs.dev4.jdk16.cms;

/**
 * 用于找到站点资源路径和网站地址，比如某个站点使用的CSS所在目录的根目录
 * 
 * @author yangyu
 * @since Jan 16, 2013 5:09:34 PM
 */
public interface BaseurlExtractor {

	/**
	 * 静态资源地址
	 * 
	 * @return
	 * @since yangyu @ May 16, 2013
	 */
	String getStaticResourceBaseUrl();

	/**
	 * 网站应用地址
	 * 
	 * @return
	 * @since yangyu @ May 16, 2013
	 */
	String getApplcationBaseUrl();

}
