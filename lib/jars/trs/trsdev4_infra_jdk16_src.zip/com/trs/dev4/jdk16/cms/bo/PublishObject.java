package com.trs.dev4.jdk16.cms.bo;

import net.sf.cglib.beans.BeanMap;

import com.trs.dev4.jdk16.cms.TagAware;

public class PublishObject {

	private BeanMap entity;

	private Object mappedObject;
	
	private int index;

	public PublishObject(Object object) {
		entity = BeanMap.create(object);
		mappedObject = object;
	}
	
	public PublishObject(Object object, int index) {
		this(object);
		this.index = index;
	}

	/**
	 * @return the entity
	 */
	public BeanMap getEntity() {
		return entity;
	}

	/**
	 * @param entity
	 *            the entity to set
	 */
	public void setEntity(BeanMap entity) {
		this.entity = entity;
	}

	/**
	 * @return the mappedObject
	 */
	public Object getMappedObject() {
		return mappedObject;
	}

	/**
	 * @param mappedObject
	 *            the mappedObject to set
	 */
	public void setMappedObject(Object mappedObject) {
		this.mappedObject = mappedObject;
	}

	@SuppressWarnings("unchecked")
	public Object getProperty(TagContext tagContext, String name) {
		if (name.equalsIgnoreCase("index")) {
			return index;
		}
		Object obj = entity.get(name);
		if (obj == null) {
			TagAware tagAware = tagContext.getSettings().getTagAware(this.getMappedObject().getClass().getSimpleName());
			obj = tagAware.getExtraProperty(this, name, tagContext);
		}
		return obj;
	}

	public int getPropertyAsInt(TagContext tagContext, String attributeName, int defaultValue) {
		Object obj = this.getProperty(tagContext, attributeName);
		if(obj==null){
			return defaultValue;
		}
		return (Integer)obj;
	}
	
	public int getPropertyAsInt(TagContext tagContext, String attributeName) {
		return this.getPropertyAsInt(tagContext, attributeName, 0);
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
	
}
