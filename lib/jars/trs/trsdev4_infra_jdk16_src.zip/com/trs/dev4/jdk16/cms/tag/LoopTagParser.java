package com.trs.dev4.jdk16.cms.tag;

import java.util.List;

import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

public class LoopTagParser implements TagParser {

	@Override
	public String parse(final TagContext tagContext) {

		PublishObject entity = tagContext.getEntity();

		final List<?> publishObjects = (List<?>) entity.getProperty(tagContext, "pageItems");

		if (publishObjects == null) {
			throw new TemplateException(
					"TRS_LOOP标签的外部标签（如TRS_OBJECTS或者TRS_LINKGROUP）需要启动loop支持，即外部标签需要补充loopType=\"loop\"属性");
		}
		
		return TagExpressionHelper.parseLoopTemplate(tagContext, publishObjects);
	}

}
