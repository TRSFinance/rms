/*
 * Created: yangyu@Jun 5, 2013 3:47:48 PM
 */
package com.trs.dev4.jdk16.cms.exp;

/**
 * 职责: <br>
 * 
 */
public class ParentObjNotFoundException extends RuntimeException {

	/**
	 * @since yangyu @ Jun 5, 2013
	 */
	private static final long serialVersionUID = 1L;

}
