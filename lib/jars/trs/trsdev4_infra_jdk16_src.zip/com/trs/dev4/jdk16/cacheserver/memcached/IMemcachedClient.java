package com.trs.dev4.jdk16.cacheserver.memcached;

import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * memcached客户端必须实现的基本功能<br>
 * 可用于替换客户端的实现策略（如spyImpl只是其中一种实现)
 * 
 */
public interface IMemcachedClient {

	/**
	 * 客户端的名称
	 * 
	 * @return
	 * @since TRS @ Oct 9, 2011
	 */
	String getName();

	/**
	 * 设置缓存
	 * 
	 * @param key
	 * @param expr
	 * @param value
	 * @since liuyou @ 2010-5-17
	 */
	void set(String key, int expr, Object value);

	/**
	 * 添加缓存<br>
	 * 当已经存在该缓存时再添加将不处理
	 * 
	 * @param key
	 * @param expr
	 * @param value
	 * @since liuyou @ 2010-5-17
	 */
	void add(String key, int expr, Object value);

	/**
	 * 替换缓存<br>
	 * 当不存在该缓存时做替换将不处理
	 * 
	 * @param key
	 * @param expr
	 * @param value
	 * @since liuyou @ 2010-5-17
	 */
	void replace(String key, int expr, Object value);

	/**
	 * 删除缓存项
	 * 
	 * @param key
	 * @since liuyou @ 2010-5-17
	 */
	void delete(String key);

	/**
	 * 获取缓存
	 * 
	 * @param key
	 * @return
	 * @since liuyou @ 2010-5-17
	 */
	Object get(String key);

	/**
	 * 
	 * @param key
	 * @return
	 * @since fangxiang @ Nov 13, 2010
	 */
	Object asynGet(String key);

	/**
	 * 
	 * @return
	 * @since fangxiang @ Nov 11, 2010
	 */
	Map<String, String> getStats(String server);

	/**
	 * 
	 * @param itemName
	 * @return
	 * @since fangxiang @ Nov 11, 2010
	 */
	Map<String, String> getStats(String server, String itemName);

	/**
	 * 
	 * @return
	 * @since fangxiang @ Nov 13, 2010
	 */
	public Collection<InetSocketAddress> getAvaliableServers();

	/**
	 * 
	 * @return
	 * @since fangxiang @ Nov 13, 2010
	 */
	public List<String> getServersDescription();

	/**
	 * 
	 * @param server
	 * @return
	 * @since fangxiang @ Nov 13, 2010
	 */
	public List<String> listAllKeys(String server);

	/**
	 * 链接服务器
	 * 
	 * @since TRS @ Nov 4, 2011
	 */
	public void connect(Map<String, String> configurations);

	/**
	 * 关闭服务器链接
	 * 
	 * @since TRS @ Nov 4, 2011
	 */
	public void close();
}
