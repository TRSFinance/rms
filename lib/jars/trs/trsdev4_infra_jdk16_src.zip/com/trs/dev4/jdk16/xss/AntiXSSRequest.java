/*
 * Created: Administrator@2011-6-30 下午05:58:48
 */
package com.trs.dev4.jdk16.xss;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import com.trs.dev4.jdk16.utils.CollectionUtil;

/**
 * 职责:解决XSS的request <br>
 * 
 */
public class AntiXSSRequest extends HttpServletRequestWrapper {

	/**
	 * 忽略路径，即不进行XSS过滤的路径
	 */
	private List ignorePaths = new ArrayList();

	/**
	 * 获取服请求地址路径
	 */
	private String servletPath = "";

	/**
	 * @param request
	 */
	public AntiXSSRequest(HttpServletRequest request) {
		super(request);
	}

	/**
	 * 
	 * @param request
	 * @param ignorePaths
	 *            忽略路径
	 */
	public AntiXSSRequest(HttpServletRequest request, List ignorePaths) {
		super(request);
		this.servletPath = request.getServletPath();
		this.ignorePaths = ignorePaths;
	}
	

	/**
	 * 
	 * @see javax.servlet.ServletRequestWrapper#getParameter(java.lang.String)
	 * @since Administrator @ 2011-6-30
	 */
	@Override
	public String getParameter(String paramName) {
		//忽略路径，不进行XSS过滤
		if (!isXSSFilter()) {
			return super.getParameter(paramName);
		}
		return SafeHtmlUtil.getSafeHtml(super.getParameter(paramName));

	}

	/**
	 * 
	 * @see javax.servlet.http.HttpServletRequestWrapper#getQueryString()
	 * @since Administrator @ 2011-6-30
	 */
	@Override
	public String getQueryString() {
		//忽略路径，不进行XSS过滤
		if (!isXSSFilter()) {
			return super.getQueryString();
		}
		return SafeHtmlUtil.getSafeHtml(super.getQueryString());
	}

	/**
	 * 是否进行XSS过滤
	 * 
	 * @return 若是在忽略路径上，返回false，否则返回true
	 * @since shenhaiwen @ 2014-5-25
	 */
	private boolean isXSSFilter() {
		if (CollectionUtil.isNotEmpty(ignorePaths) && ignorePaths.contains(servletPath)) {
			return false;
		}
			return true;
	}

	@Override
	public String getHeader(String string) {
		return super.getHeader(string);
	}

	public String getParameterAsDefaultVal(String name) {
		return super.getParameter(name);
	}

}
