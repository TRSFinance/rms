package com.trs.dev4.jdk16.cms.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.bo.ValidateContext;
import com.trs.dev4.jdk16.cms.enu.ExpressionDefination;
import com.trs.dev4.jdk16.cms.tag.AttributeConf;
import com.trs.dev4.jdk16.cms.tag.ParserConf;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

/**
 * 职责: 标签验证对象，不迟持久化 <br>
 * 
 * 
 */
public class TagAnalyser {

	/**
	 * 进行中的Tag
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	private Stack<ValidateContext> openedList = new Stack<ValidateContext>();;

	/**
	 * 结束的Tag
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	private Stack<ValidateContext> closedList = new Stack<ValidateContext>();

	/**
	 * 出错的Tag
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	private Stack<ValidateContext> erroredList = new Stack<ValidateContext>();

	public TagAnalyser() {

	}

	public Stack<ValidateContext> getOpenedList() {
		return openedList;
	}

	public void setOpenedList(Stack<ValidateContext> openedList) {
		this.openedList = openedList;
	}

	public Stack<ValidateContext> getClosedList() {
		return closedList;
	}

	public void setClosedList(Stack<ValidateContext> closedList) {
		this.closedList = closedList;
	}

	public Stack<ValidateContext> getErroredList() {
		return erroredList;
	}

	public void setErroredList(Stack<ValidateContext> erroredList) {
		this.erroredList = erroredList;
	}

	/**
	 * 校验模板
	 * 
	 * @param template
	 *            模板
	 * @return 返回ValidateResult对象，参见{@link ValidateContext}
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	public List<String> doValidate(Settings settings, String template) {

		String[] fragments = template.split("\n");

		int lineNum = 1;

		// 1. 验证关闭标签

		for (String fragment : fragments) {
			List<String> tagContents = TagExpressionHelper.getMatchRegStrs(fragment, "</*TRS_.+?/*>");
			for (String tagContent : tagContents) {
				ValidateContext validateContext = new ValidateContext(settings, tagContent);
				validateContext.setLine(lineNum);
				if (validateContext.isEndTag()) {
					checkEndTag(validateContext);
				} else {
					updateParentContext(validateContext);
					if (validateContext.isBeginTag()) {
						openedList.push(validateContext);
					} else if (validateContext.isEntireTag()) {
						closedList.push(validateContext);
					}
				}
			}
			lineNum++;
		}

		for (ValidateContext validateContext : openedList) {
			validateContext.addError("未关闭的标签");
			erroredList.push(validateContext);
		}

		for (ValidateContext validateContext : closedList) {
			TagParser parser = settings.getTagParser(validateContext.getName());
			if (parser == null) {
				validateContext.addError("指定的标签不存在 ");
				erroredList.push(validateContext);
			} else {
				// 2. 校验各个标签必须属性是否存在
				validateNeededAttribute(settings, validateContext);
				// 3. 校验各个标签互斥属性是否同时存在
				validateMutualAttribute(settings, validateContext);
				// 4. 校验各个标签是否有多余属性
				validateAllAttribute(settings, validateContext);
				// 5. 校验各个标签的是否缺少依赖的父标签
				validateParentTag(settings, validateContext);

				// 6. 遍历所有的属性

				ParserConf parserConf = settings.getParserConfig(validateContext.getName());
				
				Map<String, String> attributeMap = validateContext.getAttributes();
				Set<String> keys = attributeMap.keySet();
				for (Iterator<String> iterator = keys.iterator(); iterator.hasNext();) {
					String key = iterator.next();
					String value = attributeMap.get(key.toUpperCase());
					
					AttributeConf attributeConf = parserConf.getAttributeConf(key);
					
					String typeName = attributeConf.getType();
					
					ExpressionDefination expressionDefination = ExpressionDefination.valueOf(typeName.toUpperCase());
					expressionDefination.validate(validateContext, key.toUpperCase(), value);
					
				}
			}
		}
		List<String> errors = new ArrayList<String>();
		for (ValidateContext validateContext : closedList) {
			errors.addAll(validateContext.getErrorMsgs());
		}
		for (ValidateContext validateContext : erroredList) {
			errors.addAll(validateContext.getErrorMsgs());
		}
		return errors;
	}

	@SuppressWarnings("unchecked")
	private void updateParentContext(ValidateContext validateContext) {
		if (!openedList.isEmpty()) {
			validateContext.setParents((Stack<ValidateContext>) openedList.clone());
			ValidateContext parentValidateContext = openedList.pop();
			parentValidateContext.addChild(validateContext);
			openedList.push(parentValidateContext);
		}
	}

	private void checkEndTag(ValidateContext validateContext) {

		if (openedList.isEmpty()) {
			validateContext.addError("不存在开始标签");
			erroredList.add(validateContext);
		} else {
			ValidateContext popedValidateContext = openedList.peek();
			if (validateContext.getName().equalsIgnoreCase(popedValidateContext.getName())) {
				closedList.push(openedList.pop());
			} else {
				if (openedListExisttName(validateContext.getName())) {
					while (!openedList.isEmpty()) {
						ValidateContext vaContext = openedList.pop();
						if (vaContext.getName().equalsIgnoreCase(validateContext.getName())) {
							closedList.push(vaContext);
							break;
						} else {
							vaContext.addError("不存在结束标签");
							erroredList.add(vaContext);
						}
					}
				} else {
					validateContext.addError("不存在开始标签");
					erroredList.add(validateContext);
				}
			}
		}

	}

	/**
	 * @param name
	 * @return
	 * @since yangyu @ Dec 17, 2012
	 */
	private boolean openedListExisttName(String name) {
		for (ValidateContext validateContext : openedList) {
			if (validateContext.getName().equalsIgnoreCase(name)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 验证父标签
	 * 
	 * @param validatorConfig
	 * @param validateContext
	 * @since yangyu @ Oct 19, 2012
	 */
	private void validateParentTag(Settings settings, ValidateContext validateContext) {

		ParserConf parserConf = settings.getParserConfig(validateContext.getName());

		List<String> parents = parserConf.getNeededParentTags();

		if (parents.size() != 0) {
			Stack<ValidateContext> parentStack = validateContext.getParents();
			boolean hasParent = false;
			if (!parentStack.isEmpty()) {
				while (!parentStack.isEmpty()) {
					String parentTag = parentStack.pop().getName().toUpperCase();
					if (parents.contains(parentTag)) {
						hasParent = true;
						break;
					}
				}
				if (!hasParent) {
					validateContext.addError("标签应该嵌套在" + parents + "标签中");
				}
			} else {
				validateContext.addError("标签应该嵌套在" + parents + "标签中");
			}
		}
	}

	/**
	 * @param validatorConfig
	 * @param validateContext
	 * @since yangyu @ Oct 19, 2012
	 */
	private void validateAllAttribute(Settings settings, ValidateContext validateContext) {

		ParserConf parserConf = settings.getParserConfig(validateContext.getName());

		boolean needValidate = !parserConf.isAllowExtensionAttribute();

		if (needValidate) {

			Set<String> actualAttributes = validateContext.getAttributes().keySet();

			for (String attribute : actualAttributes) {
				if (!parserConf.existAttribute(attribute)) {
					validateContext.addError("存在多余的属性或者不正确的属性，错误属性为" + attribute + "，可用的属性有："
							+ parserConf.getAttributeNames());
				}
			}
		}
	}

	/**
	 * 验证互斥的属性
	 * 
	 * @param validatorConfig
	 * @param validateContext
	 * @since yangyu @ Oct 19, 2012
	 */
	private void validateMutualAttribute(Settings settings, ValidateContext validateContext) {

		ParserConf parserConf = settings.getParserConfig(validateContext.getName());

		Set<String> actualAttributes = validateContext.getAttributes().keySet();

		List<String> mutualAttributes = parserConf.getMutualAttributes();

		int hit = 0;
		for (String actualAttribute : actualAttributes) {
			if (mutualAttributes.contains(actualAttribute)) {
				hit++;
				if (hit > 1) {
					validateContext.addError("存在互斥属性，互斥属性为：" + mutualAttributes);
					break;
				}
			}
		}

	}

	/**
	 * 验证必须的属性
	 * 
	 * @param validatorConfig
	 * @param validateContext
	 * @since yangyu @ Oct 19, 2012
	 */
	private void validateNeededAttribute(Settings settings, ValidateContext validateContext) {
		ParserConf parserConf = settings.getParserConfig(validateContext.getName());
		Collection<AttributeConf> attributeConfs = parserConf.getAttributeList();
		for (AttributeConf attributeConf : attributeConfs) {
			if (attributeConf.isRequired()) {
				if (!validateContext.existAttribute(attributeConf.getName())) {
					validateContext.addError("缺少必须属性" + attributeConf.getName());
				}
			}
		}
	}

}
