/*
 * Created: dujie@2011-10-12 下午03:29:10
 */
package com.trs.dev4.jdk16.verifycode.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.trs.dev4.jdk16.dao.IAccessor;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.BaseManager;
import com.trs.dev4.jdk16.model.example.Captcha;
import com.trs.dev4.jdk16.verifycode.ICaptchaManager;

/**
 * 
 * 职责: <br>
 * 问答式验证码管理类实现
 * 
 */
@Service
class CaptchaManager extends BaseManager<Captcha> implements ICaptchaManager {
	

	@Resource(name = "captchaAccessor")
	private IAccessor<Captcha> captchaAccessor;

	/**
	 * @see com.trs.dev4.jdk16.verifycode.ICaptchaManager#listCaptchas(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public List<Captcha> listCaptchas(SearchFilter searchFilter) {
		return captchaAccessor.listObjects(searchFilter);
	}

	/**
	 * @see com.trs.dev4.jdk16.verifycode.ICaptchaManager#pagedCaptchas(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public PagedList<Captcha> pagedCaptchas(SearchFilter searchFilter) {
		return captchaAccessor.pagedObjects(searchFilter);
	}
	
	/**
	 * @see com.trs.dev4.jdk16.model.BaseManager#delete(com.trs.dev4.jdk16.model.IEntity)
	 * @since dujie @ 2011-10-13
	 */
	@Override
	public void delete(Captcha object) {
		captchaAccessor.delete(object);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.BaseManager#get(int)
	 * @since dujie @ 2011-10-13
	 */
	@Override
	public Captcha get(int captcha) {
		return captchaAccessor.getObject(captcha);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.BaseManager#saveOrUpdate(com.trs.dev4.jdk16.model.IEntity)
	 * @since dujie @ 2011-10-13
	 */
	@Override
	public void saveOrUpdate(Captcha captcha) {
		if (captcha.getId() > 0) {
			captchaAccessor.update(captcha);
		} else {
			captchaAccessor.insert(captcha);
		}
		
	}

	/**
	 * @return the {@link #captchaAccessor}
	 */
	public IAccessor<Captcha> getCaptchaAccessor() {
		return captchaAccessor;
	}

	/**
	 * @param captchaAccessor
	 *            the {@link #captchaAccessor} to set
	 */
	public void setCaptchaAccessor(IAccessor<Captcha> captchaAccessor) {
		this.captchaAccessor = captchaAccessor;
	}

}
