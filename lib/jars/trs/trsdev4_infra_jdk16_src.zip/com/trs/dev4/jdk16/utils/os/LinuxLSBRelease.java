/*
 * Created: liushen@Oct 25, 2012 2:30:33 PM
 */
package com.trs.dev4.jdk16.utils.os;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.trs.dev4.jdk16.exec.CommandExecUtil;
import com.trs.dev4.jdk16.exec.ExecuteResult;

/**
 * Linux lsb_release命令返回信息的封装.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class LinuxLSBRelease {

	/**
	 * 发行版ID。
	 */
	private String distributorID;

	/**
	 * 发行版的版本号。
	 */
	private String release;

	/**
	 * 发行版代号。
	 */
	private String codename;

	/**
	 * 发行版描述。
	 */
	private String description;

	private LinuxLSBRelease() {
	}

	/**
	 * 通过命令实时获取发行版信息，字符串形式，不会抛出异常。
	 * 
	 * @since liushen @ Oct 14, 2014
	 */
	public static String getOSInfo() {
		try {
			LinuxLSBRelease ll = realtimeGet();
			return ll.toString();
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	/**
	 * 通过命令实时获取发行版信息对象。
	 * 
	 * @throws UnsupportedOperationException
	 *             命令执行失败时
	 * @since liushen @ Oct 25, 2012
	 */
	public static LinuxLSBRelease realtimeGet() {
		ExecuteResult cmdResult = CommandExecUtil.executeCommand("lsb_release -a");
		if (cmdResult.getExitValue() != 0) {
			throw new UnsupportedOperationException("无法获取发行版信息, lsb_release命令返回" + cmdResult.getExitValue());
		}
		LinuxLSBRelease result = new LinuxLSBRelease();
		List<String> lines = cmdResult.getOutput();
		Map<String, String> map = new HashMap<String, String>();
		for (String line : lines) {
			int pos = line.indexOf(':');
			if (pos < 0) {
				continue;
			}
			map.put(line.substring(0, pos), line.substring(pos + 1).trim());
		}
		// Distributor ID: RedHatEnterpriseServer
		// Description: Red Hat Enterprise Linux Server release 5.1 (Tikanga)
		// Release: 5.1
		// Codename: Tikanga
		result.distributorID = map.get("Distributor ID");
		result.release = map.get("Release");
		result.codename = map.get("Codename");
		result.description = map.get("Description");
		return result;
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Oct 14, 2014
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder(super.toString());
		sb.append(": distributorID=").append(distributorID);
		sb.append(", release=").append(distributorID);
		sb.append(", codename=").append(distributorID);
		return sb.toString();
	}

	/**
	 * Get the {@link #distributorID}.
	 * 
	 * @return the {@link #distributorID}.
	 */
	public String getDistributorID() {
		return distributorID;
	}

	/**
	 * Get the {@link #release}.
	 * 
	 * @return the {@link #release}.
	 */
	public String getRelease() {
		return release;
	}

	/**
	 * Get the {@link #codename}.
	 * 
	 * @return the {@link #codename}.
	 */
	public String getCodename() {
		return codename;
	}

	/**
	 * Get the {@link #description}.
	 * 
	 * @return the {@link #description}.
	 */
	public String getDescription() {
		return description;
	}

}
