package com.trs.dev4.jdk16.cms.bo;

public class ExpressionObject {

}
