/*
 * Created on 2006-3-9 18:30:24, by liushen
 */
package com.trs.dev4.jdk16.exception;

/**
 * 进行数据库操作时抛出的异常. <BR>
 * 
 */
@SuppressWarnings("serial")
public class DAOException extends RootException {
    
	public DAOException(String msg) {
        super(msg);
    }
    
    public DAOException(String msg, Throwable cause) {
        super(msg, cause);
    }
    
    public DAOException(Throwable cause) {
		super(cause);
	}

}
