/*
 * Created: yangyu@Apr 11, 2013 3:01:32 PM
 */
package com.trs.dev4.jdk16.cms.exp;

import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

/**
 * 职责: 模板解析父类异常
 * 
 */
public class TemplateException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public TemplateException(String mesg) {
		super(mesg);
	}
	
	/**
	 * @param string
	 * @param ex
	 */
	public TemplateException(String msg, Exception ex) {
		super(msg, ex);
	}

	/**
	 * @param string
	 * @param tagContext
	 */
	public TemplateException(String msg, TagContext tagContext) {
		super(TagExpressionHelper.buildTemplateException(tagContext, msg));
	}
}
