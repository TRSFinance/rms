/*
 * Created: liushen@Dec 5, 2009 10:16:10 AM
 */
package com.trs.dev4.jdk16.exec;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.exception.ProcessException;
import com.trs.dev4.jdk16.exception.WrappedException;
import com.trs.dev4.jdk16.utils.CloseUtil;
import com.trs.dev4.jdk16.utils.CollectionUtil;
import com.trs.dev4.jdk16.utils.EnvConst;
import com.trs.dev4.jdk16.utils.FileUtil;
import com.trs.dev4.jdk16.utils.ReflectUtil;
import com.trs.dev4.jdk16.utils.RegexUtil;
import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.utils.Substring;

/**
 * 执行操作系统进程的助手.
 * 
 */
public class ProcessHelper {

	/**
	 * @since liushen @ Jul 5, 2013
	 */
	private static final boolean IS_WINDOWS = EnvConst.isWindows();

	private static final Logger LOG = Logger.getLogger(ProcessHelper.class);

	/**
	 * 
	 */
	private static final String PATTERN_SPACES = "\\s+";

	private String cmd;

	private int exitValue = Integer.MIN_VALUE;

	private Process process;

	/**
	 * 开始执行进程的时刻.
	 */
	private long startTime;

	/**
	 * 全部结束的时刻.
	 */
	private long endTime;

	/**
	 * 进程执行结束的时刻.
	 */
	private long endCallTime;

	/**
	 * 设定的工作目录.
	 */
	private File workDir;

	/**
	 * 实际的工作目录.
	 */
	private File actualWorkDir;

	/**
	 * 自定的环境变量.
	 */
	private Map<String, String> env;

	/**
	 * 实际的所有环境变量.
	 */
	private Map<String, String> actualEnv;

	private List<String> listStdout = new ArrayList<String>();

	private List<String> listStderr = new ArrayList<String>();

	/**
	 * 是否不获取程序的输出，包括stdout和stderr的输出.
	 */
	private boolean omitOutput;

	private boolean debug = LOG.isDebugEnabled();

	/**
	 * 进程ID(Unix)。
	 */
	private int pid;

	/**
	 * 进程ID(Unix/Linux：<code>java.lang.UNIXProcess</code>)或句柄(Windows：<code>java.lang.ProcessImpl</code>以及以前的
	 * <code>java.lang.Win32Process</code>)。
	 */
	private long pidOrHandle;

	/**
	 * 表示获取进程ID失败的常量。
	 */
	private static final long UNABLE_GET_PROCESS_ID = -1;

	/**
	 * 表示获取Windows进程句柄失败的常量。
	 */
	private static final long UNABLE_GET_PROCESS_HANDLE = -2;

	/**
	 * Windows命令行前缀.
	 */
	public static final String WINDOWS_CMD_PRIFEX = "cmd /c ";

	/**
	 * 是否直接执行，即不通过cmd等Shell来执行该进程。
	 */
	private boolean executedDirectly;

	/**
	 * 
	 */
	private StreamRunner stdoutRunner;

	/**
	 * 
	 */
	private StreamRunner stderrRunner;

	/**
	 * 
	 */
	private String outputEncoding;

	/**
	 * 标准输出流的监听器。
	 */
	private IProcessOutputLineListener stdoutListener;

	/**
	 * 标准错误流的监听器。
	 */
	private IProcessOutputLineListener stderrListener;

	/**
	 * @see #ProcessHelper(String, String, boolean)
	 */
	public ProcessHelper(String cmd) {
		this(cmd, null, false);
	}

	/**
	 * 
	 * @see #ProcessHelper(String, String, boolean)
	 */
	public ProcessHelper(String cmd, String strWorkDir) {
		this(cmd, strWorkDir, false);
	}

	/**
	 * @param cmd
	 *            要运行的程序的完整命令行
	 * @param strWorkDir
	 *            在哪个目录启动程序；如果该目录不存在(包含字符串为空的情况)，则自适应为本JVM进程的启动目录
	 * @param executedDirectly
	 *            在Windows下是直接启动还是通过cmd /c来间接启动
	 */
	public ProcessHelper(String cmd, String strWorkDir, boolean executedDirectly) {
		if (cmd == null) {
			throw new IllegalArgumentException("cmd is null!");
		}
		cmd = cmd.trim();
		if (cmd.length() == 0) {
			throw new IllegalArgumentException("cmd is empty!");
		}
		this.cmd = cmd;
		this.executedDirectly = executedDirectly;

		prepare();

		this.workDir = FileUtil.dirExists(strWorkDir) ? new File(strWorkDir)
				: new File(FileUtil.getCurrentWorkingDir());
	}

	/**
	 * 执行该进程所花的时间，包括调用开销和执行开销。
	 * 
	 * @return 所花时间的毫秒值
	 */
	public long getEstimatedTimeMillis() {
		return endTime - startTime;
	}

	/**
	 * 
	 * @return
	 */
	public List<String> getStdOut() {
		return listStdout;
	}

	/**
	 * 
	 * @return
	 */
	public List<String> getStdErr() {
		return listStderr;
	}

	/**
	 * 强制结束进程, 仅在用{@link #startProcess()}方式调用进程时才有效!
	 */
	public void cancelProcess() {
		if (LOG.isDebugEnabled()) {
			LOG.debug("the process will be kill, process:" + process);
		}
		if (process == null) {
			return;
		}

		if (stdoutRunner != null) {
			stdoutRunner.interrupt();
			stderrRunner.interrupt();

			try {
				stdoutRunner.join(10);
			} catch (InterruptedException e) {
				LOG.warn("failed on join to wait stdoutRunner finish, ignore", e);
			}
		}
		process.destroy();
		if (LOG.isDebugEnabled()) {
			LOG.debug("call process.destroy end, process:" + process);
		}
	}

	public void enterSomethingToProcess(String str) {
		if (process == null) {
			return;
		}
		OutputStream os = process.getOutputStream();
		OutputStreamWriter osw = new OutputStreamWriter(os);
		try {
			osw.write(str);
			// osw.flush();
			LOG.info("flush: " + str + " ok.");
		} catch (IOException e) {
			throw new WrappedException(e);
		} finally {
			CloseUtil.close(osw);
			CloseUtil.close(os);
		}
	}

	/**
	 * 
	 * @creator liushen @ Jan 28, 2010
	 */
	private void prepare() {
		if (false == executedDirectly) {
			if (IS_WINDOWS) {
				cmd = ProcessHelper.WINDOWS_CMD_PRIFEX + cmd;
			}
		}
	}

	/**
	 * 启动进程并监听该进程的退出；通过在单独的线程中启动进程来实现。
	 * 
	 * @since liushen @ Nov 30, 2012
	 */
	public void startAndListenExit(IProcessTerminatedListener ptl) {
		ProcessThread pt = new ProcessThread(this, ptl);
		pt.setName("CMD-" + StringHelper.adjustLength(cmd, 20));
		pt.start();
	}

	/**
	 * 在单独的线程中启动进程，并监听该进程的启动和退出；如果设定了最大秒数，则超过该时间后强制杀掉该进程。
	 * 
	 * @since liushen @ Oct 10, 2013
	 */
	public void startAndListen(IProcessListener listener, int maxSeconds) {
		ProcessThread pt = new ProcessThread(this, listener);
		pt.setName("CMD-" + StringHelper.adjustLength(cmd, 20));
		pt.start();

		if (maxSeconds <= 0) {
			return;
		}

		long begin = System.currentTimeMillis();
		try {
			Thread.sleep(maxSeconds * 1000);
		} catch (InterruptedException e) {
			LOG.warn("Interrupted, and this can ignored", e);
		} finally {
			if (LOG.isDebugEnabled()) {
				LOG.debug("actual wait " + (System.currentTimeMillis() - begin) + " ms for cmd: [" + cmd + "]");
			}
		}
		if (false == this.isProcessEnded()) {
			killProcess();
			pt.interrupt();
		}

	}

	/**
	 * 强制杀掉进程
	 * 
	 * @since zhuqing @ Jun 13, 2014
	 */
	private void killProcess() {
		if (EnvConst.isWindows()) {
			this.cancelProcess();
		}

		// if linux, call kill -9 pid, see TRSMAS-1041
		if (EnvConst.isLinux()) {
			String cmd = "kill -9 " + this.getProcessId();
			ExecuteResult result = CommandExecUtil.executeCommand(cmd, null, null, null);
			LOG.info("the kill -9 " + this.getProcessId() + " command return is:" + result);
		}
	}

	/**
	 * 该进程是否已经启动（不论是否运行结束）。
	 * 
	 * @since liushen @ Jun 27, 2013
	 */
	public boolean isProcessStarted() {
		return startTime > 0;
	}

	/**
	 * 该进程是否已经运行结束（不论是否正常退出）。
	 * 
	 * @since liushen @ Jun 27, 2013
	 */
	public boolean isProcessEnded() {
		return endCallTime > 0;
	}

	/**
	 * 启动进程, 并一直等待其执行结束; 仅包可见.
	 * 
	 * @return 进程的返回值
	 */
	public int startAndWait() {
		startProcess();

		try {
			exitValue = process.waitFor();
		} catch (InterruptedException e) {
			LOG.warn("wait process [" + cmd + "] interrupted", e);
			throw new ProcessException("the process interrupted, maybe by another thread!", e);
		} finally {
			endCallTime = System.currentTimeMillis();
		}

		if (false == omitOutput) {
			while (stdoutRunner.isFinished() == false
					|| stderrRunner.isFinished() == false) {
				try {
					Thread.sleep(10L);
				} catch (InterruptedException e) {
					LOG.warn("wait the stdout or stderr of process [" + cmd + "] interrupted, so skip and break.", e);
					break;
				}
			}
			listStdout = stdoutRunner.getOutputAsTail();
			listStderr = stderrRunner.getOutputAsTail();
		}

		recordEndTime();

		return exitValue;
	}

	/**
	 * 仅包可见.
	 */
	ProcessHelper startProcess() {
		List<String> lstCmd = parseCmd(cmd);
		if (isDebug()) {
			LOG.debug("cmd after parsed: " + CollectionUtil.toString(lstCmd));
		}
		ProcessBuilder pb = new ProcessBuilder(lstCmd);

		pb.directory(workDir);
		actualWorkDir = pb.directory();

		// 设置自定的环境变量
		if (env != null) {
			Map<String, String> pbEnv = pb.environment();
			for (Map.Entry<String, String> entry : env.entrySet()) {
				pbEnv.put(entry.getKey(), entry.getValue());
			}
		}

		actualEnv = pb.environment();
		recordStartTime();
		try {
			process = pb.start();
		} catch (IOException e) {
			throw new ProcessException(e);
		}

		if (false == omitOutput) {
			stdoutRunner = new StreamRunner(process.getInputStream(), stdoutListener, cmd, "stdout");
			stderrRunner = new StreamRunner(process.getErrorStream(), stderrListener, cmd, "stderr");
			if (StringHelper.isNotEmpty(outputEncoding)) {
				stdoutRunner.setEncoding(outputEncoding);
				stderrRunner.setEncoding(outputEncoding);
			}
			stdoutRunner.start();
			stderrRunner.start();
		}

		if (isDebug()) {
			LOG.debug("started: " + this);
		}

		return this;
	}

	/**
	 * 将字符串解析为 <code>java.lang.ProcessBuilder</code> 接受的List，主要是对于双引号、空格类字符的处理。
	 * 
	 * @param sCmd
	 *            完整命令行的字符串
	 * @creator liushen @ Jan 28, 2010
	 */
	static List<String> parseCmd(String sCmd) {
		List<String> lstCmd = new ArrayList<String>();

		List<Substring> lstQuotes = RegexUtil.getSubstringsByQuote(sCmd);
		// 若不含双引号，则直接以空白字符分割
		if (lstQuotes.size() == 0) {
			String[] arr = sCmd.split(PATTERN_SPACES);
			return Arrays.asList(arr);
		}

		// 若含双引号，则将引号中的内容作为完整的一部分，再按空白字符分割
		int prevEnd = 0;
		for (Substring substring : lstQuotes) {
			String before = substring.getBefore(prevEnd);
			simpleSplitAndAddToList(before, lstCmd);
			// liushen@Feb 17, 2012: 不应去除掉参数的双引号，以支持Windows的find等命令
			if (IS_WINDOWS) {
				lstCmd.add(substring.getValue());
			} else {
				// liushen@Mar 7, 2012: linux下需要去掉双引号，否则出不来正确的结果(TRSMAS-557)
				lstCmd.add(StringHelper.trimQuote(substring.getValue()));
			}
			prevEnd = substring.getEnd();
		}
		String substrAfterLastQuote = sCmd.substring(prevEnd);
		simpleSplitAndAddToList(substrAfterLastQuote, lstCmd);

		return lstCmd;
	}

	/**
	 * @param lstCmd
	 * @creator liushen @ Jan 29, 2010
	 */
	private static void simpleSplitAndAddToList(String str, List<String> lstCmd) {
		if (str == null || str.length() == 0) {
			return;
		}
		str = str.trim();
		String[] arr = str.split(PATTERN_SPACES);
		lstCmd.addAll(Arrays.asList(arr));
	}

	private void recordStartTime() {
		startTime = System.currentTimeMillis();
	}

	private void recordEndTime() {
		endTime = System.currentTimeMillis();
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Apr 25, 2010
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ProcessHelper [");
		builder.append("cmd=").append(cmd);
		builder.append(", in ").append(workDir);
		if (isProcessStarted()) {
			if (false == IS_WINDOWS) {
				builder.append(", pid=").append(getProcessId());
			}
			if (isProcessEnded()) {
				builder.append(", exitValue=").append(exitValue);
				builder.append(", consumed ").append(getEstimatedTimeMillis()).append("ms");
				if (hasStdOutput()) {
					builder.append(", stdout ").append(totalLinesOfStdout()).append(" lines");
				}
				if (hasErrorOutput()) {
					builder.append(", stderr ").append(totalLinesOfStderr()).append(" lines");
					if (false == isNormalTermination()) {
						builder.append(", and last 2: ").append(CollectionUtil.lastSublines(listStderr, 2));
					}
				}
			} else {
				builder.append(", still running, estimated ").append(getEstimatedTimeMillis()).append("ms");
			}
		}
		builder.append("]");
		return builder.toString();
	}

	int totalLinesOfStdout() {
		if (stdoutRunner == null) {
			return -1;
		}
		return stdoutRunner.getTotalOutputLine();
	}

	int totalLinesOfStderr() {
		if (stderrRunner == null) {
			return -1;
		}
		return stderrRunner.getTotalOutputLine();
	}

	/**
	 * 是否实际向标准错误设备输出有内容.
	 * 
	 * @since liushen @ Apr 25, 2010
	 */
	public boolean hasErrorOutput() {
		return CollectionUtil.isNotEmpty(listStderr);
	}

	/**
	 * 是否实际向标准输出设备输出有内容.
	 * 
	 * @since liushen @ Apr 25, 2010
	 */
	public boolean hasStdOutput() {
		return CollectionUtil.isNotEmpty(listStdout);
	}

	/**
	 * 返回进程ID或句柄；如果已经获取过则直接返回，节省反射的开销。
	 * 
	 * @return 进程ID或句柄({@link #pidOrHandle})；如果进程尚未开始执行则返回<code>0</code>；如果获取进程ID失败则返回 {@link #UNABLE_GET_PROCESS_ID}
	 *         ；如果获取Windows进程句柄失败则返回 {@link #UNABLE_GET_PROCESS_HANDLE}；
	 * @deprecated liushen@Jun 28, 2013: 换回 {@link #getProcessId()}
	 *             ；因为用得到的Windows进程handle值查不到对应的进程，它和wmic命令中查询到的handle值不同(这两个handle可能就不是同一个东西)
	 */
	@Deprecated
	public long getOrReflectPidOrHandle() {
		if ((pidOrHandle != 0) || (process == null)) {
			return pidOrHandle;
		}

		String processImplClassName = process.getClass().getName();
		if ("java.lang.UNIXProcess".equals(processImplClassName)) {
			/* get the PID on unix/linux/mac systems */
			try {
				pidOrHandle = ReflectUtil.getFieldValueAsLong(process, "pid", false);
			} catch (Throwable e) {
				LOG.warn("unable to get pid of " + processImplClassName + " via Reflect; the process cmd is ["
						+ getCmd() + "]", e);
				pidOrHandle = UNABLE_GET_PROCESS_ID;
			}
		} else {
			try {
				pidOrHandle = ReflectUtil.getFieldValueAsLong(process, "handle", false);
			} catch (Throwable e) {
				LOG.warn("unable to get process handle of " + processImplClassName
						+ " via Reflect; the process cmd is [" + getCmd() + "]", e);
				pidOrHandle = UNABLE_GET_PROCESS_HANDLE;
			}
		}

		pid = (int) pidOrHandle;
		return pidOrHandle;
	}

	/**
	 * 获取进程ID；暂不支持Windows。
	 * 
	 * @since liushen @ Sep 14, 2012
	 */
	public int getProcessId() {
		getOrReflectPidOrHandle();
		return pid;
	}

	/**
	 * 该进程是否是正常退出的：By convention, 0 indicates normal termination.
	 * 
	 * @since liushen @ Jul 5, 2013
	 */
	public boolean isNormalTermination() {
		return exitValue == 0;
	}

	/**
	 * @return the {@link #cmd}
	 */
	public String getCmd() {
		return cmd;
	}

	/**
	 * @return the {@link #exitValue}
	 */
	public int getExitValue() {
		return exitValue;
	}

	/**
	 * @return the {@link #startTime}
	 */
	public long getStartTime() {
		return startTime;
	}

	/**
	 * @return the {@link #endTime}
	 */
	public long getEndTime() {
		return endTime;
	}

	void dumpStaticis() {
		if (false == isProcessStarted()) {
			System.out.println("The process (" + cmd + ") not start yet!");
			return;
		}
		System.out.println("The process: cmd: " + cmd);
		if (debug) {
			System.out.println("workDir: " + workDir + ", env:");
			if (env != null) {
				for (Iterator<String> keys = env.keySet().iterator(); keys.hasNext();) {
					String key = keys.next();
					System.out.println(key + " = " + env.get(key));
				}
			}
		}
	
		System.out.println("ExitValue: " + getExitValue());
		System.out.println("EstimatedTime: " + getEstimatedTimeMillis() + "ms. (start: " + new Timestamp(startTime) + ", endCall: "
				+ new Timestamp(endCallTime) + ", end: " + new Timestamp(endTime) + ")");
		System.out.println("StdOut: " + CollectionUtil.toString(getStdOut()));
		System.out.println("StdErr: " + CollectionUtil.toString(getStdErr()));
		System.out.println();
	}

	/**
	 * Get the {@link #env}.
	 * 
	 * @return the {@link #env}.
	 */
	public Map<String, String> getEnv() {
		return env;
	}

	/**
	 * Set the {@link #env}.
	 * 
	 * @param env
	 *            the env to set
	 */
	void setEnv(Map<String, String> env) {
		this.env = env;
	}

	/**
	 * Get the {@link #workDir}.
	 * 
	 * @return the {@link #workDir}.
	 */
	public File getWorkDir() {
		return workDir;
	}

	/**
	 * @param count
	 * @return
	 * @since liushen @ Apr 25, 2010
	 */
	public String sublinesOfStdout(int count) {
		return CollectionUtil.sublines(listStdout, count);
	}

	/**
	 * 
	 * @param count
	 * @return
	 * @since liushen @ Apr 25, 2010
	 */
	public String sublinesOfStderr(int count) {
		return CollectionUtil.sublines(listStderr, count);
	}

	/**
	 * 
	 * @param count
	 * @return
	 * @since liushen @ Apr 25, 2010
	 */
	public String lastSublinesOfStdout(int count) {
		return CollectionUtil.lastSublines(listStdout, count);
	}

	/**
	 * 
	 * @param count
	 * @return
	 * @since liushen @ Apr 25, 2010
	 */
	public String lastSublinesOdStderr(int count) {
		return CollectionUtil.lastSublines(listStderr, count);
	}

	/**
	 * @return the {@link #omitOutput}
	 */
	public boolean isOmitOutput() {
		return omitOutput;
	}

	/**
	 * @param omitOutput
	 *            the {@link #omitOutput} to set
	 */
	public void setOmitOutput(boolean omitOutput) {
		this.omitOutput = omitOutput;
	}

	/**
	 * @return the {@link #endCallTime}
	 */
	public long getEndCallTime() {
		return endCallTime;
	}

	/**
	 * @return the {@link #actualWorkDir}
	 */
	public File getActualWorkDir() {
		return actualWorkDir == null ? workDir : actualWorkDir;
	}

	/**
	 * @return the {@link #actualEnv}
	 */
	public Map<String, String> getActualEnv() {
		return actualEnv == null ? env : actualEnv;
	}

	/**
	 * @return the {@link #debug}
	 */
	public boolean isDebug() {
		return debug;
	}

	/**
	 * @param debug
	 *            the {@link #debug} to set
	 */
	void setDebug(boolean debug) {
		this.debug = debug;
	}

	/**
	 * @return the {@link #executedDirectly}
	 */
	public boolean isExecutedDirectly() {
		return executedDirectly;
	}

	/**
	 * @param calledByShell
	 *            the {@link #executedDirectly} to set
	 */
	public void setExecutedDirectly(boolean calledByShell) {
		this.executedDirectly = calledByShell;
	}

	/**
	 * @return the {@link #stdoutListener}
	 */
	public IProcessOutputLineListener getStdoutListener() {
		return stdoutListener;
	}

	/**
	 * @param stdoutListener
	 *            the {@link #stdoutListener} to set
	 */
	public void setStdoutListener(IProcessOutputLineListener stdoutListener) {
		this.stdoutListener = stdoutListener;
	}

	/**
	 * @return the {@link #stderrListener}
	 */
	public IProcessOutputLineListener getStderrListener() {
		return stderrListener;
	}

	/**
	 * @param stderrListener
	 *            the {@link #stderrListener} to set
	 */
	public void setStderrListener(IProcessOutputLineListener stderrListener) {
		this.stderrListener = stderrListener;
	}

	/**
	 * @return the {@link #outputEncoding}
	 */
	public String getOutputEncoding() {
		return outputEncoding;
	}

	/**
	 * @param outputEncoding
	 *            the {@link #outputEncoding} to set
	 */
	public void setOutputEncoding(String outputEncoding) {
		this.outputEncoding = outputEncoding;
	}

}
