package com.trs.dev4.jdk16.cms;

/**
 * 
 * 职责: 模板解释器
 * 
 */
public interface TemplateInterpreter {

	/**
	 * 解释这次会话
	 * 
	 * @param generatorSessionImpl
	 * @since yangyu @ Aug 8, 2013
	 */
	void interpret(GeneratorSession generatorSession);

}
