package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.bo.Site;

/**
 * 站点管理的统一接口，CMS模板引擎会获取当前站点，当前站点会被缓存
 * 
 * @author yangyu
 * @since Jan 16, 2013 3:17:41 PM
 */
public interface SiteManager {

	/**
	 * 获取当前站点，引擎会自动缓存的当前站点
	 * 
	 * @return
	 * @throws CurrentSiteNotFoundException
	 */
	Site getCurrent();

	/**
	 * 增加站点
	 * 
	 * @param site
	 * @return
	 */
	int addNew(Site site);

	/**
	 * 更新站点，如果是当前站点，更新缓存中的站点
	 * 
	 * @param site
	 * @return
	 */
	void update(Site site);

	/**
	 * 删除站点，当前站点不允许删除
	 * 
	 * @param site
	 * @return
	 */
	void delete(Site site);

	/**
	 * 设置当前站点，并触发相关事件
	 * 
	 * @param site
	 * @return
	 */
	Site changeCurrent(Site site);

	/**
	 * 取消当前站点
	 * 
	 * @param site
	 * @return
	 * @since yangyu @ Aug 7, 2013
	 */
	void cancelCurrent(Site site);

}
