/*
 * Created: liushen@Jul 13, 2010 5:39:00 PM
 */
package com.trs.dev4.jdk16.utils;

import java.util.List;

import org.json.JSONException;

/**
 * 按需生成JSON表达式；对外屏蔽JSON对象的内部处理.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class JSONBuilder {

	org.json.JSONObject jsonObj = new org.json.JSONObject();

	private static final String[] ALLFIELDS = { "*" };

	/**
	 * 
	 * @since liushen @ Jul 6, 2010
	 */
	public JSONBuilder() {
	}

	public JSONBuilder add(String key, int value) {
		try {
			jsonObj.put(key, value);
		} catch (JSONException e) {
			// TODO: liushen@Jan 7, 2011: 抛出运行期异常更合适？
			e.printStackTrace();
		}
		return this;
	}

	public JSONBuilder add(String key, Object value) {
		try {
			jsonObj.put(key, value);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return this;
	}

	public JSONBuilder addArray(String key, List<?> values) {
		return addArray(key, values, "*");
	}

	/**
	 * @param key
	 * @param values
	 * @param selectedFields
	 * @return
	 * @since liushen @ Jul 15, 2010
	 */
	public JSONBuilder addArray(String key, List<?> values,
			String... selectedFields) {
		if (selectedFields.length == 0) {
			selectedFields = ALLFIELDS;
		}
		try {
			org.json.JSONArray ary = new org.json.JSONArray();
			for (Object obj : values) {
				if (ArrayUtil.equals(ALLFIELDS, selectedFields)) {
					selectedFields = ReflectUtil
							.getAllFieldName(obj.getClass());
				}
				org.json.JSONArray aryObj = new org.json.JSONArray();
				for (int i = 0; i < selectedFields.length; i++) {
					aryObj.put(ReflectUtil
							.getFieldValue(obj, selectedFields[i]));
				}
				ary.put(aryObj);
			}
			jsonObj.put(key, ary);
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return null;
	}

	public String toJSONObjString() {
		return jsonObj.toString();
	}

}
