package com.trs.dev4.jdk16.cms.tag;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.bo.TagItem;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

public class LinkTagParser implements TagParser {

	protected static Log log = LogFactory.getLog(LinkTagParser.class);
	
	@Override
	public String parse(TagContext tagContext) {

		TagItem pTagItem = tagContext.getTagItem().getParent();
		if (!pTagItem.getName().equalsIgnoreCase("TRS_LINKGROUP")) {
			pTagItem = pTagItem.getParent();
		}
		String selectedClass = pTagItem.getAttribute("selectedClass");
		String defaultClass = pTagItem.getAttribute("defaultClass");
		String urlParam = pTagItem.getAttribute("urlParam");

		String value = getValue(tagContext, urlParam);
		value = StringUtils.isEmpty(value) ? "" : value;
		
		String selectedValue = "";
		if(tagContext.existAttribute("selectedValue")){
			selectedValue = tagContext.getValueFunctionValue("selectedValue");
		}

		// 完成
		String hrefValue = TagExpressionHelper.deleteParameter(tagContext, urlParam);
		if (!StringUtils.isEmpty(selectedValue)) {
			try {
				hrefValue = new StringBuilder(hrefValue).append("&").append(urlParam).append("=").append(
						URLEncoder.encode(selectedValue, "UTF-8")).toString();
			} catch (UnsupportedEncodingException e) {
				log.error("not support Encoding " + selectedValue);
			}
		}

		String innerHtml = TagExpressionHelper.parseInternalTemplate(tagContext, tagContext.getEntity());

		String classValue = "";

		if (selectedValue.equalsIgnoreCase(value)) {
			classValue = selectedClass;
		} else {
			classValue = defaultClass;
		}

		StringBuilder sb = new StringBuilder("<a href='");
		sb.append(hrefValue);
		sb.append("' class='");
		sb.append(classValue);
		sb.append("'>");
		sb.append(innerHtml);
		sb.append("</a>");
		return sb.toString();
	}
	
	private String getValue(TagContext tagContext, String urlParam) {
		return tagContext.getGeneratorSession().getRequestWrapper().getParameter(urlParam);
	}

}
