/*
 * Created: liushen@Oct 9, 2012 5:28:58 PM
 */
package com.trs.dev4.jdk16.schedule;

import java.util.concurrent.TimeUnit;

/**
 * 定时调度运行的触发条件。 <br>
 * 
 */
public class RunCondition {

	public static enum Type {
		FIXEDDELAY("固定间隔"), FIXEDRATE("固定频率");

		private String description;

		/**
		 * 
		 * @since liushen @ May 26, 2011
		 */
		private Type(String description) {
			this.description = description;
		}

		/**
		 * @see java.lang.Enum#toString()
		 * @since liushen @ May 26, 2011
		 */
		@Override
		public String toString() {
			return description;
		}
	}

	private Type type;

	private int fixedDelta;

	private TimeUnit timeUnit;

	/**
	 * @param type
	 * @param fixedDelta
	 * @param timeUnit
	 */
	public RunCondition(Type type, int fixedDelta, TimeUnit timeUnit) {
		this.type = (type == null) ? Type.FIXEDDELAY : type;
		this.fixedDelta = fixedDelta;
		this.timeUnit = (timeUnit == null) ? TimeUnit.SECONDS : timeUnit;
	}

	/**
	 * 以秒为单位，返回间隔时长。
	 * 
	 * @since liushen @ Oct 9, 2012
	 */
	public long getFixedDeltaAsSeconds() {
		return timeUnit.toSeconds(fixedDelta);
	}

	/**
	 * 以毫秒为单位，返回间隔时长。
	 * 
	 * @since liushen @ Oct 10, 2012
	 */
	public long getFixedDeltaAsMilliSeconds() {
		return timeUnit.toMillis(fixedDelta);
	}

	/**
	 * @return
	 * @since liushen @ Oct 9, 2012
	 */
	public boolean isAtFixedRate() {
		return type == Type.FIXEDRATE;
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Oct 10, 2012
	 */
	@Override
	public String toString() {
		if (isAtFixedRate()) {
			return "每" + getFixedDeltaAsSeconds() + "秒";
		} else {
			return "每隔" + getFixedDeltaAsSeconds() + "秒";
		}
	}

	/**
	 * 固定间隔或频率的时间长度，单位为 {@link #timeUnit} 。
	 * 
	 * @since liushen @ Oct 9, 2012
	 */
	public int getFixedDelta() {
		return fixedDelta;
	}

	/**
	 * @return the {@link #type}
	 */
	public Type getType() {
		return type;
	}

	/**
	 * @return the {@link #timeUnit}
	 */
	public TimeUnit getTimeUnit() {
		return timeUnit;
	}

}
