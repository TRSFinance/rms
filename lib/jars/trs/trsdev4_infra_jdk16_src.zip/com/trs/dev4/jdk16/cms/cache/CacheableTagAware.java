/*
 * Created: Administrator@2013-11-8 上午09:31:19
 */
package com.trs.dev4.jdk16.cms.cache;

import com.trs.dev4.jdk16.cms.TagAware;
import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.template.CachedOperationCallback;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * 职责: <br>
 * 
 */
public class CacheableTagAware<T> implements TagAware<T> {

	private TagAware<T> tagAware;

	private Settings settings;

	/**
	 * @param tagAware
	 * @param settings
	 */
	public CacheableTagAware(TagAware<T> tagAware, Settings settings) {
		this.tagAware = tagAware;
		this.settings = settings;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getExtraProperty(com.trs.dev4.jdk16.cms.bo.PublishObject, java.lang.String,
	 *      com.trs.dev4.jdk16.cms.bo.TagContext)
	 * @since Administrator @ 2013-11-8
	 */
	@Override
	public Object getExtraProperty(final PublishObject publishable, final String key, final TagContext tagContext) {
		String cacheKey = new StringBuilder("getExtraProperty_").append(tagAware.getTagClass().getSimpleName()).append(
				"_id_").append(publishable.getPropertyAsInt(tagContext, "id")).append("_").append(String.valueOf(key))
				.toString();
		return settings.getCachedOperationTemplate().obtainCachedData(cacheKey, tagAware.objectCachedTime(),
				new CachedOperationCallback() {
					@Override
					public Object doTakeCachingData() {
						return tagAware.getExtraProperty(publishable, key, tagContext);
					}
				});
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getPublishObject(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since Administrator @ 2013-11-8
	 */
	@SuppressWarnings("unchecked")
	@Override
	public T getPublishObject(final SearchFilter searchFilter) {

		String cacheKey = new StringBuilder("getPublishObject_").append(
				tagAware.getTagClass().getSimpleName()).append("_").append(searchFilter.getCacheKey()).toString();

		return (T) settings.getCachedOperationTemplate().obtainCachedData(cacheKey, tagAware.objectCachedTime(),
				new CachedOperationCallback() {

					@Override
					public Object doTakeCachingData() {
						return tagAware.getPublishObject(searchFilter);
					}

				});
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getPublishObjectById(int)
	 * @since Administrator @ 2013-11-8
	 */
	@SuppressWarnings("unchecked")
	@Override
	public T getPublishObjectById(final int id) {
		String cacheKey = new StringBuilder("getPublishObjectById_").append(
				tagAware.getTagClass().getSimpleName()).append("_").append(id).toString();
		
		return (T) settings.getCachedOperationTemplate().obtainCachedData(cacheKey, tagAware.objectCachedTime(),
				new CachedOperationCallback() {
					@Override
					public Object doTakeCachingData() {
						return tagAware.getPublishObjectById(id);
					}

				});
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getTagClass()
	 * @since Administrator @ 2013-11-8
	 */
	@Override
	public Class<T> getTagClass() {
		return tagAware.getTagClass();
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#objectCachedTime()
	 * @since Administrator @ 2013-11-8
	 */
	@Override
	public int objectCachedTime() {
		return tagAware.objectCachedTime();
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#pagePublishObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since Administrator @ 2013-11-8
	 */
	@SuppressWarnings("unchecked")
	@Override
	public PagedList<T> pagePublishObjects(final SearchFilter searchFilter) {
		String cacheKey = new StringBuilder("pagePublishObjects_").append(
				tagAware.getTagClass().getSimpleName()).append("_").append(searchFilter.getCacheKey()).toString();
		return (PagedList<T>) settings.getCachedOperationTemplate().obtainCachedData(cacheKey,
				tagAware.objectCachedTime(),
				new CachedOperationCallback() {
					@Override
					public Object doTakeCachingData() {
						return tagAware.pagePublishObjects(searchFilter);
					}
				});
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#specialTagAttribute()
	 * @since Administrator @ 2013-11-8
	 */
	@Override
	public String[] specialTagAttribute() {
		return tagAware.specialTagAttribute();
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#total(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since Administrator @ 2013-11-8
	 */
	@Override
	public int total(final SearchFilter sf) {
		String cacheKey = new StringBuilder("total_")
				.append(tagAware.getTagClass().getSimpleName()).append("_").append(sf.getCacheKey()).toString();

		return (Integer) settings.getCachedOperationTemplate().obtainCachedData(cacheKey, tagAware.objectCachedTime(),
				new CachedOperationCallback() {
					@Override
					public Object doTakeCachingData() {
						return tagAware.total(sf);
					}
				});
	}

}
