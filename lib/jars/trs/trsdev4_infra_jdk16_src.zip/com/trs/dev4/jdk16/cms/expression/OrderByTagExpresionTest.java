package com.trs.dev4.jdk16.cms.expression;

import org.junit.Before;
import org.junit.Test;

/**
 * id desc
 * 
 * @author yangyu
 * @since Mar 19, 2013 2:04:41 PM
 */
public class OrderByTagExpresionTest {

	@Before
	public void setUp() throws Exception {
	}

	/**
	 * 参数不符合要求(长度，不存在属性，第二个参数不在desc 和asc之间)
	 */
	@Test
	public void testWrongLength() {

	}

	@Test
	public void testFirstPropertyNotFound() {

	}

	@Test
	public void testLastPropertyNotFound() {

	}

	/**
	 * 参数正确
	 */
	@Test
	public void testBuild() {

	}

	/**
	 * 第二个参数通过函数获取，符合Value模式
	 */

	@Test
	public void testBuildWithExpression() {

	}
}
