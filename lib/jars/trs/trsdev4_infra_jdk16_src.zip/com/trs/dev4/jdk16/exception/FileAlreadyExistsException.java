/*
 * Created: xuyan@2014-1-15 上午09:27:40
 */
package com.trs.dev4.jdk16.exception;

/**
 * 职责:表示目标文件已经存在. <br>
 * 
 */
@SuppressWarnings("serial")
public class FileAlreadyExistsException extends RootException {

	/**
	 * @param msg
	 * @param cause
	 */
	public FileAlreadyExistsException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public FileAlreadyExistsException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public FileAlreadyExistsException(Throwable cause) {
		super(cause);
	}

}
