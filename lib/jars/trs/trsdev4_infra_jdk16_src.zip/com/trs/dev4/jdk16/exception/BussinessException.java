/*
 * Created: liushen@Apr 15, 2010 10:18:31 AM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 业务异常，比如违反业务规则. <br>
 * 
 */
@SuppressWarnings("serial")
public class BussinessException extends RootException {

	/**
	 * @param msg
	 * @param cause
	 */
	public BussinessException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public BussinessException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public BussinessException(Throwable cause) {
		super(cause);
	}

}
