/*
 * Created: liushen@Feb 1, 2012 9:10:14 AM
 */
package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.session.RequestContext;

/**
 * 对模板具有感应模块的抽象，用于满足论坛的版区、MAS的分类等的不同对象采用模板的需要。<br>
 * 
 */
public interface ITemplateAware {

	/**
	 * 根据请求上下文(包括URL等信息)，解析出匹配的模板名。
	 * 
	 * @param reqCtx
	 *            请求上下文
	 * @return 匹配的模板名；如果该请求不存在模板，则返回<code>null</code>.
	 * @since liushen @ Feb 1, 2012
	 */
	String resolveTemplateName(RequestContext reqCtx);

}
