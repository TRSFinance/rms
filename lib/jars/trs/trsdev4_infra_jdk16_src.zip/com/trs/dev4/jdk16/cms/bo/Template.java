package com.trs.dev4.jdk16.cms.bo;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Lob;
import javax.persistence.MappedSuperclass;
import javax.persistence.Table;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.PolymorphismType;

import com.trs.dev4.jdk16.model.BaseEntity;

/**
 * 用于描述模板，实现{@link ITemplate}
 */
@Entity
@Table(name = "trstemplates")
@MappedSuperclass
@org.hibernate.annotations.Entity(polymorphism = PolymorphismType.EXPLICIT, dynamicUpdate = true)
@org.hibernate.annotations.GenericGenerator(name = "idStrategy", strategy = "native", parameters = { @Parameter(name = "sequence", value = "SEQ_TEMPLATE_ID") })
public class Template extends BaseEntity {

	/**
	 * 
	 */
	@Column(name = "`trsname`")
	private String name;
	/**
	 * 模板内容
	 */
//	MySQL 5.1.36: Column length too big for column 'trscontent' (max = 21845); use BLOB or TEXT instead  
	// 但对同一个mysql，论坛建成了，MAS有上述错误，可能和JDBC驱动版本有关，或者就是论坛是先前hbm建的
	@Lob
	@Basic(fetch = FetchType.EAGER)	
	@Column(name = "`trscontent`", length = 655350)
	private String content;
	/**
	 * 校验标记
	 */
	private String checkSum;

	/**
	 * 模板的类型
	 */
	private String objectType;

	/**
	 * 模板的对应的类型的ID
	 */
	@Column(name = "`objectId`")
	private int objectId;
	/**
	 * 内容大小
	 */
	@Column(name = "`trssize`")
	private int size;
	/**
	 * @since TRS @ Feb 16, 2011
	 */
	private static final long serialVersionUID = 1L;

	// 构造函数
    public Template() {
        super();
    }
    
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the content
	 */
	public String templateName() {
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}

	public String getContent() {
		return content;
	}

	/**
	 * @return the checkSum
	 */
	public String getCheckSum() {
		return checkSum;
	}

	/**
	 * @param checkSum the checkSum to set
	 */
	public void setCheckSum(String checkSum) {
		this.checkSum = checkSum;
	}

	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * @return the objectId
	 */
	public int getObjectId() {
		return objectId;
	}

	/**
	 * @param objectId the objectId to set
	 */
	public void setObjectId(int objectId) {
		this.objectId = objectId;
	}

	/**
	 * @return the objectType
	 */
	public String getObjectType() {
		return objectType;
	}

	/**
	 * @param objectType the objectType to set
	 */
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	
}