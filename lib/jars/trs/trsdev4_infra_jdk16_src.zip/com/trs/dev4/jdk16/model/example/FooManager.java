/*
 * Created: liushen@Oct 24, 2009 3:12:30 PM
 */
package com.trs.dev4.jdk16.model.example;

import com.trs.dev4.jdk16.boexample.ArchivedFoo;
import com.trs.dev4.jdk16.boexample.Foo;
import com.trs.dev4.jdk16.dao.IAccessor;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.model.BaseManager;

/**
 * 示例领域对象的业务逻辑.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class FooManager extends BaseManager<Foo> implements IFooManager {

	private IAccessor<ArchivedFoo> archivedFooAccessor;

	private IAccessor<AssignedFoo> assignedFooAccessor;

	public FooManager() {
		// new Exception("FooManager").printStackTrace();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.example.IFooManager#addNewArchivedFoo(com.trs.dev4.jdk16.boexample.ArchivedFoo)
	 * @since liushen @ May 10, 2010
	 */
	@Override
	public void addNewArchivedFoo(ArchivedFoo archivedFoo) {
		archivedFooAccessor.insert(archivedFoo);
	}

	public void addNewAssignedFoo(AssignedFoo assignedFoo) {
		assignedFooAccessor.insert(assignedFoo);
	}

	/**
	 * @param archivedFooDao
	 *            the {@link #archivedFooAccessor} to set
	 */
	public void setArchivedFooAccessor(IAccessor<ArchivedFoo> archivedFooDao) {
		this.archivedFooAccessor = archivedFooDao;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.example.IFooManager#getArchived(int)
	 * @since liushen @ May 17, 2010
	 */
	@Override
	public ArchivedFoo getArchived(int id) {
		return archivedFooAccessor.getObject(id);
	}

	public AssignedFoo getAssigned(int id) {
		return assignedFooAccessor.getObject(id);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.example.IFooManager#totalArchived()
	 * @since liushen @ May 17, 2010
	 */
	@Override
	public int totalArchived() {
		return archivedFooAccessor.total();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.example.IFooManager#pagedArchived()
	 * @since liushen @ May 17, 2010
	 */
	@Override
	public PagedList<ArchivedFoo> pagedArchived() {
		return archivedFooAccessor.pagedAll();
	}

	public PagedList<AssignedFoo> pagedAssigned() {
		return assignedFooAccessor.pagedAll();
	}

	/**
	 * @param assignedFooAccessor
	 *            the {@link #assignedFooAccessor} to set
	 */
	public void setAssignedFooAccessor(
			IAccessor<AssignedFoo> assignedFooAccessor) {
		this.assignedFooAccessor = assignedFooAccessor;
	}

}
