package com.trs.dev4.jdk16.session;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.trs.dev4.jdk16.session.impl.ApplicationSession;

/**
 *
 *
 */
public interface ISessionHandler<T extends ISessionUser> {
	/**
	 * 是否普通登录
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 14, 2010
	 */
	public boolean isLogined(HttpServletRequest request,
			HttpServletResponse response);

	/**
	 * 获取个人门户的用户身份
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 14, 2010
	 */
	public T getUser(HttpServletRequest request);

	/**
	 * 获取个人门户的用户身份
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 14, 2010
	 */
	public T getUser(HttpServletRequest request, HttpServletResponse response);

	/**
	 * 用户登录个人门户
	 * 
	 * @param request
	 * @param user
	 * @since fangxiang @ Apr 14, 2010
	 */
	public void login(HttpServletRequest request, HttpServletResponse response,
			T user);

	/**
	 * 普通用户退出
	 * 
	 * @param request
	 * @since fangxiang @ Apr 14, 2010
	 */
	public void logout(HttpServletRequest request, HttpServletResponse response);

	/**
	 * 获取访问的用户总数
	 * 
	 * @return
	 * @since fangxiang @ Apr 14, 2010
	 */
	public int countTotalUsers();

	/**
	 * 获取管理台登录用户数
	 * 
	 * @return
	 * @since fangxiang @ Jan 22, 2011
	 */
	public int countConsoleUsers();

	/**
	 * 获取登录的用户数
	 * 
	 * @return
	 * @since fangxiang @ Apr 14, 2010
	 */
	public int countLoginedUsers();

	/**
	 * 获取用户别名
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 20, 2010
	 */
	public String getUserNick(HttpServletRequest request,
			HttpServletResponse response);

	/**
	 * 获取用户编号
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 20, 2010
	 */
	public int getUserId(HttpServletRequest request,
			HttpServletResponse response);

	/**
	 * 设置验证码
	 * 
	 * @param request
	 * @param verifyCode
	 * @since fangxiang @ Apr 20, 2010
	 */
	public void setVerifyCode(HttpServletRequest request,
			HttpServletResponse response, String verifyCode);

	/**
	 * 检查验证码是否一致
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 20, 2010
	 */
	public boolean isVerified(HttpServletRequest request,
			HttpServletResponse response);

	/**
	 * 判断用户是否在线
	 * 
	 * @param userName
	 * @return true表示在线，false表示不在线
	 * @since fangxiang @ Oct 19, 2010
	 */
	public boolean isOnline(String userName);

	/**
	 * 获取统计信息
	 * 
	 * @return
	 * @since fangxiang @ Dec 6, 2010
	 */
	public Map<String, Object> statistic();

	/**
	 * 获取应用的会话
	 * 
	 * @param request
	 * @param response
	 * @param b
	 * @return
	 * @since fangxiang @ Dec 6, 2010
	 */
	public ApplicationSession getApplicationSession(HttpServletRequest request,
			HttpServletResponse response, boolean create);

	/**
	 * 获取应用的会话
	 * 
	 * @param request
	 *            请求
	 * @param response
	 *            响应
	 * @param create
	 *            是否创建新会话
	 * @return
	 */
	public String getApplicationSessionId(HttpServletRequest request,
			HttpServletResponse response, boolean create);

	/**
	 * 更新会话的最后访问时间
	 * 
	 * @param as
	 *            会话
	 */
	public void updateLastModified(ApplicationSession as);

	/**
	 * 判断请求是否属于忽略列表，不创建会话
	 * 
	 * @param request
	 *            请求
	 * @return true表示忽略，false表示不忽略
	 */
	public boolean ignoreUrl(HttpServletRequest request,
			HttpServletResponse response);

	/**
	 * 判断指定的用户是否正在登陆
	 * 
	 * @param userName
	 *            用户名
	 * @return true表示正在登陆，false表示未登录
	 */
	public boolean isLogined(String userName);
	/**
	 * 根据会话编号获取用户对象
	 * 
	 * @param applicationSessionId
	 *            会话编号
	 * @return 用户对象集合
	 * @since fangxiang @ Jan 22, 2011
	 */
	public ApplicationSession getApplicationSession(String applicationSessionId);

	/**
	 * 根据用户获得会话编号
	 * 
	 * @param userName
	 *            用户名
	 * @return 会话编号集合
	 * @since fangxiang @ Jan 22, 2011
	 */
	public List<ApplicationSession> listApplicationSessions(String userName);

	/**
	 * 获取最大的会话数目
	 * 
	 * @return 最大会话数目
	 * @since fangxiang @ Jan 22, 2011
	 */
	public int getSessionLimit();

	/**
	 * 统计富余的会话数目
	 * 
	 * @param consoleInclude
	 *            是否包含控制台用户
	 * @return 富余的会话数目
	 * @since fangxiang @ Jan 22, 2011
	 */
	public int countFreeSessions(boolean consoleInclude);
}