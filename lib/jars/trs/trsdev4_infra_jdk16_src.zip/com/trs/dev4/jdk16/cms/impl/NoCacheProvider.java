package com.trs.dev4.jdk16.cms.impl;

import com.trs.dev4.jdk16.cms.CacheProvider;
import com.trs.dev4.jdk16.cms.cache.CachedResult;

/**
 * 不使用缓存的Provider
 * 
 * @author yangyu
 * @since Jan 16, 2013 5:21:36 PM
 */
public class NoCacheProvider implements CacheProvider {

	public void clear() {

	}

	public CachedResult get(String key) {
		return CachedResult.NOTEXISTED;
	}

	public String getContent() {
		return null;
	}

	public void remove(String key) {

	}

	public void set(String key, Object object) {

	}

	/**
	 * @see com.trs.dev4.jdk16.cms.CacheProvider#set(java.lang.String,
	 *      java.lang.Object, int)
	 * @since yangyu @ Jun 25, 2013
	 */
	@Override
	public void set(String key, Object object, int expr) {

	}

	/**
	 * @see com.trs.dev4.jdk16.cms.CacheProvider#initializeCache()
	 * @since yangyu @ Jun 25, 2013
	 */
	@Override
	public void initializeCache() {
		// TODO yangyu@Jun 25, 2013 5:51:17 PM: Auto-generated method stub

	}

}
