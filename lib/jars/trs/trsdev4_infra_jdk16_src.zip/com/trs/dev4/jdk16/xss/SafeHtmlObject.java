/*
 * Created: congli@2014-3-18 上午09:36:06
 */
package com.trs.dev4.jdk16.xss;

/**
 * 职责:XSS过滤对象，主要是看XSS字符串是否被过滤过 <br>
 * 
 */
public class SafeHtmlObject {

	/**
	 * 过滤后的字符串
	 */
	private String stringAfterXSSFilter;

	/**
	 * 是否被过滤
	 */

	private boolean isXSSFiltered;

	/**
	 * @return the {@link #stringAfterXSSFilter}
	 */
	public String getStringAfterXSSFilter() {
		return stringAfterXSSFilter;
	}

	/**
	 * @param stringAfterXSSFilter
	 *            the {@link #stringAfterXSSFilter} to set
	 */
	public void setStringAfterXSSFilter(String stringAfterXSSFilter) {
		this.stringAfterXSSFilter = stringAfterXSSFilter;
	}

	/**
	 * @return the {@link #isXSSFiltered}
	 */
	public boolean isXSSFiltered() {
		return isXSSFiltered;
	}

	/**
	 * @param isXSSFiltered
	 *            the {@link #isXSSFiltered} to set
	 */
	public void setXSSFiltered(boolean isXSSFiltered) {
		this.isXSSFiltered = isXSSFiltered;
	}

}
