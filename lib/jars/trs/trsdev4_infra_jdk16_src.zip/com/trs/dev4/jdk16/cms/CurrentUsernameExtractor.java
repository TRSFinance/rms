package com.trs.dev4.jdk16.cms;

import javax.servlet.ServletRequest;

/**
 * 外部系统如何获取当前用户，外部配置
 * 
 * @author yangyu
 * @since Mar 14, 2013 10:26:45 AM
 */
public interface CurrentUsernameExtractor {

	/**
	 * 当前用户的用户名
	 * 
	 * @param request
	 * @return
	 * @since yangyu @ Apr 27, 2013
	 */
	String getCurrentUsername(ServletRequest request);

	/**
	 * 当前用户是否登录
	 * 
	 * @param request
	 * @return
	 * @since yangyu @ Apr 27, 2013
	 */
	boolean isLogin(ServletRequest request);

}
