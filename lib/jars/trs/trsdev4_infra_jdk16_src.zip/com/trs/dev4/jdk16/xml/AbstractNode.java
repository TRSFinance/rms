/**
 * AbstractNode.java. created on 2006-6-1
 */
package com.trs.dev4.jdk16.xml;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 支持属性的节点。
 * 
 * @author liu kaixuan
 * @date 2006-6-1 16:50:54
 */
public abstract class AbstractNode implements Node {

	private int level ;

	protected String nodeName ;

	/**节点的属性，没有排列顺序*/
	protected Map<String, Object> attributes;

	/**
	 * @param nodeName 节点名称
	 */
	public AbstractNode(String nodeName){
		this.nodeName  = nodeName  ;
	}

	/**
	 * @see #addAttribute(String, Object)
	 */
	public void addAttribute(String name, int value){
		addAttribute(name, new Integer(value)) ;
	}

	/**
	 * @see #addAttribute(String, Object)
	 */
	public void addAttribute(String name, String value){
		addAttribute(name, (Object) value) ;
	}

	/**
	 * 添加一个节点属性，如果原来的属性已经存在，则覆盖。名称区分大小写。
	 * @param name 属性名称
	 * @param value 属性值。如果为null，作为""处理。
	 */
	public void addAttribute(String name, Object value){
		if(attributes == null){
			attributes = new HashMap<String, Object>();
		}

		if(value == null) value = "" ;

		attributes.put(name, value) ;
	}

	protected String getFmtWhiteSpace(){
		StringBuffer sb = new StringBuffer(32) ;
		//格式化
		for(int i = 0 ; i < getLevel() ; i++){
			sb.append("    ") ;
		}

		return sb.toString() ;
	}

	public String toXML() {
		StringBuffer sb = new StringBuffer(128) ;

		//格式化
		sb.append(getFmtWhiteSpace()) ;

		sb.append("<").append(nodeName) ;

		if(attributes != null){
			Iterator<String> keys = attributes.keySet().iterator();
			while(keys.hasNext()){
				Object key = keys.next() ;
				Object value = attributes.get(key) ;
				sb.append(" ").append(key).append("=\"").append(value).append("\"") ;
			}
		}

		if(!hasNodeValue()){ //没有接节点值
			sb.append("/>") ;
		}else{
			sb.append(">").append(getNodeValue()).append("</").append(nodeName).append(">") ;
		}

		return sb.toString() ;
	}

	/**
	 * 
	 * @return
	 */
	protected abstract boolean hasNodeValue() ;

	/**
	 * 
	 * @return
	 */
	protected abstract String getNodeValue() ;

	/**
	 * 
	 * @see com.trs.dev4.jdk16.xml.Node#setLevel(int)
	 */
	@Override
	public void setLevel(int level) {
		this.level = level ;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.xml.Node#getLevel()
	 */
	@Override
	public int getLevel() {
		return level ;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AbstractNode [level=" + level + ", nodeName=" + nodeName
				+ ", attributes=" + attributes + "]";
	}
}
