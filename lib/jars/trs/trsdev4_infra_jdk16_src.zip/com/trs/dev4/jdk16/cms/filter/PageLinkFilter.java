package com.trs.dev4.jdk16.cms.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.GeneratorSessionFactory;
import com.trs.dev4.jdk16.cms.PageLinkManager;
import com.trs.dev4.jdk16.cms.SiteManager;
import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.RequestWrapper;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.servlet24.BaseFilter;

/**
 * 
 * 职责: 用于置标组件的请求转发
 * 
 */
public class PageLinkFilter extends BaseFilter {

	protected static Logger LOG = Logger.getLogger(PageLinkFilter.class);

	private GeneratorSessionFactory generatorSessionFactory;
	
	private SiteManager siteManager;;

	private Settings settings;

	private PageLinkManager pageLinkManager;

	/**
	 * 
	 * 用于收集客户端发来的请求，判断当前应用是否需要使用置标组件处理（当前站点是否存在）；
	 * 
	 * 如果当前站点存在，根据请求的URI获取相应的PageLink以及模板，将模板的内容解析成HTML并返回给客户端
	 * 
	 * 如果当前站点不存在，直接交给下一个Filter处理
	 * 
	 * @see com.trs.dev4.jdk16.servlet24.BaseFilter#doFilterInternal(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 * @since yangyu @ Apr 11, 2013
	 */
	@Override
	protected void doFilterInternal(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
		Site site = siteManager.getCurrent();
		if (site != null) {
			RequestWrapper requestWrapper = RequestWrapper.getWebRequestContext(request);
			PageLink pageLink = pageLinkManager.getFromRequestURI(site, requestWrapper, settings.getMethodPart());
			if (pageLink != null) {
				doContentGenerate(requestWrapper, response, site, pageLink);	
			} else {
				filterChain.doFilter(request, response);
			}
		} else {
			filterChain.doFilter(request, response);
		}
	}

	/**
	 * 使用前台页面定制组件解析模板内容
	 * 
	 * @param requestWrapper
	 * @param response
	 * @param site
	 * @param pageLink
	 * @throws IOException
	 * @since yangyu @ Jul 10, 2013
	 */
	private void doContentGenerate(RequestWrapper requestWrapper, ServletResponse response, Site site, PageLink pageLink)
			throws IOException {
		PrintWriter printWriter = preparePrintWriter(response);
		GeneratorSession generatorSession = generatorSessionFactory.getCurrentSession();
		generatorSession.bind(site, pageLink, requestWrapper, printWriter);
		try {
			generatorSession.responseGeneratedHTML();
		} catch (TemplateException e) {
			LOG.error("The template of current pageLink [" + pageLink + "] can not parsed appropriately");
			printWriter.println(e.getMessage());
		} finally {
			generatorSession.clear();
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.servlet24.BaseFilter#initInternal(javax.servlet.FilterConfig)
	 * @since yangyu @ Apr 3, 2013
	 */
	@Override
	protected boolean initInternal(FilterConfig config) throws ServletException {

		ApplicationContext applicationContext = getApplicationContext(filterConfig);
		generatorSessionFactory = (GeneratorSessionFactory) applicationContext.getBean("generatorSessionFactory");

		settings = generatorSessionFactory.getSettings();
		pageLinkManager = settings.getCachablePageLinkManager();
		siteManager = settings.getCachableSiteManager();

		LOG.info("Initializing PageLinkFilter successfully");
		
		return true;
	}

	/**
	 * 准备PrintWriter，支持中文编码输出
	 * 
	 * @param response
	 * @return
	 * @throws IOException
	 * @since yangyu @ Apr 11, 2013
	 */
	private PrintWriter preparePrintWriter(ServletResponse response) throws IOException {
		response.setContentType("text/html");
		response.setCharacterEncoding("utf-8");
		return response.getWriter();
	}
	
	protected ApplicationContext getApplicationContext(FilterConfig filterConfig) {
		ServletContext application = filterConfig.getServletContext();
		return WebApplicationContextUtils.getWebApplicationContext(application);
	}
	
	public void setGeneratorSessionFactory(GeneratorSessionFactory generatorSessionFactory) {
		this.generatorSessionFactory = generatorSessionFactory;
	}

	public void setSiteManager(SiteManager siteManager) {
		this.siteManager = siteManager;
	}

	public void setPageLinkManager(PageLinkManager pageLinkManager) {
		this.pageLinkManager = pageLinkManager;
	}
	
	/**
	 * @see com.trs.dev4.jdk16.servlet24.BaseFilter#destroyInternal()
	 * @since yangyu @ Apr 3, 2013
	 */
	@Override
	protected void destroyInternal() {

	}

}
