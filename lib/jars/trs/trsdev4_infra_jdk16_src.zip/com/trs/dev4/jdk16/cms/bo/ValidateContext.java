package com.trs.dev4.jdk16.cms.bo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import org.apache.commons.lang.StringUtils;

import com.trs.dev4.jdk16.cms.exp.ParentObjNotFoundException;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

/**
 * 职责: 模板里的每个标签验证后，都对应一个tagContainer对象<br>
 * 
 */
public class ValidateContext {

	static final String REG_TAG_NAME = "TRS_[a-zA-Z0-9]+";
	static final String REG_TAG_ATTRIBUTE = "\\S+?=\".*?\"|\\S+?='.*?'";
	/**
	 * 标签名称
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	private String name;

	/**
	 * 父标签集合
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	private Stack<ValidateContext> parents = new Stack<ValidateContext>();

	/**
	 * 子标签集合
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	private List<ValidateContext> childrens = new ArrayList<ValidateContext>();

	/**
	 * 列号
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	private int line;

	/**
	 * 标签正文
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	private String content;

	/**
	 * 错误信息
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	private List<String> errorMsgs = new ArrayList<String>();

	/**
	 * 属性值
	 * 
	 * @since TRS信息技术股份有限公司 @ Oct 16, 2012
	 */
	private Map<String, String> attributes = new HashMap<String, String>();
	
	private Settings settings;

	public ValidateContext() {

	}

	public boolean isBeginTag() {
		return !(this.content.startsWith("</") || this.content.endsWith("/>"));
	}

	public boolean isEndTag() {
		return this.content.startsWith("</");
	}

	public boolean isEntireTag() {
		return this.content.endsWith("/>");
	}

	public ValidateContext(String tagContent) {
		this.content = tagContent;
		if (this.isEndTag()) {
			this.setName(TagExpressionHelper.substring(tagContent, "</", ">"));
		} else {
			this.setName(TagExpressionHelper.getMatchRegStr(tagContent, REG_TAG_NAME));
			List<String> tagContents = TagExpressionHelper.getMatchRegStrs(tagContent, REG_TAG_ATTRIBUTE);
			for (String expression : tagContents) {
				String[] temps = StringUtils.split(expression, "=");
				String key = temps[0];
				String value = temps[1];
				this.addAttribute(key.toUpperCase(), value.substring(1, value.length() - 1));
			}
		}
	}

	/**
	 * @param settings
	 * @param tagContent
	 */
	public ValidateContext(Settings settings, String tagContent) {
		this(tagContent);
		this.settings = settings;
	}

	/**
	 * @return the {@link #name}
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the {@link #name} to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	public Stack<ValidateContext> getParents() {
		return parents;
	}

	public void setParents(Stack<ValidateContext> parents) {
		this.parents = parents;
	}

	public List<ValidateContext> getChildrens() {
		return childrens;
	}

	public void setChildrens(List<ValidateContext> childrens) {
		this.childrens = childrens;
	}

	public int getLine() {
		return line;
	}

	public void setLine(int line) {
		this.line = line;
	}

	/**
	 * @return the {@link #content}
	 */
	public String getContent() {
		return content;
	}

	/**
	 * @param content
	 *            the {@link #content} to set
	 */
	public void setContent(String content) {
		this.content = content;
	}

	public List<String> getErrorMsgs() {
		return errorMsgs;
	}

	public void setErrorMsgs(List<String> errorMsgs) {
		this.errorMsgs = errorMsgs;
	}

	public Map<String, String> getAttributes() {
		return attributes;
	}

	public void setAttributes(Map<String, String> attributes) {
		this.attributes = attributes;
	}

	public void addChild(ValidateContext validateContext) {
		this.childrens.add(validateContext);
	}

	public void addAttribute(String key, String value) {
		attributes.put(key, value);
	}

	public void addError(String error) {
		errorMsgs.add("第" + line + "行标签" + name + "出错，错误信息为" + error);
	}

	public String getAttribute(String key) {
		return attributes.get(key);
	}

	public ValidateContext getDirectParent() {
		if (parents.isEmpty()) {
			return null;
		} else {
			return parents.peek();
		}
	}
	
	public String getObjValue() {
		String obj = this.getAttribute("OBJ");
		if (StringUtils.isEmpty(obj)) {
			Stack<ValidateContext> parents = this.getParents();
			while (!parents.isEmpty()) {
				obj = parents.pop().getAttribute("OBJ");
				if (!StringUtils.isEmpty(obj)) {
					break;
				}
			}
		}
		return obj;
	}
	
	public String getParentObjValue() {
		String obj = this.getAttribute("OBJ");
		int count = 0;
		if (!StringUtils.isEmpty(obj)) {
			count++;
		}
		
		Stack<ValidateContext> parents = this.getParents();
		while (!parents.isEmpty()) {
			obj = parents.pop().getAttribute("OBJ");
			if (!StringUtils.isEmpty(obj)) {
				count++;
				if (count == 2) {
					return obj;
				}
			}
		}
		throw new ParentObjNotFoundException();
	}

	public Settings getSettings() {
		return settings;
	}

	public void setSettings(Settings settings) {
		this.settings = settings;
	}

	/**
	 * @param name2
	 * @since Administrator @ 2013-12-6
	 */
	public boolean existAttribute(String name) {
		return attributes.containsKey(name.toUpperCase());
	}
	
	

}
