/*
 * Created: liushen@Feb 7, 2012 9:26:01 AM
 */
package com.trs.dev4.jdk16.utils.spring;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

/**
 * 用于发现Spring重复构造Bean的情况。 <br>
 * 
 */
public class DuplicateConstructionFinder implements BeanPostProcessor {

	private static final Logger LOG = Logger.getLogger(DuplicateConstructionFinder.class);

	private int actualPlanInitCount;
	private int actualSuccessInitedCount;
	private List<String> beanNames = new ArrayList<String>(200);

	/**
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessBeforeInitialization(java.lang.Object, java.lang.String)
	 * @since liushen @ Feb 7, 2012
	 */
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		actualPlanInitCount++;
		beanNames.add(beanName);
		if (LOG.isDebugEnabled()) {
			LOG.debug("Before Init, beanName: " + beanName + ", obj: " + bean);
		}
		return bean;
	}

	/**
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessAfterInitialization(java.lang.Object, java.lang.String)
	 * @since liushen @ Feb 7, 2012
	 */
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		actualSuccessInitedCount++;
		if (LOG.isDebugEnabled()) {
			LOG.debug("After Init, beanName: " + beanName + ", obj: " + bean);
		}
		return bean;
	}

	/**
	 * @return the {@link #actualPlanInitCount}
	 */
	public int getActualPlanInitCount() {
		return actualPlanInitCount;
	}

	/**
	 * @return the {@link #actualSuccessInitedCount}
	 */
	public int getActualSuccessInitedCount() {
		return actualSuccessInitedCount;
	}

	public String[] getActualPlanInitBeanNames() {
		return beanNames.toArray(new String[0]);
	}

}
