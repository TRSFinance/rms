/*
 * Created: liuyou@2010-4-21 下午01:53:27
 */
package com.trs.dev4.jdk16.actionlog.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.actionlog.IActionlogExtendable;
import com.trs.dev4.jdk16.actionlog.IActionlogManager;
import com.trs.dev4.jdk16.actionlog.LogEnums;
import com.trs.dev4.jdk16.actionlog.LogEnums.Result;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.BaseEntity;
import com.trs.dev4.jdk16.model.BaseManager;
import com.trs.dev4.jdk16.model.IEntity;
import com.trs.dev4.jdk16.session.ISessionUser;
import com.trs.dev4.jdk16.session.RequestContext;
import com.trs.dev4.jdk16.utils.ClassUtil;
import com.trs.dev4.jdk16.utils.DateUtil;

/**
 * 本地日志管理实现类
 * 
 * 
 */
public class LocalActionlogManager extends BaseManager<Actionlog> implements IActionlogManager {

	private final static Logger logger = Logger.getLogger(LocalActionlogManager.class);

	/**
	 * 注入系统标识
	 */
	private String sysFlag;

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlogManager#archive(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void archive(SearchFilter searchfilter) {

	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#saveOrUpdate(com.trs.dev4.jdk16.model.IEntity)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void saveOrUpdate(Actionlog log) {
		if (log.getResult() == Result.FAIL) {
			log.setOperDesc(log.getOperType() + ".errorlog");
		} else {
			log.setOperDesc(log.getOperType() + ".log");
		}
		super.update(log);
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlogManager#createActionLog(com.trs.dev4.jdk16.model.IEntity,
	 *      java.lang.String, com.trs.dev4.jdk16.actionlog.LogEnums.Result,
	 *      long, long)
	 * @since luofei@2010-4-21
	 */
	@Override
	public com.trs.dev4.jdk16.actionlog.impl.Actionlog createActionlog(IEntity ientity, String operType, Result result, long startTime, long spentTime) {
		Actionlog actionlog = new Actionlog();
		actionlog.setResult(result);
		actionlog.isScored();
		actionlog.setLogLevel(LogEnums.Level.INFO);
		actionlog.setOperType(LogEnums.LabelPrefix.OPERTYPE + operType);
		actionlog.setOperDesc(LogEnums.LabelPrefix.OPERDESC + operType);
		actionlog.setObjId(ientity.getId());
		actionlog.setOperUserId(-1);
		actionlog.setOperUserName("unknown");
		actionlog.setObjType(LogEnums.LabelPrefix.OBJTYPE + ClassUtil.getSimpleName(ientity).toLowerCase());
		actionlog.setStartTime(startTime);
		actionlog.setSpentTime(spentTime);
		actionlog.setSysFlag(sysFlag);
		return actionlog;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#update(com.trs.dev4.jdk16.model.IEntity)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void update(com.trs.dev4.jdk16.actionlog.impl.Actionlog actionlog) {
		this.saveOrUpdate(actionlog);
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlogManager#setSysFlag(java.lang.String)
	 * @since luofei@2010-4-21
	 */
	@Override
	public void setSysFlag(String s) {
		this.sysFlag = s;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlogManager#createActionlog(java.lang.Object,java.lang.Object,
	 *      java.lang.String, com.trs.dev4.jdk16.actionlog.LogEnums.Result,
	 *      long, long)
	 * @since fangxiang @ Nov 23, 2010
	 */
	@Override
	public Actionlog createActionlog(Object operator, Object object, String operType, Result result, long startTime, long spentTime, String applicationKey) {
		if (applicationKey == null) {
			applicationKey = sysFlag;
		}
		// 设置操作者
		Actionlog actionlog = new Actionlog();
		if (ISessionUser.class.isInstance(operator)) {
			ISessionUser sessionUser = (ISessionUser) operator;
			if (sessionUser != null) {
				actionlog.setRemoteAddr(sessionUser.getLoginedIP());
				actionlog.setOperUserId(sessionUser.getId());
				actionlog.setOperUserName(sessionUser.getUserName());
				actionlog.setCreatedTime(DateUtil.getCurrentTimeMillis());
				actionlog.setCreatedUser(sessionUser.getUserName());
				actionlog.setCreatedUserId(sessionUser.getId());
			}
		} else if (RequestContext.class.isInstance(operator)) {
			RequestContext requestContext = (RequestContext) operator;
			actionlog.setRemoteAddr(requestContext.getClientIP());
			actionlog.setOperUserId(requestContext.getUserId());
			actionlog.setOperUserName(requestContext.getUserName());
			actionlog.setCreatedTime(DateUtil.getCurrentTimeMillis());
			actionlog.setCreatedUser(requestContext.getUserName());
			actionlog.setCreatedUserId(requestContext.getUserId());
			actionlog.setUserAgent(requestContext.getUserAgent());
			actionlog.setProxyIPs(requestContext.getProxyIPs());
			actionlog.setCallerStackBrief(requestContext.getCallerStackBrief());
			applicationKey = requestContext.getSysFlag();
		} else {
			logger.debug("Operator(" + operator + ") isn't ISessionUser instance.");
			actionlog.setRemoteAddr("(localhost)");
			actionlog.setOperUserId(-2);
			actionlog.setOperUserName(operator.toString());
			actionlog.setCreatedUser(operator.toString());
			actionlog.setCreatedTime(DateUtil.getCurrentTimeMillis());
			actionlog.setCreatedUserId(-2);
		}
		//
		actionlog.setResult(result);
		actionlog.isScored();
		actionlog.setLogLevel(LogEnums.Level.INFO);
		actionlog.setOperType(applicationKey + "." + operType);
		// 设置对象内容
		if (IEntity.class.isInstance(object)) {
			IEntity entity = (IEntity) object;
			actionlog.setObjId(entity.getId());
			if (object instanceof BaseEntity) {
				actionlog.setOperTitle(((BaseEntity) object).getDescription());
			} else {
				actionlog.setOperTitle(entity.toString());
			}
			logger.debug("Object(" + object + ") is IEntity instance.");
		} else {
			actionlog.setOperTitle(object.toString());
			logger.debug("Object(" + object + ") isn't IEntity instance.");
		}
		if (IActionlogExtendable.class.isInstance(object)) {
			IActionlogExtendable extendable = (IActionlogExtendable) object;
			actionlog.setExtendField1(extendable.getExtend1());
			actionlog.setExtendField2(extendable.getExtend2());
			actionlog.setExtendField3(extendable.getExtend3());
			logger.debug("Object(" + object + ") is IActionlogExtendable instance,extend1:" + actionlog.getExtendField1() + ",extend2:"
					+ actionlog.getExtendField2() + ",extend3:" + actionlog.getExtendField3());
		} else {
			logger.debug("Object(" + object + ") isn't IActionlogExtendable instance.");
		}
		//
		actionlog.setObjType(applicationKey + "." + object.getClass().getSimpleName().toLowerCase() + ".objType");
		actionlog.setStartTime(startTime);
		actionlog.setSpentTime(spentTime);
		actionlog.setSysFlag(applicationKey);
		return actionlog;
	}

	/**
	 * @see com.trs.dev4.jdk16.actionlog.IActionlogManager#getAndUpdateUnscored(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public List<Actionlog> getAndUpdateUnscored(SearchFilter filter) {
		return new ArrayList<Actionlog>();
	}

}
