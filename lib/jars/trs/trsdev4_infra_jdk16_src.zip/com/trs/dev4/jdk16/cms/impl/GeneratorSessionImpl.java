package com.trs.dev4.jdk16.cms.impl;

import java.io.PrintWriter;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.trs.dev4.jdk16.cms.CacheProvider;
import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.TemplateInterpreter;
import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.RequestWrapper;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.bo.Template;
import com.trs.dev4.jdk16.cms.enu.InterpreterType;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

/**
 * 
 * 职责: GeneratorSession的实现类
 * 
 * 每次Request对应创建一个GeneratorSessionImpl
 * 
 * 保存请求中的过程参数，包括当前站点，当前映射，Request封装
 * 
 * 也包含组件的全局配置，位于成员变量Settings中
 * 
 */
public class GeneratorSessionImpl implements GeneratorSession {

	private Site site;

	private PageLink pageLink;

	private PrintWriter printWriter;

	private Settings settings;

	private RequestWrapper requestWrapper;
	
	private CacheProvider assignedCacheProvider;
	
	private InterpreterType assignedInterpreterType;
	
	private String assignedContent;
	
	private String templateName;
	
	private boolean neetNotCompress = false;
	
	/**
	 * @param settings
	 */
	public GeneratorSessionImpl(Settings settings) {
		super();
		this.settings = settings;
	}

	/**
	 * 绑定参数到GeneratorSession中
	 * 
	 * @see com.trs.dev4.jdk16.cms.GeneratorSession#bind(com.trs.dev4.jdk16.cms.bo.Settings,
	 *      com.trs.dev4.jdk16.cms.bo.Site, com.trs.dev4.jdk16.cms.bo.PageLink,
	 *      com.trs.dev4.jdk16.cms.bo.RequestWrapper, java.io.PrintWriter)
	 * @since yangyu @ Apr 11, 2013
	 */
	public void bind(Site site, RequestWrapper requestWrapper, PrintWriter writer) {
		this.site = site;
		this.requestWrapper = requestWrapper;
		this.printWriter = writer;
	}

	/**
	 * 绑定参数到GeneratorSession中
	 * 
	 * @see com.trs.dev4.jdk16.cms.GeneratorSession#bind(com.trs.dev4.jdk16.cms.bo.Settings,
	 *      com.trs.dev4.jdk16.cms.bo.Site, com.trs.dev4.jdk16.cms.bo.PageLink,
	 *      com.trs.dev4.jdk16.cms.bo.RequestWrapper, java.io.PrintWriter)
	 * @since yangyu @ Apr 11, 2013
	 */
	public void bind(Settings settings, Site site, PageLink pageLink, RequestWrapper requestWrapper, PrintWriter writer) {
		this.settings = settings;
		this.bind(site, pageLink, requestWrapper, writer);
	}
	
	/**
	 * @see com.trs.dev4.jdk16.cms.GeneratorSession#bind(com.trs.dev4.jdk16.cms.bo.Site,
	 *      com.trs.dev4.jdk16.cms.bo.EmptyPageLink,
	 *      com.trs.dev4.jdk16.cms.bo.RequestWrapper, java.io.PrintWriter)
	 * @since yangyu @ May 17, 2013
	 */
	@Override
	public void bind(Site site, PageLink pageLink, RequestWrapper requestWrapper, PrintWriter printWriter) {
		this.site = site;
		this.pageLink = pageLink;
		this.requestWrapper = requestWrapper;
		this.printWriter = printWriter;
		if (pageLink != null) {
			this.templateName = pageLink.getTemplateName();
		}
	}

	/**
	 * 将模板的解析结果HTML输出到客户端
	 * 
	 * @see com.trs.dev4.jdk16.cms.GeneratorSession#responseGeneratedHTML()
	 * @since yangyu @ Apr 11, 2013
	 */
	public void responseGeneratedHTML() {
		
		TemplateInterpreter templateInterpreter = settings.getTemplateInterpreter();
		
		templateInterpreter.interpret(this);
		
	}

	/**
	 * 本次解析流程需要的ContentGenerator
	 * 
	 * @param pageLink
	 * @return
	 * @since yangyu @ May 20, 2013
	 */
	public InterpreterType getInterpreterType() {
		if (assignedInterpreterType != null) {
			return assignedInterpreterType;
		} else {
			return pageLink.getParserType();
		}
	}

	/**
	 * 本次解析需要的CacheProvider
	 * 
	 * @return
	 * @since yangyu @ Aug 7, 2013
	 */
	@Override
	public CacheProvider getCacheProvider() {
		if (assignedCacheProvider != null) {
			return assignedCacheProvider;
		} else {
			return settings.getCacheProvider();
		}
	}

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	public PageLink getPageLink() {
		return pageLink;
	}

	public void setPageLink(PageLink pageLink) {
		this.pageLink = pageLink;
	}

	public PrintWriter getPrintWriter() {
		return printWriter;
	}

	public void setPrintWriter(PrintWriter printWriter) {
		this.printWriter = printWriter;
	}

	public Settings getSettings() {
		return settings;
	}

	public RequestWrapper getRequestWrapper() {
		return requestWrapper;
	}

	/**
	 * 解析模板上下文TagContext为HTML
	 * 
	 * @see com.trs.dev4.jdk16.cms.GeneratorSession#parse(com.trs.dev4.jdk16.cms.bo.TagContext)
	 * @since yangyu @ Apr 11, 2013
	 */
	public String parse(TagContext tagContext) {
		Map<String, TagParser> tagParsers = settings.getTagParsers();
		TagParser tagParser = tagParsers.get(tagContext.getTagItem().getName());
		if (tagParser == null) {
			throw new TemplateException("不存在的置标标签" + tagContext.getTagItem().getName(), tagContext);
		}
		return tagParser.parse(tagContext);
	}



	/**
	 * @see com.trs.dev4.jdk16.cms.GeneratorSession#setAssignedCacheProvider(com.trs.dev4.jdk16.cms.impl.NoCacheProvider)
	 * @since yangyu @ May 17, 2013
	 */
	@Override
	public void setAssignedCacheProvider(CacheProvider cacheProvider) {
		this.assignedCacheProvider = cacheProvider;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.GeneratorSession#setAssignedContentGeneratorType(com.trs.dev4.jdk16.cms.enu.InterpreterType)
	 * @since yangyu @ May 17, 2013
	 */
	@Override
	public void setAssignedContentGeneratorType(InterpreterType contentGenerator) {
		this.assignedInterpreterType = contentGenerator;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.GeneratorSession#setAssignedParsedContent(java.lang.String)
	 * @since yangyu @ May 17, 2013
	 */
	@Override
	public void setAssignedParsedContent(String content) {
		this.assignedContent = content;
	}

	public String getAssignedContent() {
		return assignedContent;
	}

	public CacheProvider getAssignedCacheProvider() {
		return assignedCacheProvider;
	}

	public void setRequestWrapper(RequestWrapper requestWrapper) {
		this.requestWrapper = requestWrapper;
	}
	
	/**
	 * 
	 * @param generatorSession
	 * @param settings
	 * @return
	 * @since yangyu @ Aug 7, 2013
	 */
	public String getParsedContent(final GeneratorSession generatorSession, final Settings settings) {
		if (!StringUtils.isEmpty(generatorSession.getAssignedContent())) {
			return generatorSession.getAssignedContent();
		} else {
			PageLink pageLink = generatorSession.getPageLink();
			Template template = settings.getTemplateManager().getFormPageLink(pageLink);
			return template.getContent();
		}
	}
	
	/**
	 * @return the {@link #templateName}
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * @param templateName the {@link #templateName} to set
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * Flush输出到Response，输出前会压缩HTML
	 * 
	 * @param printWriter
	 * @param sb
	 */
	public void flushContent(String content) {
		
		if (!neetNotCompress && site.isCompressedHtml()) {
			printWriter.println(TagExpressionHelper.compressHTML(content));
		} else {
			printWriter.println(content);
		}
		printWriter.flush();
	}
	
	/**
	 * @see com.trs.dev4.jdk16.cms.GeneratorSession#clear()
	 * @since yangyu @ May 28, 2013
	 */
	@Override
	public void clear() {
		this.assignedContent = null;
		this.assignedCacheProvider = null;
		this.assignedInterpreterType = null;
		this.neetNotCompress = false;
		this.templateName = null;
	}

	/**
	 * @param neetNotCompress
	 *            the {@link #neetNotCompress} to set
	 */
	public void setNeetNotCompress(boolean neetNotCompress) {
		this.neetNotCompress = neetNotCompress;
	}

}
