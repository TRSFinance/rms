/*
 * Created: yangyu@Jun 25, 2013 4:04:56 PM
 */
package com.trs.dev4.jdk16.cms.impl;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.CacheProvider;
import com.trs.dev4.jdk16.cms.cache.CachedResult;

/**
 * 职责: <br>
 * 
 */
public class LocalCacheProvider implements CacheProvider {
	
	public static int DEFAULT_EXPR = 30;
	
	protected static Logger logger = Logger.getLogger(LocalCacheProvider.class);

	private Cache ehCacheServer = null;
	
	private static CacheManager cacheManager = null;
	
	/**
	 * 
	 * 
	 * @since TRS @ Feb 13, 2012
	 */
	public void initializeCache() {
		if (cacheManager == null) {
			cacheManager = CacheManager.create();
		}
		ehCacheServer = new Cache(new CacheConfiguration("localCache@" + this.hashCode(), 1000000));
		cacheManager.addCache(ehCacheServer);
		logger.info("LocalCacheProvider server started with cacheManager(" + cacheManager + ") and cache(" + ehCacheServer + ").");
	}
	
	/**
	 * @see com.trs.dev4.jdk16.cms.CacheProvider#clear()
	 * @since yangyu @ Jun 25, 2013
	 */
	@Override
	public void clear() {
		ehCacheServer.removeAll();
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.CacheProvider#get(java.lang.String)
	 * @since yangyu @ Jun 25, 2013
	 */
	@Override
	public CachedResult get(String key) {
		Element element = ehCacheServer.get(key);
		if (element == null) {
			return CachedResult.NOTEXISTED;
		}
		return new CachedResult(element.getObjectValue());
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.CacheProvider#remove(java.lang.String)
	 * @since yangyu @ Jun 25, 2013
	 */
	@Override
	public void remove(String key) {
		ehCacheServer.remove(key);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.CacheProvider#set(java.lang.String,
	 *      java.lang.Object)
	 * @since yangyu @ Jun 25, 2013
	 */
	@Override
	public void set(String key, Object value, int expr) {
		Element element = new Element(key, value);
		element.setTimeToLive(expr);
		ehCacheServer.put(element);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.CacheProvider#set(java.lang.String,
	 *      java.lang.Object)
	 * @since yangyu @ Jun 25, 2013
	 */
	@Override
	public void set(String key, Object value) {
		Element element = new Element(key, value);
		element.setTimeToLive(DEFAULT_EXPR);
		ehCacheServer.put(element);
	}

}
