/*
 * Created: liushen@Apr 9, 2010 12:10:11 PM
 */
package com.trs.dev4.jdk16.servlet24;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.FileRenamePolicy;
import com.trs.dev4.jdk16.utils.FileUtil;
import com.trs.dev4.jdk16.utils.NumberUtil;

/**
 * 处理文件上传请求的助手.<br>
 * 依赖于cos.jar.
 * 
 * @author TRS信息技术股份有限公司
 */
public class MultipartHelper {

	/**
	 *
	 */
	private MultipartRequest mpReq;

	/**
	 * @throws IOException
	 */
	public MultipartHelper(HttpServletRequest request, String saveDirectory,
			int maxPostSize) throws IOException {
		this(request, saveDirectory, maxPostSize, "UTF-8", null);
	}

	/**
	 * @throws IOException
	 */
	public MultipartHelper(HttpServletRequest request, String saveDirectory,
			int maxPostSize, FileRenamePolicy policy)
			throws IOException {
		this(request, saveDirectory, maxPostSize, "UTF-8", policy);
	}

	/**
	 * @throws IOException
	 */
	public MultipartHelper(HttpServletRequest request, String saveDirectory,
			int maxPostSize, String encoding, FileRenamePolicy policy)
			throws IOException {
		mpReq = new MultipartRequest(request, saveDirectory, maxPostSize,
				encoding, policy);
	}

	/**
	 * 获取和给定表单域对应的上传文件信息.
	 * 
	 * @param name
	 *            表单域的名称
	 * @return 上传文件信息；如果不存在此表单域则返回<code>null</code>.
	 * @since liushen @ Apr 9, 2010
	 */
	public MultipartFile getMultipartFile(String name) {
		File file = mpReq.getFile(name);
		if (file == null) {
			return null;
		}
		FileUtil.assertFileExists(file);
		String originalFileName = mpReq.getOriginalFileName(name);
		return new MultipartFile(file, originalFileName, name);
	}

	/**
	 * 获取request的参数值
	 * 
	 * @param paramName
	 *            参数名
	 * @return 参数值
	 * @since fangxiang @ May 24, 2010
	 */
	public String getParameter(String paramName) {
		return mpReq.getParameter(paramName);
	}

	/**
	 * 获取request的参数值
	 * 
	 * @param paramName
	 *            参数名
	 * @return 参数值
	 * @since fangxiang @ May 24, 2010
	 */
	public int getParameterAsInt(String paramName) {
		return NumberUtil.parseInt(mpReq.getParameter(paramName));
	}

}
