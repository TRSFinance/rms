package com.trs.dev4.jdk16.cms.bo;

/**
 * Pagelet标签的封装类
 * 
 * @author yangyu
 * @since Feb 4, 2013 11:45:00 AM
 */
public class Pagelet {

	/**
	 * 标签项
	 */
	private TagItem tagItem;
	/**
	 * 对应的ID值
	 */
	private String id;
	
	public Pagelet(TagItem currentItem) {
		this.tagItem = currentItem;
	}

	public String getName() {
		return tagItem.getAttribute("temlateName");
	}

	public TagItem getTagItem() {
		return tagItem;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
