/*
 * Created: yangyu@May 30, 2013 5:17:57 PM
 */
package com.trs.dev4.jdk16.cms.enu;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import com.trs.dev4.jdk16.cms.TagAware;
import com.trs.dev4.jdk16.cms.bo.ExpressionResult;
import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.bo.ValidateContext;
import com.trs.dev4.jdk16.cms.exp.RequestParameterNotFoundException;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.cms.expression.FilterByFieldTagExpression;
import com.trs.dev4.jdk16.cms.expression.OrderByTagExpresion;
import com.trs.dev4.jdk16.cms.tag.ParserConf;
import com.trs.dev4.jdk16.cms.util.ReflectHelper;

/**
 * 职责: 置标表达式的定义
 * 
 */
public enum ExpressionDefination {

	/**
	 * 只允许数字输入的标签属性，使用广泛
	 */
	INT {
		/**
		 * 只验证值是否位数字类型
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionDefination#validate(com.trs.dev4.jdk16.cms.bo.ValidateContext,
		 *      java.lang.String)
		 * @since yangyu @ Jun 5, 2013
		 */
		@Override
		public void validate(ValidateContext validateContext, String key, String value) {
			if (!StringUtils.isNumeric(value)) {
				validateContext.addError("置标表达式格式错误，属性" + key + "必须是数值类型");
			}
		}
	},
	/**
	 * 字符串输入标签属性，使用广泛
	 */
	STRING {

	},
	/**
	 * 字符数组的标签属性，一般特点是以“;”为分割符
	 * 
	 * 如TRS_PAGELET标签的CSS和JS属性
	 */
	STRING_ARRAY {
		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {
			String[] parts = StringUtils.split(attribute, ";");
			return new ExpressionResult(ExpressionType.ARRAYSTRING, parts);
		}
	},

	/**
	 * 只允许boolean类型的校验属性，使用广泛
	 */
	BOOLEAN {
		/**
		 * 只校验是否为true或者false
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionDefination#validate(com.trs.dev4.jdk16.cms.bo.ValidateContext,
		 *      java.lang.String)
		 * @since yangyu @ Jun 5, 2013
		 */
		@Override
		public void validate(ValidateContext validateContext, String key, String value) {

			if (!("true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value))) {
				validateContext.addError("置标表达式格式错误，必须是BOOLEAN类型，如true或者false");
			}
		}

	},
	/**
	 * 允许函数解析的INT类型，一般包含两种格式，一个是数字类型，另一个是结果为数字的函数类型
	 * 
	 * 如：TRS_OBJECT的id属性等，使用较多
	 */
	INTFUNCTION {

		/**
		 * 先验证是否为INT，然后解析函数，函数的结果是否是INT
		 * 
		 * 如果不是，验证是否是String或者Array类型
		 * 
		 * 最后进入函数的判断
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionDefination#validate(com.trs.dev4.jdk16.cms.bo.ValidateContext,
		 *      java.lang.String)
		 * @since yangyu @ Jun 5, 2013
		 */
		@Override
		public void validate(ValidateContext validateContext, String key, String value) {
			// 1. 验证如果是INT类型的值可以直接通过
			if (StringUtils.isNumeric(value)) {
				return;
			}

			// 2. 验证如果使用FunctionMark(如String为单引号)，直接提示解析结果不是int类型
			ExpressionType expressionType = ExpressionType.resolveType(value);
			if (!expressionType.equals(ExpressionType.NOTYPEMARK)) {
				validateContext.addError("置标表达式格式错误，必须是INTFUNCTION类型，不支持’‘或者()来表示其他类型");
				return;
			}

			// 3. 验证函数解析后的结果是否是int类型
			ExpressionFunction expressionFunction = ExpressionFunction.resolveFunction(value);
			if (expressionFunction.equals(ExpressionFunction.NOFUNCTION)) {
				validateContext.addError("置标表达式格式错误，必须是INTFUNCTION类型，不支持非函数的字符串");
			}

			expressionFunction.validate(validateContext, expressionType, value);

		}

		/**
		 * param.id;10;
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionDefination#resolve(com.trs.dev4.jdk16.cms.bo.TagContext,
		 *      java.lang.String)
		 * @since yangyu @ 2013-6-6
		 */
		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {
			//数字的情况
			if (StringUtils.isNumeric(attribute)) {
				return new ExpressionResult(ExpressionType.INT, NumberUtils.toInt(attribute));
			} else {
				//非数字情况，解析结果为数字
				ExpressionFunction expressionFunctionDefination = ExpressionFunction.resolveFunction(attribute);
				return expressionFunctionDefination.resolveValue(tagContext, ExpressionType.INT, attribute);
			}
		}
	},
	/**
	 * 其他表达式中使用的表达式
	 * 
	 * 比如：FILTERBYFIELD的键值，ORDERBY键值
	 * 
	 */
	KEY {
		/**
		 * 必须是OBJ值对应对象的属性值
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionDefination#validate(com.trs.dev4.jdk16.cms.bo.ValidateContext,
		 *      java.lang.String)
		 * @since yangyu @ Jun 5, 2013
		 */
		@Override
		public void validate(ValidateContext validateContext, String key, String value) {

			String objValue = validateContext.getObjValue();

			TagAware<?> tagAware = validateContext.getSettings().getTagAware(objValue);

			if (tagAware != null) {
				try {
					ReflectHelper.getField(tagAware.getTagClass(), value);
				} catch (Exception e) {
					if (!ArrayUtils.contains(tagAware.specialTagAttribute(), value)) {
						validateContext.addError("不存在的置标对象属性，当前属性为" + value);
					}
				}
			}
		}

		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {
			return new ExpressionResult(tagContext.getEntity().getProperty(tagContext, attribute));
		}

	},
	/**
	 * param.id,'aaa',10
	 * 
	 * FILTERBYFIELD的值
	 * 
	 */
	VALUE {

		/**
		 * 验证非String类型，以及非函数类型的情况，比如aaa
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionDefination#validate(com.trs.dev4.jdk16.cms.bo.ValidateContext,
		 *      java.lang.String)
		 * @since yangyu @ 2013-6-17
		 */
		@Override
		public void validate(ValidateContext validateContext, String key, String value) {
			ExpressionType expressionType = ExpressionType.resolveType(value);
			if (expressionType.equals(ExpressionType.NOTYPEMARK)) {
				ExpressionFunction expressionFunction = ExpressionFunction.resolveFunction(value);
				if (expressionFunction.equals(ExpressionFunction.NOFUNCTION)) {
					ExpressionResult expressionResult = ExpressionType.packingStringValueToResult(
							ExpressionType.NOTYPEMARK, value);
					if (expressionResult.getExpressionType().equals(ExpressionType.UNDEFINED)) {
						validateContext.addError("属性" + key + "的置标表达式格式不正确，当前值为" + value
								+ "，这个值是未定义类型，如果需要表示为字符类型，应该在前后加上单引号");
					}
				} else {
					expressionFunction.validate(validateContext, expressionType, value);
				}
			}
		}

		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {

			ExpressionType expressionType = ExpressionType.resolveType(attribute);
			if (expressionType.canUseFunction()) {
				String noTypeValue = expressionType.getNoTypeValue(attribute);
				ExpressionFunction expressionFunction = ExpressionFunction.resolveFunction(noTypeValue);
				return expressionFunction.resolveValue(tagContext, expressionType, noTypeValue);
			} else {
				return expressionType.getConvertedValue(attribute);
			}
		}
	},
	/**
	 * <TRS_PROPERTY VALUE="param.id"/> <TRS_PROPERTY VALUE="key"/> 用于展示，不用区分类型，输出的都是String类型
	 */
	PROPERTYVALUE {
		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {
			ExpressionFunction expressionFunction = ExpressionFunction.resolveFunction(attribute);
			ExpressionResult expressionResult = null;
			if (expressionFunction.equals(ExpressionFunction.NOFUNCTION)) {
				PublishObject entity = tagContext.getEntity();
				if (entity != null) {
					expressionResult = new ExpressionResult(entity.getProperty(tagContext, attribute));
					if (expressionResult.getResult() == null) {
						expressionResult = new ExpressionResult(ExpressionType.STRING, attribute);
					}
				} else {
					expressionResult = new ExpressionResult(ExpressionType.STRING, attribute);
				}
			} else {
				expressionResult = expressionFunction.resolveValue(tagContext, ExpressionType.STRING, attribute);
			}
			return expressionResult;
		}
	},
	/**
	 * PROPERTY的value属性，SWITCH的value属性
	 */
	KEYVALUE {
		/**
		 * <TRS_PROPERTY VALUE="index,param.id"/> 'param.id'
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionDefination#resolve(com.trs.dev4.jdk16.cms.bo.TagContext,
		 *      java.lang.String)
		 * @since yangyu @ Jun 6, 2013
		 */
		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {
			ExpressionType expressionType = ExpressionType.resolveType(attribute);
			String noTypeValue = expressionType.getNoTypeValue(attribute);
			ExpressionFunction expressionFunctionDefination = ExpressionFunction.resolveFunction(noTypeValue);
			ExpressionResult expressionResult = expressionFunctionDefination.resolveValue(tagContext, expressionType,
					noTypeValue);
			if (expressionResult.getExpressionType().equals(ExpressionType.UNDEFINED)) {
				expressionResult = new ExpressionResult(tagContext.getEntity().getProperty(tagContext, attribute));
			}
			return expressionResult;
		}
	},
	/**
	 * OBJECTS orderby
	 */
	ORDERBY {
		@Override
		public void validate(ValidateContext validateContext, String key, String value) {
			String[] segments = StringUtils.split(value, " ");
			if (segments.length == 2) {
				KEY.validate(validateContext, key, segments[0]);
				if (segments[1].equalsIgnoreCase("desc") || segments[1].equalsIgnoreCase("asc")
						|| segments[1].equalsIgnoreCase("rand")) {
				} else {
					validateContext.addError("ORDERBY置标表达式格式不正确，后半部分的值应为【desc,asc,rand】中的一个");
				}
			}
		}

		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {

			String[] parts = StringUtils.split(attribute, ";");
			List<OrderByTagExpresion> expressions = new ArrayList<OrderByTagExpresion>();
			for (String part : parts) {
				OrderByTagExpresion orderByTagExpresion = new OrderByTagExpresion();
				String[] segments = StringUtils.split(part, " ");
				orderByTagExpresion.setEntityProperty(segments[0]);
				orderByTagExpresion.setOrderby(VALUE.resolve(tagContext, segments[1]).getStringValue());
				orderByTagExpresion.setSearchString(part);
				expressions.add(orderByTagExpresion);
			}

			return new ExpressionResult(expressions);
		}

	},
	/**
	 * SWITCH标签的VALUE属性
	 */
	KEYVALUE_OPER_VALUE {

		@Override
		public void validate(ValidateContext validateContext, String key, String value) {

			String[] segments = StringUtils.split(value, " ");
			if (segments.length == 3) {
				KEYVALUE.validate(validateContext, key, segments[0]);
				OPER.validate(validateContext, key, segments[1]);
				VALUE.validate(validateContext, key, segments[2]);
			}

		}

		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {
			String[] segments = StringUtils.split(attribute, " ");
			ExpressionResult keyExpressionResult = KEYVALUE.resolve(tagContext, segments[0]);
			ExpressionOperator oper = ExpressionOperator.getOperator(segments[1]);
			ExpressionResult valueExpressionResult = VALUE.resolve(tagContext, segments[2]);
			return new ExpressionResult(ExpressionType.BOOLEAN, oper.dealSwitch(keyExpressionResult,
					valueExpressionResult));
		}

	},
	EMPTY_KEYVALUE {

		@Override
		public void validate(ValidateContext validateContext, String key, String value) {
			String[] segments = StringUtils.split(value, " ");
			if (segments.length == 2) {
				if (segments[0].equalsIgnoreCase("empty") || segments[0].equalsIgnoreCase("!empty")) {
				} else {
					validateContext.addError("EMPTY_KEYVALUE表达式不正确，第一个部分的值应该为【empty,!empty】中的一个");
				}
				KEYVALUE.validate(validateContext, key, segments[1]);
			}
		}

		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {
			String[] segments = StringUtils.split(attribute, " ");
			ExpressionResult expressionResult = new ExpressionResult();

			try {
				expressionResult = KEYVALUE.resolve(tagContext, segments[1]);
			} catch (RequestParameterNotFoundException e) {
				expressionResult.setResult(null);
			}

			if (segments[0].equalsIgnoreCase("empty")) {
				if (expressionResult.isEmpty()) {
					return new ExpressionResult(ExpressionType.BOOLEAN, true);
				} else {
					return new ExpressionResult(ExpressionType.BOOLEAN, false);
				}
			} else if (segments[0].equalsIgnoreCase("!empty")) {
				if (expressionResult.isEmpty()) {
					return new ExpressionResult(ExpressionType.BOOLEAN, false);
				} else {
					return new ExpressionResult(ExpressionType.BOOLEAN, true);
				}
			}
			throw new TemplateException("SWITCH标签不支持的属性格式");
		}

	},
	OBJ {

		@Override
		public void validate(ValidateContext validateContext, String key, String value) {
			TagAware<?> tagAware = validateContext.getSettings().getTagAware(value);
			if (tagAware == null) {
				validateContext.addError("OBJ属性所指定的值不存在，目前可用的OBJ属性为"
						+ validateContext.getSettings().getTagAwares().keySet());
			}
		}

	},

	STRINGOPTION {

		@Override
		public void validate(ValidateContext validateContext, String key, String value) {
			ParserConf parserConf = validateContext.getSettings().getParserConfig(validateContext.getName());
			List<String> stringOptions = parserConf.getAttributeConf(key).getOptions();
			if (stringOptions == null || !stringOptions.contains(value.toUpperCase())) {
				validateContext.addError("属性值不符合要求，当前值为" + value + ",可选值为" + stringOptions);
			}
		}

	},
	FILTERBYFIELD {

		@Override
		public void validate(ValidateContext validateContext, String key, String value) {
			String[] parts = StringUtils.split(value, ";");
			for (String part : parts) {
				String[] segments = StringUtils.split(part, " ");
				if (segments.length == 3) {
					KEY.validate(validateContext, key, segments[0]);
					OPER.validate(validateContext, key, segments[1]);
					VALUE.validate(validateContext, key, segments[2]);

					String obj = validateContext.getObjValue();
					TagAware tagAware = validateContext.getSettings().getTagAware(obj);

					Field field = null;
					try {
						field = ReflectHelper.getField(tagAware.getTagClass(), segments[0]);
						ExpressionType expressionType = ExpressionType.resolveType(segments[2]);
						expressionType.validate(validateContext, field.getType(), key);
					} catch (Exception e) {
					}

				} else {
					validateContext.addError("属性FilterByField置标表达式格式不正确，参考格式为name eq 'aaa'");
				}
			}
		}

		/**
		 * id gt 10;id le param.id
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionDefination#resolve(java.lang.String)
		 * @since yangyu @ Jun 6, 2013
		 */
		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {
			String[] parts = StringUtils.split(attribute, ";");
			List<FilterByFieldTagExpression> expressions = new ArrayList<FilterByFieldTagExpression>();
			for (String part : parts) {
				String[] segments = StringUtils.split(part, " ");
				try {
					String key = segments[0];
					ExpressionOperator oper = ExpressionOperator.getOperator(segments[1]);
					ExpressionResult value = ExpressionDefination.VALUE.resolve(tagContext, segments[2]);
					expressions.add(new FilterByFieldTagExpression(key, oper, value, attribute));
				} catch (RequestParameterNotFoundException e) {
				}
			}
			return new ExpressionResult(expressions);
		}

	},

	SWITCH {

		@Override
		public void validate(ValidateContext validateContext, String key, String value) {
			String[] segments = StringUtils.split(value, " ");
			if (segments.length == 3) {
				KEYVALUE_OPER_VALUE.validate(validateContext, key, value);
			} else if (segments.length == 2) {
				EMPTY_KEYVALUE.validate(validateContext, key, value);
			}
		}

		/**
		 * id gt 10;id le param.id
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionDefination#resolve(java.lang.String)
		 * @since yangyu @ Jun 6, 2013
		 */
		@Override
		public ExpressionResult resolve(TagContext tagContext, String attribute) {
			String[] segments = StringUtils.split(attribute, " ");
			if (segments.length == 3) {
				return KEYVALUE_OPER_VALUE.resolve(tagContext, attribute);
			} else if (segments.length == 2) {
				return EMPTY_KEYVALUE.resolve(tagContext, attribute);
			}
			throw new TemplateException("SWITCH标签不支持的属性格式");
		}
	},
	OPER {
		@Override
		public void validate(ValidateContext validateContext, String key, String value) {
			ExpressionOperator.getOperator(value);
		}
	};

	/**
	 * @param tagContext
	 *            上下文
	 * @param attribute
	 *            要解析的全文
	 * @return
	 * @since yangyu @ May 31, 2013
	 */
	public ExpressionResult resolve(TagContext tagContext, String attribute) {
		return new ExpressionResult(attribute);
	}

	/**
	 * @param validateContext
	 * @param value2
	 * @since yangyu @ Jun 5, 2013
	 */
	public void validate(ValidateContext validateContext, String key, String value) {
	}

}