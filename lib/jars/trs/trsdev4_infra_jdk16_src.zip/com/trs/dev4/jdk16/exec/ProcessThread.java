/*
 * Created: liushen@Nov 30, 2012 5:12:16 PM
 */
package com.trs.dev4.jdk16.exec;

import org.apache.log4j.Logger;

/**
 * 为 {@link ProcessHelper} 提供监听进程退出的支撑。<br>
 * 
 */
public class ProcessThread extends Thread {

	private static final Logger LOG = Logger.getLogger(ProcessThread.class);
	private IProcessTerminatedListener ptl;
	private ProcessHelper ph;

	/**
	 * @param ph
	 * @param ptl
	 */
	public ProcessThread(ProcessHelper ph, IProcessTerminatedListener ptl) {
		this.ph = ph;
		this.ptl = ptl;
	}

	/**
	 * @see java.lang.Thread#run()
	 * @since liushen @ Nov 30, 2012
	 */
	@Override
	public void run() {
		if (LOG.isDebugEnabled()) {
			LOG.debug("ph=" + ph + ", ptl=" + ptl);
		}
		ph.startAndWait();
		if (LOG.isDebugEnabled()) {
			LOG.debug("process exited: " + ph);
		}
		if (ptl == null) {
			return;
		}

		try {
			ptl.afterExited(ph);
		} catch (Throwable e) {
			LOG.error("fail during ProcessTerminatedListener.afterExited: " + ph, e);
		}

	}

}
