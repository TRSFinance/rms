/*
 * Created: yangyu@May 22, 2013 1:51:32 PM
 */
package com.trs.dev4.jdk16.cms.tag;

import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.PageLinkManager;
import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.exp.TemplateException;

/**
 * 职责: <br>
 * <TRS_PAGELINK NAME="首页"/>
 */
public class PageLinkTagParser implements TagParser {

	/**
	 * @see com.trs.dev4.jdk16.cms.TagParser#parse(com.trs.dev4.jdk16.cms.bo.TagContext)
	 * @since yangyu @ May 22, 2013
	 */
	@Override
	public String parse(TagContext tagContext) {
		GeneratorSession generatorSession = tagContext.getGeneratorSession();
		PageLinkManager pageLinkManager = generatorSession.getSettings().getPageLinkManager();
		String name = tagContext.getStringValue("name");
		int siteId = generatorSession.getSite().getId();
		PageLink pageLink = pageLinkManager.get(siteId, name);
		if (pageLink == null) {
			throw new TemplateException("不存在的映射" + name, tagContext);
		}
		String baseUrl = generatorSession.getSettings().getBaseurlExtractor().getApplcationBaseUrl();
		return baseUrl + pageLink.getUrlPattern();
	}

}
