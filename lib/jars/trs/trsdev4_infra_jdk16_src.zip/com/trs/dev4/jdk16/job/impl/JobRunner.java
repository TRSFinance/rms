/*
 * Created: TRS@Mar 3, 2011 6:08:24 PM
 */
package com.trs.dev4.jdk16.job.impl;

import java.util.concurrent.ScheduledFuture;

import com.trs.dev4.jdk16.job.JobDetail;

/**
 * 用于执行单个定时任务的封装
 */
public class JobRunner {
	/**
	 * 
	 */
	protected ScheduledFuture<?> scheduledFuture;
	/**
	 * 
	 */
	protected JobDetail jobDetail;
	/**
	 * 检查点
	 */
	protected long checkPoint;
	/**
	 * 
	 */
	protected boolean checked = true;

	/**
	 * 
	 * @param jobDetail
	 */
	public JobRunner(JobDetail jobDetail, ScheduledFuture<?> scheduledFuture) {
		this.jobDetail = jobDetail;
		this.scheduledFuture = scheduledFuture;
	}

	/**
	 * 判断JobDetail是否发生了改变
	 * 
	 * @param jobDetail
	 * @return true表示发生了改变，false表示未发生改变
	 * @since TRS @ Mar 3, 2011
	 */
	public boolean changedDetail(JobDetail jobDetail) {
		return !this.jobDetail.equals(jobDetail);
	}

	/**
	 * @return the {@link #data.scheduledFuture}
	 */
	public ScheduledFuture<?> getScheduledFuture() {
		return this.scheduledFuture;
	}

	/**
	 * @param scheduledFuture
	 *            the {@link #data.scheduledFuture} to set
	 */
	public void setScheduledFuture(ScheduledFuture<?> scheduledFuture) {
		this.scheduledFuture = scheduledFuture;
	}

	/**
	 * @return the {@link #data.jobDetail}
	 */
	public JobDetail getJobDetail() {
		return this.jobDetail;
	}

	/**
	 * 重置
	 * 
	 * @since TRS @ Mar 17, 2011
	 */
	public void reset() {
		checked = false;
	}

	/**
	 * 检查
	 * 
	 * @since TRS @ Mar 17, 2011
	 */
	public void check() {
		checked = true;
	}

	/**
	 * 是否检查过
	 * 
	 * @return
	 * @since TRS @ Mar 17, 2011
	 */
	public boolean isChecked() {
		return checked;
	}
}