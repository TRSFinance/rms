/*
 * Created: cl@2011-6-15 下午02:09:27
 */
package com.trs.dev4.jdk16.exception;

/**
 * 职责: 文件为空的异常<br>
 * 
 */
public class FileEmptyException extends RootException {

	/**
	 * @param msg
	 * @param cause
	 */
	public FileEmptyException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public FileEmptyException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public FileEmptyException(Throwable cause) {
		super(cause);
	}

	/**
	 * @since cl @ 2011-6-15
	 */
	private static final long serialVersionUID = 1L;

}
