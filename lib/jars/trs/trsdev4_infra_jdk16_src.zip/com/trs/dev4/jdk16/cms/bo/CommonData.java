/*
 * Created: yangyu@Sep 4, 2012 9:13:21 AM
 */
package com.trs.dev4.jdk16.cms.bo;

import org.apache.commons.lang.math.NumberUtils;

/**
 * 职责: <br>
 * 
 */
public class CommonData implements Comparable<CommonData> {

	private String type;

	private String stringValue;

	private String sourceValue;

	private Object enumValue;

	public CommonData() {

	}

	public CommonData(String stringValue) {
		this.stringValue = stringValue;
		this.type = "String";
	}

	public CommonData(Object obj) {
		if (obj instanceof Integer) {
			this.setType("int");
		} else if (obj instanceof Boolean) {
			this.setType("boolean");
		} else {
			this.setType("String");
		}
		this.setStringValue(obj.toString());
	}

	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 * @since yangyu @ Sep 4, 2012
	 */
	@Override
	public int compareTo(CommonData commonData) {
		if (type.equalsIgnoreCase("int")) {
			int v1 = NumberUtils.toInt(stringValue, 0);
			int v2 = NumberUtils.toInt(commonData.getStringValue(), 0);
			if (v1 > v2) {
				return 1;
			} else if (v1 == v2) {
				return 0;
			} else {
				return -1;
			}
		} else if (commonData.getType().equalsIgnoreCase("enum")) {
			return commonData.getEnumValue().toString().compareTo(stringValue);
		} else {
			return stringValue.compareTo(commonData.getStringValue());
		}
	}

	public Object getConverted() {

		if (this.getType().equalsIgnoreCase("enum")) {
			return this.getEnumValue();
		} else if (this.getType().equalsIgnoreCase("int")) {
			return NumberUtils.toInt(stringValue, 0);
		} else if (this.getType().equalsIgnoreCase("boolean")) {
			return new Boolean(stringValue);
		} else {
			return stringValue;
		}

	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStringValue() {
		return stringValue;
	}

	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}

	public String getSourceValue() {
		return sourceValue;
	}

	public void setSourceValue(String sourceValue) {
		this.sourceValue = sourceValue;
	}

	public Object getEnumValue() {
		return enumValue;
	}

	public void setEnumValue(Object enumValue) {
		this.enumValue = enumValue;
	}

}
