/*
 * Created: fangxiang@Jan 21, 2011 3:35:30 PM
 */
package com.trs.dev4.jdk16.cms;

import java.util.Map;

/**
 * 发布内容获取器
 * 
 */
public interface IContentProvider {
	/**
	 * 获取待发布的内容
	 * 
	 * @param parameters
	 * @return
	 * @since fangxiang @ Jan 21, 2011
	 */
	public Map<String, Object> getContent(Map<String, Object> parameters);

	/**
	 * 
	 * @param parameters
	 * @return
	 * @since fangxiang @ Jan 21, 2011
	 */
	public String getOutputFile(Map<String, Object> parameters);
}
