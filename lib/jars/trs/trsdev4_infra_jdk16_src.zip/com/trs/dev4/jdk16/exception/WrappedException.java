/*
 * Created: liushen@Mar 9, 2010 7:35:04 AM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 通用异常，包装其他异常对象或错误信息. <br>
 */
@SuppressWarnings("serial")
public class WrappedException extends RootException {

	/**
	 * @param msg
	 * @param cause
	 */
	public WrappedException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public WrappedException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public WrappedException(Throwable cause) {
		super(cause);
	}

	/**
	 * @see java.lang.Throwable#toString()
	 * @since liushen @ May 16, 2010
	 */
	@Override
	public String toString() {
		String localMsg = getClass().getName() + ": " + getLocalizedMessage();
		Throwable cause = this.getCause();
		return localMsg
				+ (cause == null ? "" : " " + cause.getLocalizedMessage());
	}

}
