package com.trs.dev4.jdk16.cms.enu;

import org.apache.commons.lang.StringUtils;

import com.trs.dev4.jdk16.cms.bo.ExpressionResult;
import com.trs.dev4.jdk16.cms.expression.FilterByFieldTagExpression;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.utils.NumberUtil;

public enum ExpressionOperator {

	EQ {
		@Override
		public boolean dealSwitch(ExpressionResult key, ExpressionResult value) {
			Object keyObj = key.getResult();
			Object valueObj = value.getResult();
			if (keyObj == null || valueObj == null) {
				return false;
			}
			return keyObj.equals(valueObj);
		}

		@Override
		public void buildSearchFilter(SearchFilter searchFilter, FilterByFieldTagExpression filterByFieldTagExpression) {
			searchFilter.addEqCondition(filterByFieldTagExpression.getKey(), filterByFieldTagExpression.getExpressionResult().getResult());
		}
	},
	GT {
		@Override
		public boolean dealSwitch(ExpressionResult key, ExpressionResult value) {
			return key.compareTo(value) > 0;
		}

		@Override
		public void buildSearchFilter(SearchFilter searchFilter, FilterByFieldTagExpression filterByFieldTagExpression) {
			searchFilter.addGreaterThan(filterByFieldTagExpression.getKey(), filterByFieldTagExpression.getExpressionResult().getResult());
		}
	},
	LT {
		@Override
		public boolean dealSwitch(ExpressionResult key, ExpressionResult value) {
			return key.compareTo(value) < 0;
		}

		@Override
		public void buildSearchFilter(SearchFilter searchFilter, FilterByFieldTagExpression filterByFieldTagExpression) {
			searchFilter.addLesserThan(filterByFieldTagExpression.getKey(), filterByFieldTagExpression.getExpressionResult().getResult());
		}
	},
	GE {
		@Override
		public boolean dealSwitch(ExpressionResult key, ExpressionResult value) {
			return key.compareTo(value) >= 0;
		}

		@Override
		public void buildSearchFilter(SearchFilter searchFilter, FilterByFieldTagExpression filterByFieldTagExpression) {
			searchFilter.addGreaterThanEquals(filterByFieldTagExpression.getKey(), filterByFieldTagExpression.getExpressionResult().getResult());
		}
	},
	LE {
		@Override
		public boolean dealSwitch(ExpressionResult key, ExpressionResult value) {
			return key.compareTo(value) <= 0;
		}

		@Override
		public void buildSearchFilter(SearchFilter searchFilter, FilterByFieldTagExpression filterByFieldTagExpression) {
			searchFilter.addLesserThanEquals(filterByFieldTagExpression.getKey(), filterByFieldTagExpression.getExpressionResult().getResult());
		}
	},
	NE {
		@Override
		public boolean dealSwitch(ExpressionResult key, ExpressionResult value) {
			return !key.equals(value);
		}

		@Override
		public void buildSearchFilter(SearchFilter searchFilter, FilterByFieldTagExpression filterByFieldTagExpression) {
			searchFilter.addNotEqCondition(filterByFieldTagExpression.getKey(), filterByFieldTagExpression.getExpressionResult().getResult());
		}
	},
	LIKE {
		@Override
		public boolean dealSwitch(ExpressionResult key, ExpressionResult value) {
			return false;
		}

		@Override
		public void buildSearchFilter(SearchFilter searchFilter, FilterByFieldTagExpression filterByFieldTagExpression) {
			searchFilter.addLike(filterByFieldTagExpression.getKey(), filterByFieldTagExpression.getExpressionResult().getResult());
		}
	},
	IN {
		@Override
		public boolean dealSwitch(ExpressionResult key, ExpressionResult value) {
			return false;
		}

		@Override
		public void buildSearchFilter(SearchFilter searchFilter, FilterByFieldTagExpression filterByFieldTagExpression) {
			searchFilter.addCondition("in", filterByFieldTagExpression.getKey(), filterByFieldTagExpression
					.getExpressionResult().getIntArray());
		}
	},
	SINCE {
		@Override
		public boolean dealSwitch(ExpressionResult key, ExpressionResult value) {
			return false;
		}

		@Override
		public void buildSearchFilter(SearchFilter searchFilter, FilterByFieldTagExpression filterByFieldTagExpression) {
			searchFilter.addGreaterThan(filterByFieldTagExpression.getKey(), getBeginTime(filterByFieldTagExpression.getExpressionResult().getStringValue()));
		}
		
		private long getBeginTime(String sinceValue) {
			long currentTimeMill = System.currentTimeMillis();
			int num = NumberUtil.parseInt(StringUtils.substring(sinceValue, 0, sinceValue.length() - 1));
			if (sinceValue.endsWith("h") || sinceValue.endsWith("H")) {
				return currentTimeMill - num * 3600000;
			} else if (sinceValue.endsWith("s") || sinceValue.endsWith("S")) {
				return currentTimeMill - num * 1000;
			} else if (sinceValue.endsWith("Y") || sinceValue.endsWith("y")) {
				return currentTimeMill - num * 31104000000l;
			} else if (sinceValue.endsWith("D") || sinceValue.endsWith("d")) {
				return currentTimeMill - num * 86400000;
			} else if (sinceValue.endsWith("M")) {
				return currentTimeMill - num * 2592000000l;
			} else if (sinceValue.endsWith("m")) {
				return currentTimeMill - num * 60000;
			} else {
				return currentTimeMill;
			}
		}
	};

	public static ExpressionOperator getOperator(String oper) {
		return ExpressionOperator.valueOf(oper.toUpperCase());
	}

	/**
	 * 处理SWITCH标签的比较
	 * 
	 * @param key
	 * @param value
	 * @return
	 * @since yangyu @ Jun 13, 2013
	 */
	public abstract boolean dealSwitch(ExpressionResult key, ExpressionResult value);

	/**
	 * 根据FilterByFieldTagExpression构造SearchFilter
	 * 
	 * @param filterByFieldTagExpression
	 * @param searchFilter
	 * @since yangyu @ Jun 13, 2013
	 */
	public abstract void buildSearchFilter(SearchFilter searchFilter, FilterByFieldTagExpression filterByFieldTagExpression);

}
