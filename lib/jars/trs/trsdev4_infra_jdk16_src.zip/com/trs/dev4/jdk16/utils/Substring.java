/**
 * Created: liushen@Jan 29, 2010 1:29:02 AM
 */
package com.trs.dev4.jdk16.utils;

/**
 * 封装子字符串的信息.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class Substring {

	private String fullString;

	private int start;

	private int end;

	public Substring(String str, int start, int end) {
		fullString = str;
		this.start = start;
		this.end = end;
	}

	public String getValue() {
		return fullString.substring(start, end);
	}

	/**
	 * @return
	 * @creator liushen @ Jan 29, 2010
	 */
	public String getBefore() {
		return fullString.substring(0, start);
	}


	/**
	 * @return
	 * @creator liushen @ Jan 29, 2010
	 */
	public String getBefore(int prevStartPos) {
		return fullString.substring(prevStartPos, start);
	}

	/**
	 * 
	 * @return
	 * @creator liushen @ Jan 29, 2010
	 */
	public String getAfter() {
		return fullString.substring(end);
	}

	/**
	 * Get the {@link #fullString}.
	 * 
	 * @return the {@link #fullString}.
	 */
	public String getFullString() {
		return fullString;
	}

	/**
	 * Get the {@link #start}.
	 * 
	 * @return the {@link #start}.
	 */
	public int getStart() {
		return start;
	}

	/**
	 * Get the {@link #end}.
	 * 
	 * @return the {@link #end}.
	 */
	public int getEnd() {
		return end;
	}

}
