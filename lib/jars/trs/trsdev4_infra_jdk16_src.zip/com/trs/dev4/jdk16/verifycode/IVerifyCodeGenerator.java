/*
 * Created: dujie@2011-10-12 下午05:32:50
 */
package com.trs.dev4.jdk16.verifycode;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.Serializable;

/**
 * 职责: <br>
 * 混合类型验证码生成器 生成图片·提供验证码
 */
public interface IVerifyCodeGenerator {

	/**
	 * 获取带有随机验证码的图片
	 * 
	 * @param verifyCode 验证码字符串
	 * @param isChinese 知否是中文
	 * @param noiseLevel 噪音级别.噪音级别是指验证码生成图片的背景复杂度,噪音级别数越大，验证码越难识别,取值范围：400～1000.
	 * @param torsionResistance 扭曲度.扭曲度是指验证码在生成图片上的偏移程度,扭曲度指数越大，验证码越难识别,取值范围：10～30.
	 * @param fontSize 验证码字体大小
	 * @param pictureWidth 图片的宽度
	 * @param pictureHeight 图片的高度
	 * @return 图片
	 * @throws IOException IO异常
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	public abstract BufferedImage drawVerifyCodeToPicture(Serializable verifyCode, boolean isChinese, int noiseLevel, int torsionResistance, int fontSize, int pictureWidth, int pictureHeight)
			throws IOException;

}