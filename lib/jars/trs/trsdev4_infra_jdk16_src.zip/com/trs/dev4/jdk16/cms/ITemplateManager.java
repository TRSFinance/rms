/*
 * created by TRS @ Jan 21, 2011
 *
 */
package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.cms.bo.Template;
import com.trs.dev4.jdk16.cms.bo.TemplateDocument;
import com.trs.dev4.jdk16.cms.bo.TemplateVersion;
import com.trs.dev4.jdk16.dao.HQLBuilder;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.IBaseManager;

/**
 * 模板管理器
 * 
 * @author TRS
 */
public interface ITemplateManager extends IBaseManager<Template>, TemplateManager {
	/**
	 * 通过template对象， 并构造对应的版本对象插入到数据库中
	 * 
	 * @param templateId
	 * @return TODO
	 * @since TRS信息技术股份有限公司 @ Oct 23, 2012
	 */
	public TemplateVersion addTemplateVersion(Template template);

	/**
	 * 获取模板对象
	 * 
	 * @param name
	 * @return
	 * @since TRS @ Feb 12, 2011
	 */
	Template getTemplate(String templateName, PageLink pageLink);

	/**
	 * 直接解析模板
	 * 
	 * @param templateContent
	 * @return
	 * @since TRS @ Feb 16, 2011
	 */
	TemplateDocument parseTemplateDocument(String templateContent);

	/**
	 * 根据ObjectId和ObjectType获取模板对象
	 * 
	 * @param objectType
	 *            模板类型
	 * @param objectId
	 *            模板ID
	 * @return
	 */
	Template getTemplateByObjectType(String objectType,int objectId);

	/**
	 * 获取符合查询条件的模板版本分页内容
	 * 
	 * @param sf
	 *            查询条件，参见{@link SearchFilter}
	 * @return 模板版本分页数据，参见{@link TemplateVerison,@link PagedList}
	 * @since TRS信息技术股份有限公司 @ Oct 25, 2012
	 */
	public PagedList<TemplateVersion> pagedVersions(SearchFilter sf);

	/**
	 * 批量更新模板版本随想
	 * 
	 * @param builder
	 *            HQL语句构造器，参见{@link HQLBuilder}
	 * @return
	 * @since TRS信息技术股份有限公司 @ Oct 25, 2012
	 */
	public int batchUpdateVersion(HQLBuilder builder);

	/**
	 * 根据id获取模板版本对象
	 * 
	 * @param id
	 *            版本id
	 * @return 版本对象，参见{@link TemplateVerison}
	 * @since TRS信息技术股份有限公司 @ Oct 25, 2012
	 */
	public TemplateVersion getTemplateVersion(int id);

	/**
	 * 从已知的映射获取该映射所使用的模板
	 * 
	 * @param pageLink
	 * @since yangyu @ Nov 29, 2012
	 */
	public Template getFormPageLink(PageLink pageLink);

	/**
	 * 根据站点ID和模板名称获取TemplateDoc
	 * 
	 * @param templateName
	 * @param siteId
	 * @return
	 * @since yangyu @ Nov 30, 2012
	 */
	public TemplateDocument getTemplateDocument(String templateName, int siteId);

	/**
	 * 根据站点和模板名获取模板
	 * 
	 * @param templateName
	 *            模板名
	 * @param siteId
	 *            站点ID
	 * @return
	 * @since yangyu @ Dec 7, 2012
	 */
	public Template getBySiteAndTemplateName(String templateName, int siteId);

	/**
	 * 站点下模板的数量
	 * 
	 * @param site
	 * @return
	 * @since yangyu @ Dec 17, 2012
	 */
	public int countUnderSite(Site site);
	
}
