/*
 * Created: liushen@Feb 16, 2010 10:35:02 AM
 */
package com.trs.dev4.jdk16.dao;

/**
 * 封装对一个字段的查询条件.
 * 
 * @author TRS信息技术有限公司
 */
// TODO liushen @ Feb 16, 2010: 需要将HQLBuilder及其内部的Condition提炼整合。
public class Condition {

	/**
	 * 该条件中, 字段和取值的关系运算符. 默认为相等, 即"=".
	 */
	private String op;

	/**
	 * 该条件的字段.
	 */
	private String field;

	/**
	 * 该条件的绑定参数名.
	 * 
	 * @since liushen @ May 4, 2010
	 */
	private String bindName;

	/**
	 * 该条件的取值.
	 */
	private Object value;

	/**
	 * 二元条件的第二个取值.
	 */
	private Object value2;

	/**
	 * 构造零元或一元条件.
	 * 
	 * @param op
	 * @param prop
	 * @param value
	 */
	private Condition(String op, String prop, Object value) {
		this.op = op;
		this.field = prop;
		this.value = value;
	}

	/**
	 * 构造二元条件.
	 * 
	 * @param op
	 * @param prop
	 * @param value1
	 * @param value2
	 */
	private Condition(String op, String prop, Object value1, Object value2) {
		this.op = op;
		this.field = prop;
		this.value = value1;
		this.value2 = value2;
	}

	/**
	 * 该条件不需要绑定参数。
	 * 
	 * @return
	 * @creator liushen @ Feb 16, 2010
	 */
	public boolean noNeedToBindParam() {
		return value == null && value2 == null;
	}

	/**
	 * 该条件需要绑定一个参数。
	 * 
	 * @return
	 * @creator liushen @ Feb 16, 2010
	 */
	public boolean needBindOneParam() {
		return value != null && value2 == null;
	}

	/**
	 * 该条件需要绑定两个参数。
	 * 
	 * @return
	 * @creator liushen @ Feb 16, 2010
	 */
	public boolean needBindTwoParams() {
		return value != null && value2 != null;
	}

	/**
	 * 该条件需要绑定一个数组或集合类型的参数.
	 * 
	 * @return
	 * @creator liushen @ Feb 16, 2010
	 */
	public boolean needBindCollectionParam() {
		return OP_IN.equals(op) || OP_NOTIN.equals(op);
	}

	/**
	 * 该条件是个Between..and条件.
	 * 
	 * @return
	 * @creator liushen @ Feb 16, 2010
	 */
	public boolean isBetweenCondition() {
		return BETWEEN.equals(op);
	}

	/**
	 * 该条件是个Like条件.
	 * 
	 * @return
	 * @creator liushen @ Feb 16, 2010
	 */
	public boolean isLikeCondition() {
		return OP_LIKE.equals(op);
	}

	/**
	 * Get the {@link #op}.
	 * 
	 * @return the {@link #op}.
	 */
	public String getOp() {
		if (isRightLikeCondition()) {
			return OP_LIKE;
		}
		return op;
	}

	/**
	 * @return
	 * @since Administrator @ 2014-2-19
	 */
	public boolean isRightLikeCondition() {
		return OP_RIGHTLIKE.equals(op);
	}

	/**
	 * 有效的检索条件的数目，供单元测试检查。
	 * 
	 * @since liushen @ Feb 28, 2014
	 */
	static int totalValidOps() {
		return VALID_OPS.length;
	}

	/**
	 * Get the {@link #field}.
	 * 
	 * @return the {@link #field}.
	 */
	public String getField() {
		return field;
	}

	/**
	 * Get the {@link #value}.
	 * 
	 * @return the {@link #value}.
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Get the {@link #value2}.
	 * 
	 * @return the {@link #value2}.
	 */
	public Object getValue2() {
		return value2;
	}

	/**
	 * @return the {@link #bindName}
	 */
	public String getBindName() {
		return bindName;
	}

	/**
	 * @param bindName
	 *            the {@link #bindName} to set
	 */
	void setBindName(String bindName) {
		this.bindName = bindName;
	}

	/**
	 * 判断是否为合法的零元或一元运算符(查询条件).
	 * 
	 * @param op
	 *            给定的运算符
	 * @return 是零元或一元运算符返回true, 否则返回false.
	 */
	static boolean isValidOp(String op) {
		for (int i = 0; i < VALID_OPS.length; i++) {
			if (VALID_OPS[i].equals(op)) {
				return true;
			}
		}
		return false;
	}

	static Condition buildCondition(String op, String field, Object value) {
		if (false == isValidOp(op)) {
			return null;
		}
		// liushen @ May 29, 2011: 零元运算符(is null等)没有value
		if (OP_ISNULL.equals(op) || OP_ISNOTNULL.equals(op)) {
			return new Condition(op, field, value);
		}
		if (value == null) {
			return null;
		}
		return new Condition(op, field, value);
	}

	public static Condition buildBetweenCondition(String field,
			Object value, Object value2) {
		if (value == null || value2 == null) {
			return null;
		}
		return new Condition(BETWEEN, field, value, value2);
	}

	static final String OP_LIKE = "like";
	static final String OP_ISNULL = "is null";
	static final String OP_ISNOTNULL = "is not null";
	static final String OP_GT = ">";
	static final String OP_GTE = ">=";
	static final String OP_LT = "<";
	static final String OP_LTE = "<=";
	static final String OP_EQUAL = "=";
	static final String OP_NOTEQUAL = "!=";
	static final String OP_IN = "in";
	static final String OP_NOTIN = "not in";
	static final String OP_RIGHTLIKE = "rightLike";
	
	/**
	 * 
	 */
	static final String BETWEEN = "between";

	// TODO 将操作符改进为枚举
	static final String[] VALID_OPS = { OP_EQUAL, OP_LIKE, OP_GTE, OP_LTE, OP_GT, OP_LT, OP_IN, OP_NOTIN,
			OP_NOTEQUAL, OP_ISNULL, OP_ISNOTNULL, OP_RIGHTLIKE };

	/**
	 * @see java.lang.Object#toString()
	 * @since Administrator @ 2014-2-19
	 */
	@Override
	public String toString() {
		StringBuilder strBuf = new StringBuilder();
		strBuf.append(this.getField()).append(' ');
		strBuf.append(this.isRightLikeCondition() ? OP_RIGHTLIKE : this.getOp()).append(' ');
		if (this.needBindCollectionParam()) {
			strBuf.append("(").append(this.getValue()).append(')');
		} else if (this.isBetweenCondition()) {
			strBuf.append('(').append(this.getValue());
			strBuf.append(" and ").append(this.getValue2()).append(')');
		} else if (this.needBindOneParam()) {
			strBuf.append(this.getValue());
		}
		return strBuf.toString();
	}
	
	public String toPesudoExpression(Condition condition) {
		StringBuilder sb = new StringBuilder();
		sb.append(condition.getField()).append(' ').append(condition.getOp());
		if (condition.needBindCollectionParam()) {
			sb.append(" (:").append(condition.getBindName()).append(')');
		} else if (condition.isBetweenCondition()) {
			sb.append(" :").append(condition.getBindName()).append("lo");
			sb.append(" and :").append(condition.getBindName()).append("hi");
		} else if (condition.needBindOneParam()) {
			sb.append(" :").append(condition.getBindName());
		}
		return sb.toString();
	}

}
