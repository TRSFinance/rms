/*
 * Created: liushen@Apr 6, 2011 12:05:58 PM
 */
package com.trs.dev4.jdk16.file.impl;

import com.trs.dev4.jdk16.file.IDirectory;

/**
 * 职责: <br>
 *
 */
public abstract class BaseDirectory implements IDirectory {

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#toJSON()
	 * @since liushen @ Apr 6, 2011
	 */
	@Override
	public String toJSON() {
		return BaseFile.toJSON(this);
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#isFolder()
	 * @since liushen @ Apr 15, 2011
	 */
	@Override
	public final boolean isFolder() {
		return true;
	}

}
