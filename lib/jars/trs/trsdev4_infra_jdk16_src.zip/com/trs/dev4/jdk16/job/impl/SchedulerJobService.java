/*
 * Created: TRS@Jan 29, 2011 10:21:43 PM
 */
package com.trs.dev4.jdk16.job.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.job.IJobExecutor;
import com.trs.dev4.jdk16.job.IJobListener;
import com.trs.dev4.jdk16.job.JobDetail;

/**
 * 基于JDK1.5的Scheduler实现的定时任务
 * 
 */
public class SchedulerJobService extends BaseJobService implements IJobListener {
	/**
	 * 
	 */
	private final static Logger logger = Logger
			.getLogger(SchedulerJobService.class);
	/**
	 *
	 */
	private final Map<String, JobRunner> jobRunners = new HashMap<String, JobRunner>();
	/**
	 *
	 */
	private final ScheduledExecutorService scheduler = Executors
			.newScheduledThreadPool(10);

	/**
	 * 
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#cancelJob(com.trs.dev4.jdk16.job.JobDetail)
	 * @since TRS @ Jan 29, 2011
	 */
	@Override
	protected void cancelJob(JobDetail jobDetail) {
		JobRunner jobWrapper = getRunner(jobDetail);
		if (jobWrapper != null) {
			jobWrapper.getScheduledFuture().cancel(true);
			jobRunners.remove(jobDetail.getJobName());
		}
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#scheduleJob(com.trs.dev4.jdk16.job.JobDetail)
	 * @since TRS @ Jan 29, 2011
	 */
	@Override
	public void scheduleJob(JobDetail jobDetail) {
		// 检查是否需要更新
		JobRunner jobRunner = getRunner(jobDetail);
		if (jobRunner != null) { // 任务已经存在，首先判断是否发生了改变
			if (!jobRunner.changedDetail(jobDetail)) {// 没有更新的话不执行
				logger.debug("JobRunner no change with executorName("
						+ jobDetail.getJobName() + ").");
				jobRunner.check();//
				return;
			}
			// 如果发生了改变，则先取消任务
			cancelJob(jobDetail);
		}
		//
		IJobExecutor jobExecutor = this.getExecutor(jobDetail);
		if (jobExecutor == null) {
			logger.debug("Can't found jobExecutor with executorName("
					+ jobDetail.getExecutorName() + ").");
			return;
		}
		JobExecutorWrapper jobExecutorWrapper = new JobExecutorWrapper(
				jobExecutor, jobDetail, this);
		ScheduledFuture<?> scheduledObject;
		if (jobDetail.getPeriodAsSecond() != 0) { // 循环执行
			scheduledObject = scheduler.scheduleAtFixedRate(jobExecutorWrapper,
					jobDetail.getDelayAsSecond(),
					jobDetail.getPeriodAsSecond(), TimeUnit.SECONDS);
		} else { // 单次执行
			scheduledObject = scheduler.schedule(jobExecutorWrapper, 1,
					TimeUnit.SECONDS);
		}
		//
		jobRunners.put(jobDetail.getJobName(), new JobRunner(jobDetail,
				scheduledObject));
	}

	/**
	 * @param jobDetail
	 * @return
	 * @since TRS @ Mar 3, 2011
	 */
	private JobRunner getRunner(JobDetail jobDetail) {
		return jobRunners.get(jobDetail.getJobName());
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobListener#beforeExecute(com.trs.dev4.jdk16.job.IJobExecutor,
	 *      com.trs.dev4.jdk16.job.JobDetail)
	 * @since TRS @ Jan 29, 2011
	 */
	@Override
	public void beforeExecute(IJobExecutor jobExecutor, JobDetail jobDetail) {

	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobListener#afterExecuted(com.trs.dev4.jdk16.job.IJobExecutor,
	 *      com.trs.dev4.jdk16.job.JobDetail)
	 * @since TRS @ Jan 29, 2011
	 */
	@Override
	public void afterExecuted(IJobExecutor jobExecutor, JobDetail jobDetail) {
		if (jobDetail.getPeriodAsSecond() == 0) { // 移除单次执行的任务
			jobRunners.remove(jobDetail.getId());
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#listScheduledJobs()
	 * @since TRS @ Feb 23, 2011
	 */
	@Override
	public List<JobDetail> listScheduledJobs() {
		List<JobDetail> jobDetails = new ArrayList<JobDetail>();
		for (JobRunner jobRunner : jobRunners.values()) {
			jobDetails.add(jobRunner.getJobDetail());
		}
		return jobDetails;
	}


	/**
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#start()
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public void start() {
		super.start();
	}

	/**
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#stop()
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public void stop() {
		super.stop();
		//
		this.scheduler.shutdown();
	}

	/**
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#existsJob(java.lang.String)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public boolean existsJob(String jobName) {
		return jobRunners.containsKey(jobName);
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#countJobs()
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public int countJobs() {
		return this.jobRunners.size();
	}


	/**
	 * 
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#preSchedule()
	 * @since TRS @ Mar 17, 2011
	 */
	@Override
	protected void preSchedule() {
		for (JobRunner jobRunner : jobRunners.values()) {
			jobRunner.reset();
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#postScheduled()
	 * @since TRS @ Mar 17, 2011
	 */
	@Override
	protected void postScheduled() {
		for ( JobRunner jobRunner : jobRunners.values() ){
			if (!jobRunner.isChecked()) {
				this.cancelJob(jobRunner.getJobDetail());
			}
		}
	}
}
