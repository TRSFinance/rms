/*
 * Created: Administrator@2013-12-4 下午02:00:27
 */
package com.trs.dev4.jdk16.cms.tag;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Element;

/**
 * 职责: <br>
 * 
 */
public class AttributeConf {

	private String name;

	private String type;

	private boolean required = false;

	private List<String> options;

	/**
	 * @return the {@link #name}
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the {@link #name} to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the {@link #type}
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the {@link #type} to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the {@link #required}
	 */
	public boolean isRequired() {
		return required;
	}

	/**
	 * @param required
	 *            the {@link #required} to set
	 */
	public void setRequired(boolean required) {
		this.required = required;
	}

	/**
	 * @return the {@link #options}
	 */
	public List<String> getOptions() {
		return options;
	}

	/**
	 * @param options
	 *            the {@link #options} to set
	 */
	public void setOptions(List<String> options) {
		this.options = options;
	}

	/**
	 * @param element
	 * @return
	 * @since Administrator @ 2013-12-4
	 */
	public static AttributeConf readAttribute(Element attributeElement) {
		AttributeConf attributeConf = new AttributeConf();
		attributeConf.name = attributeElement.attributeValue("name").toUpperCase();
		attributeConf.type = attributeElement.attributeValue("type").toUpperCase();
		if (attributeElement.attribute("required") != null) {
			attributeConf.required = Boolean.valueOf(attributeElement.attributeValue("required"));
		}
		if (attributeElement.attribute("option") != null) {
			attributeConf.options = Arrays.asList(StringUtils.split(StringUtils.upperCase(attributeElement
					.attributeValue("option")), ";"));
		}
		return attributeConf;
	}

}
