/*
 * Created: yirongyi@2015年3月20日 上午10:05:57
 */
package com.trs.dev4.jdk16.exception;

/**
 * 数据不合法异常：如字段长度超过规定长度 <br>
 */
public class DataInvalidException extends DAOException {

	/**
	 * @param msg
	 */
	public DataInvalidException(String msg) {
		super(msg);
	}

	/**
	 * @param msg
	 * @param cause
	 */
	public DataInvalidException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param cause
	 */
	public DataInvalidException(Throwable cause) {
		super(cause);
	}

	/**
	 * @since yirongyi @ 2015年3月20日
	 */
	private static final long serialVersionUID = 6018167460075023773L;

}
