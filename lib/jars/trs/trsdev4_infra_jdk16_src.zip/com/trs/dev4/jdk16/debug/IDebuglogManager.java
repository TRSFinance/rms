/*
 * Created: fangxiang@Nov 25, 2010 10:44:55 PM
 */
package com.trs.dev4.jdk16.debug;

import com.trs.dev4.jdk16.model.IBaseManager;

/**
 * 职责: <br>
 *
 */
public interface IDebuglogManager extends IBaseManager<Debuglog> {

}
