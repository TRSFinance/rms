package com.trs.dev4.jdk16.view;

/**
 * 职责:将请求封装，相当于STRUTS的ActionForm .<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class LoginForm {
	/**
	 * 用户名
	 */
	private String userName;
	/**
	 * 用户密码
	 */
	private String password;

	/**
	 * 默认无参构造函数, 由于作为Spring Web-MVC的CommandClass，因此需要此默认无参构造函数.
	 */
	public LoginForm() {
	}

	/**
	 * 根据登录用户名构造对象.
	 */
	public LoginForm(String userName) {
		this.userName = userName;
	}

	/**
	 * Get the {@link #userName}.
	 * 
	 * @return the {@link #userName}.
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Set the {@link #userName}.
	 * 
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Get the {@link #password}.
	 * 
	 * @return the {@link #password}.
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Set the {@link #password}.
	 * 
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

}
