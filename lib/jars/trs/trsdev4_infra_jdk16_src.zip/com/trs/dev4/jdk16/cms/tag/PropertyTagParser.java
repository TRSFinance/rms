package com.trs.dev4.jdk16.cms.tag;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.exp.RequestParameterNotFoundException;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

public class PropertyTagParser implements TagParser {

	@Override
	public String parse(TagContext tagContext) {
		Object obj = null;
		try {
			obj = tagContext.getKeyFunctionValue("value");
		} catch (RequestParameterNotFoundException e) {
			obj = "";
		}
		if (obj != null) {
			obj = this.numberPatternDecorate(tagContext, obj);
			obj = this.datePatternDecorate(tagContext, obj);
			String stringValue = obj.toString();
			stringValue = this.separateDecorate(tagContext, stringValue);
			stringValue = this.escapeXMLDecorate(tagContext, stringValue);
			stringValue = this.lengthDecorate(tagContext, stringValue);
			return stringValue;
		} else {
			return "";
		}
	}

	/**
	 * 更新长度截取
	 * 
	 * @param tagContext
	 * @param string
	 * @return
	 * @since yangyu @ Sep 21, 2012
	 */
	private String lengthDecorate(TagContext tagContext, String value) {

		int length = tagContext.getIntValue("length", 0);

		if (length > 0) {
			return StringUtils.substring(value.toString(), 0, length);
		}

		return value;
	}

	private String separateDecorate(TagContext tagContext, String output) {
		// 加前缀、后缀、分割、URL
		String prefix = tagContext.getStringValue("prefix", "");
		String suffix = tagContext.getStringValue("suffix", "");
		String separator = tagContext.getStringValue("separator");

		String[] separatedOutput = new String[] { output };
		if (StringUtils.isNotEmpty(separator)) {
			separatedOutput = StringUtils.split(output, separator);
		}
		String[] prefixSeparatedOutput = new String[separatedOutput.length];
		for (int i = 0; i < separatedOutput.length; i++) {
			prefixSeparatedOutput[i] = (new StringBuffer(prefix)).append(separatedOutput[i]).append(suffix).toString();
		}
		String urlPattern = tagContext.getStringValue("urlPattern");
		if (StringUtils.isNotEmpty(urlPattern)) {

			for (int i = 0; i < separatedOutput.length; i++) {
				String url = urlPattern.replace("$", separatedOutput[i]);
				separatedOutput[i] = (new StringBuffer("<a href='")).append(url).append("'>").append(prefixSeparatedOutput[i]).append("</a>").toString();
			}
		}
		StringBuffer outputBuffer = new StringBuffer();
		for (int i = 0; i < separatedOutput.length; i++) {
			outputBuffer.append(separatedOutput[i]);
		}
		output = outputBuffer.toString();

		String holder = tagContext.getStringValue("holder");
		if (StringUtils.isNotEmpty(holder)) {
			output = StringUtils.replace(output, "$", holder);
		}
		return output;
	}

	private String escapeXMLDecorate(TagContext tagContext, Object output) {
		String escape = tagContext.getStringValue("escapeXML");
		boolean escapeXML = Boolean.valueOf(escape);
		if (escapeXML == true) {
			return TagExpressionHelper.Html2Text((String) output);
		}
		return output.toString();
	}

	private Object numberPatternDecorate(TagContext tagContext, Object value) {
		String numberPattern = tagContext.getStringValue("NUMBERPATTERN");
		if (!StringUtils.isEmpty(numberPattern)) {
			value = new DecimalFormat(numberPattern).format(value);
		}
		return value;
	}

	private Object datePatternDecorate(TagContext tagContext, Object value) {
		String datePattern = tagContext.getStringValue("DATEPATTERN");
		boolean readable = tagContext.getBooleanValue("readable", false);
		if (!StringUtils.isEmpty(datePattern)) {
			long timeMillis = 0;
			if (value instanceof Date) {
				timeMillis = ((Date) value).getTime();
			} else if (StringUtils.isNumeric(value.toString())) {
				timeMillis = Long.valueOf(value.toString());
			}
			value = new SimpleDateFormat(datePattern).format(new Date(timeMillis));
		} else if (readable) {
			long timeMillis = 0;
			if (value instanceof Date) {
				timeMillis = ((Date) value).getTime();
			} else if (StringUtils.isNumeric(value.toString())) {
				timeMillis = Long.valueOf(value.toString());
			}
			value = showMoment(timeMillis);
		}
		return value;
	}

	private String showMoment(long ctimelong) {
		String r = "";
		long nowtimelong = System.currentTimeMillis();
		long result = Math.abs(nowtimelong - ctimelong);

		if (result < 60000)// 一分钟内
		{
			long seconds = result / 1000;
			r = seconds + "秒钟前";
		} else if (result >= 60000 && result < 3600000)// 一小时内
		{
			long seconds = result / 60000;
			r = seconds + "分钟前";
		} else if (result >= 3600000 && result < 86400000)// 一天内
		{
			long seconds = result / 3600000;
			r = seconds + "小时前";
		} else if (result > 86400000 && result < 2592000000l)// 日期格式
		{
			long seconds = result / 86400000;
			r = seconds + "天前";
		} else if (result > 2592000000l && result < 31104000000l) {
			long seconds = result / 2592000000l;
			r = seconds + "月前";
		} else {
			long seconds = result / 31104000000l;
			r = seconds + "年前";
		}
		return r;
	}

}
