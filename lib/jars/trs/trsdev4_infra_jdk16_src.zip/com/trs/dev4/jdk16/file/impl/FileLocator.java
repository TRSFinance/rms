/*
 * Created: liushen@Aug 9, 2010 5:59:21 PM
 */
package com.trs.dev4.jdk16.file.impl;

import com.trs.dev4.jdk16.file.IFileResource;
import com.trs.dev4.jdk16.utils.AssertUtil;

/**
 * 定位到具体的实现. <br>
 * 
 * @deprecated liushen@Apr 15, 2011: 貌似过于复杂了；尚未完成和实际使用
 */
@Deprecated
public class FileLocator {

	/**
	 * 根据完整的url(如：ftp://userName:pwd@ip:port/file)信息获取文件或目录实例
	 * 
	 * @param strPath
	 *            完整的url
	 * @return 文件或目录对象
	 * @since lichuanjiao @ 2010-9-12
	 */
	public IFileResource getResource(String strPath) {
		AssertUtil.notNullOrEmpty(strPath, "未指定路径.");
//		ConnectionInfo connectionInfo = null;
//		try {
//			connectionInfo = new ConnectionInfo(strPath);
//		} catch (NoSuchResourceException e) {
//			throw e;
//		}
//		if (connectionInfo.getProtocol().equalsIgnoreCase("ftp"))
//			return new FTPDirectory(connectionInfo);
		// 依次判断类型并返回相应的实例
		// 根据URL获取文件实例
		return null;
	}

	/**
	 * 根据url和用户信息获取文件或目录实例
	 * 
	 * @param strPath
	 *            url
	 * @param userName
	 *            用户名
	 * @param pwd
	 *            密码
	 * @return 文件或目录对象
	 * @since lichuanjiao @ 2010-9-12
	 */
	public IFileResource getResource(String strPath, String userName, String pwd) {
		AssertUtil.notNullOrEmpty(strPath, "未指定路径.");
//		ConnectionInfo connectionInfo = null;
//		try {
//			connectionInfo = new ConnectionInfo(strPath);
//			connectionInfo.setUserName(userName);
//			connectionInfo.setPassword(pwd);
//		} catch (NoSuchResourceException e) {
//			throw e;
//		}
//		if (connectionInfo.getProtocol().equalsIgnoreCase("ftp"))
//			return new FtpFileImpl(connectionInfo);
		// 依次判断类型并返回相应的实例
		// 根据URL获取文件实例
		return null;
	}

}
