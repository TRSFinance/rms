/*
 * Created: liushen@Apr 21, 2010 10:19:47 AM
 */
package com.trs.dev4.jdk16.utils;

import java.io.File;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

import com.trs.dev4.jdk16.exception.WrappedException;

/**
 * 提取XML相关内容的助手。 <br>
 * 
 */
public class XmlReader {

	private Document document;

	/**
	 * 构造函数, 该实例提取出的内容均来自该xml文件.
	 */
	public XmlReader(File xmlFile) {
		try {
			document = new SAXReader().read(xmlFile);
		} catch (DocumentException e) {
			throw new WrappedException(e);
		}
	}

	/**
	 * 构造函数, 该实例提取出的内容均来自该URL.
	 */
	public XmlReader(URL url) {
		try {
			document = new SAXReader().read(url);
		} catch (DocumentException e) {
			throw new WrappedException(e);
		}
	}

	/**
	 * 构造函数, 该实例提取出的内容均来自该字符串.
	 * 
	 * @param xmlString
	 */
	public XmlReader(String xmlString) {
		AssertUtil.notNullOrEmpty(xmlString, "xmlString is empty!");
		Reader reader = new StringReader(xmlString);
		try {
			document = new SAXReader().read(reader);
		} catch (DocumentException e) {
			throw new WrappedException(e);
		}
	}

	/**
	 * 提取给定的XPath表达式对应的XML内容.
	 * 
	 * @param xpathExpression
	 * @return 字符串表示的XML内容
	 * @since liushen @ Apr 21, 2010
	 */
	public String getStringByXPath(String xpathExpression) {
		return document.valueOf(xpathExpression);
	}

	/**
	 * 获取其XML编码.
	 * 
	 * @return
	 * @since liushen @ Apr 21, 2010
	 */
	public String getEncoding() {
		return document.getXMLEncoding();
	}

	/**
	 * 获取Document
	 * 
	 * @return Document
	 * @since TRS信息技术股份有限公司 @ Sep 10, 2012
	 */
	public Document getDocument() {
		return document;
	}

}
