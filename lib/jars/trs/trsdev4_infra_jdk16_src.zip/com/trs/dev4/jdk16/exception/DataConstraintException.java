/*
 * Created: liushen@Jan 22, 2015 1:55:44 PM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 违反唯一性约束引发的异常。 <br>
 */
public class DataConstraintException extends DAOException {

	private static final long serialVersionUID = 1L;

	/**
	 * @param msg
	 * @param cause
	 */
	public DataConstraintException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param cause
	 */
	public DataConstraintException(Throwable cause) {
		super(cause);
	}

}
