package com.trs.dev4.jdk16.servlet24;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Map型的ThreadLocal变量
 * 
 */
public class MappedContextTL extends ThreadLocal<Map<String, Object>> {
	@Override
	protected Map<String, Object> initialValue() {
		Map<String, Object> result = new HashMap<String, Object>();
		result = Collections.synchronizedMap(result);
		return result;
	}

	/**
	 * 设置线程变量的参数和值
	 * 
	 * @param key
	 * @param value
	 * @since liuyou @ 2010-5-23
	 */
	public void setArg(String key, Object value) {
		super.get().put(key, value);
	}

	/**
	 * 提取线程变量参数对应的值
	 * 
	 * @param 参数
	 * @return 当前线程的变量值
	 * @since liuyou @ 2010-5-23
	 */
	public Object getArg(String key) {
		return super.get().get(key);
	}

	/**
	 * 移除线程变量参数
	 * 
	 * @param key
	 *            参数
	 * @return
	 * @since liuyou @ 2010-5-23
	 */
	public Object removeArg(String key) {
		return super.get().remove(key);
	}

	/**
	 * 清理整个线程变量
	 * 
	 * @since liuyou @ 2010-5-23
	 */
	public void clear() {
		super.get().clear();
	}
}
