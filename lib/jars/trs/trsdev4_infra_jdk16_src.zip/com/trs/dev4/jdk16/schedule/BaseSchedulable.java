/*
 * Created: liushen@May 6, 2011 11:56:26 AM
 */
package com.trs.dev4.jdk16.schedule;

/**
 * 抽象基类. <br>
 * 
 */
public abstract class BaseSchedulable implements ISchedulable {

}
