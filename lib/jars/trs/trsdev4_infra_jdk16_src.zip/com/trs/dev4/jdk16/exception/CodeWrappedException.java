/*
 * Created: liuyou@2010-5-19 上午11:06:30
 */
package com.trs.dev4.jdk16.exception;

/**
 * 包装一个错误,为其指定错误编号
 * 
 */
public class CodeWrappedException extends RootException {

	private String errorCode;

	/**
	 * 包装一个错误,为其指定错误编号
	 * 
	 * @param errorCode
	 * @param rootEx
	 */
	public CodeWrappedException(String errorCode, RootException rootEx) {
		super(rootEx.getMessage(), rootEx.getCause());
		this.errorCode = errorCode;
	}

	/**
	 * 返回错误编号
	 * 
	 * @return
	 * @since liuyou @ 2010-5-19
	 */
	public String getErrorCode() {
		return this.errorCode;
	}

	private static final long serialVersionUID = -9202140859396702235L;

}
