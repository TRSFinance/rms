package com.trs.dev4.jdk16.cms.impl;

import com.trs.dev4.jdk16.cms.BaseurlExtractor;

/**
 * 默认NoBaseurlExtractor
 * 
 * @author yangyu
 * @since Jan 16, 2013 5:20:56 PM
 */
public class NoBaseurlExtractor implements BaseurlExtractor {

	/**
	 * @see com.trs.dev4.jdk16.cms.BaseurlExtractor#getApplcationBaseUrl()
	 * @since yangyu @ May 16, 2013
	 */
	@Override
	public String getApplcationBaseUrl() {
		// TODO yangyu@May 16, 2013 3:05:01 PM: Auto-generated method stub
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.BaseurlExtractor#getStaticResourceBaseUrl()
	 * @since yangyu @ May 16, 2013
	 */
	@Override
	public String getStaticResourceBaseUrl() {
		// TODO yangyu@May 16, 2013 3:05:01 PM: Auto-generated method stub
		return null;
	}


}
