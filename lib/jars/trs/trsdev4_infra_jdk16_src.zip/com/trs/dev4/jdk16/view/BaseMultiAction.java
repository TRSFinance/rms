/*
 * Created: fangxiang@Apr 17, 2010 9:45:30 PM
 */
package com.trs.dev4.jdk16.view;


/**
 *
 */
public abstract class BaseMultiAction {

	/**
	 *
	 */
	public BaseMultiAction() {
	}

}
