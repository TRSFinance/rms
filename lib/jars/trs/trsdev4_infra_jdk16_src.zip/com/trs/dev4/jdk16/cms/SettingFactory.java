package com.trs.dev4.jdk16.cms;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.cache.CachablePageLinkManager;
import com.trs.dev4.jdk16.cms.cache.CachableSiteManager;
import com.trs.dev4.jdk16.cms.core.PageletsSchedulerImpl;
import com.trs.dev4.jdk16.cms.core.TagAnalyser;
import com.trs.dev4.jdk16.cms.impl.NoBaseurlExtractor;
import com.trs.dev4.jdk16.cms.impl.NoCacheProvider;
import com.trs.dev4.jdk16.cms.impl.TemplateInterpreterImpl;
import com.trs.dev4.jdk16.cms.tag.ParserConf;
import com.trs.dev4.jdk16.cms.tag.TagDefination;
import com.trs.dev4.jdk16.cms.template.CachedOperationTemplate;
import com.trs.dev4.jdk16.cms.util.ReflectHelper;

/**
 * 用于构建SettingFactory
 * 
 * @author yangyu
 * @since Feb 26, 2013 11:43:06 AM
 */
public class SettingFactory {

	protected static Logger LOG = Logger.getLogger(SettingFactory.class);

	/**
	 * 系统初始化是需要根据配置文件构造置标组件统一配置Settings
	 * 
	 * @param generatorProperties
	 * 
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * 
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws ClassNotFoundException
	 */
	public Settings buildSettings(Properties generatorProperties, Settings settings) {

		try {
			configCacheProvider(generatorProperties, settings);
			configThreadPoolSize(generatorProperties, settings);
			configCurrentUsernameExtractor(generatorProperties, settings);
			configMethodPart(generatorProperties, settings);
		} catch (NumberFormatException e) {
			LOG
					.error(
							"Init CMS settings error , please check the generatorProperties of spring config , some number config fault.",
							e);
		} catch (Exception e) {
			LOG
					.error(
							"Init CMS settings error , please check the generatorProperties of spring config , some class not found.",
							e);
		}

		readAndInitTagDefination(settings);

		CachableSiteManager cachableSiteManager = new CachableSiteManager();
		cachableSiteManager.setSettings(settings);
		settings.setCachableSiteManager(cachableSiteManager);

		CachablePageLinkManager cachablePageLinkManager = new CachablePageLinkManager();
		cachablePageLinkManager.setSettings(settings);
		settings.setCachablePageLinkManager(cachablePageLinkManager);

		TagAnalyser tagAnalyser = new TagAnalyser();
		settings.setTagAnalyser(tagAnalyser);

		settings.setPageletsScheduler(new PageletsSchedulerImpl());
		settings.setTemplateHandller(new TemplateInterpreterImpl());

		CachedOperationTemplate cachedOperationTemplate = new CachedOperationTemplate();
		cachedOperationTemplate.setSettings(settings);
		settings.setCachedOperationTemplate(cachedOperationTemplate);

		return settings;
	}

	/**
	 * 
	 * 从tagDefinition-default.xml中读取标签的校验信息，用于模板校验，校验信息设置到 Settings 中
	 * 
	 * @param settings
	 * @since yangyu @ Jun 3, 2013
	 */
	private void readAndInitTagDefination(Settings settings) {

		TagDefination tagDefination = TagDefination.getInstance();
		tagDefination.initDefination();

		Map<String, TagParser> tagParsers = new HashMap<String, TagParser>();
		Map<String, ParserConf> parserConfs = new HashMap<String, ParserConf>();

		for (ParserConf parserConf : tagDefination.getParsers()) {
			tagParsers.put(parserConf.getName(), parserConf.getTagParser());
			parserConfs.put(parserConf.getName(), parserConf);
			if (parserConf.isCachable()) {
				settings.addCachableTagParser(parserConf.getName());
			}
		}

		settings.setTagParsers(tagParsers);
		settings.setParserConfs(parserConfs);

	}

	/**
	 * @param generatorProperties
	 * @param settings
	 * @since yangyu @ Mar 29, 2013
	 */
	private void configMethodPart(Properties generatorProperties, Settings settings) {
		String methodPart = generatorProperties.getProperty("generator.template.methodPart", "method");
		settings.setMethodPart(methodPart);
	}

	/**
	 * 配置currentuser提取器
	 * 
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	private void configCurrentUsernameExtractor(Properties generatorProperties, Settings settings)
			throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		String currentUsernameExtractorClassName = generatorProperties
				.getProperty("generator.template.currentUsernameExtractor_class");
		if (!StringUtils.isEmpty(currentUsernameExtractorClassName)) {
			CurrentUsernameExtractor currentUsernameExtractor = (CurrentUsernameExtractor) ReflectHelper.classForName(
					currentUsernameExtractorClassName, CurrentUsernameExtractor.class).newInstance();
			settings.setCurrentUsernameExtractor(currentUsernameExtractor);
		} else {
			settings.setBaseurlExtractor(new NoBaseurlExtractor());
		}
	}

	/**
	 * 线程池配置
	 * 
	 * @param generatorProperties
	 * @param settings
	 */
	private void configThreadPoolSize(Properties generatorProperties, Settings settings) {
		String threadPoolSizeStr = generatorProperties.getProperty("generator.bigpipe.threadPoolSize");
		int threadPoolSize = 15;
		if (!StringUtils.isEmpty(threadPoolSizeStr)) {
			threadPoolSize = Integer.parseInt(threadPoolSizeStr);
		}
		settings.setThreadPoolSize(threadPoolSize);
	}

	/**
	 * 配置组件需要的CacheProvider
	 * 
	 * @param generatorProperties
	 * @param settings
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws ClassNotFoundException
	 */
	private void configCacheProvider(Properties generatorProperties, Settings settings) throws InstantiationException,
			IllegalAccessException, ClassNotFoundException {
		String providerClassName = generatorProperties.getProperty("generator.cache.provider_class");
		if (!StringUtils.isEmpty(providerClassName)) {
			CacheProvider cacheProvider = (CacheProvider) ReflectHelper.classForName(providerClassName,
					CacheProvider.class).newInstance();
			cacheProvider.initializeCache();
			settings.setCacheProvider(cacheProvider);
		} else {
			settings.setCacheProvider(new NoCacheProvider());
		}
	}

}
