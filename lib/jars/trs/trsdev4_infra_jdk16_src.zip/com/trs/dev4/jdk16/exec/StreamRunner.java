/*
 * Created: liushen@Dec 5, 2009 11:12:20 AM
 */
package com.trs.dev4.jdk16.exec;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.utils.CloseUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 包内部类，处理进程的输出流. <br>
 * 
 */
class StreamRunner extends Thread {

	private static final Logger LOG = Logger.getLogger(StreamRunner.class);

	/**
	 * 进程名。
	 */
	private String cmdName;

	/**
	 * 输入流, 对应进程的输出流.
	 */
	private InputStream is;

	/**
	 * 线程是否执行结束.
	 */
	private boolean finished = false;

	/**
	 * 输入流读取是否成功结束.
	 */
	private boolean successReadComplete = false;

	/**
	 * 设置用于读取进程输出流的编码. 如果为null, 则使用JVM默认编码.
	 */
	private String encoding = "UTF-8";

	/**
	 * 实际用的编码, 从<code>InputStreamReader.getEncoding()</code>返回.
	 */
	private String actualEncoding;

	/**
	 * 最多保存多少行的头输出、尾输出。
	 */
	private int maxLine = 500;

	/**
	 * 实际共输出了多少行。
	 */
	private int totalOutputLine;

	/**
	 * 输出的头部，最多不超过 {@link #maxLine} 行.
	 */
	private List<String> headOutput = new ArrayList<String>();

	/**
	 * 输出的尾部，最多不超过 {@link #maxLine} 行.
	 */
	private LinkedList<String> tailOutput = new LinkedList<String>();

	/**
	 * 
	 */
	private IProcessOutputLineListener lineListener;

	StreamRunner(InputStream is, IProcessOutputLineListener lineListener, String cmd, String outputType) {
		this.is = is;
		this.lineListener = lineListener;
		this.cmdName = cmd;

		this.setDaemon(true);
		this.setName("CMD-" + outputType + "-" + StringHelper.adjustLength(cmdName, 20));
	}

	/**
	 * @param encoding
	 *            the {@link #encoding} to set
	 */
	void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	@Override
	public void run() {
		InputStreamReader isr;
		try {
			isr = new InputStreamReader(is, encoding);
		} catch (UnsupportedEncodingException e) {
			LOG.warn("Unsupported Encoding: [" + encoding + "], so use jvm default encoding instead.");
			isr = new InputStreamReader(is);
		}
		actualEncoding = isr.getEncoding();
		BufferedReader br = new BufferedReader(isr);
		try {
			for (String line = br.readLine(); line != null; line = br
					.readLine()) {
				totalOutputLine++;
				if (totalOutputLine <= maxLine) {
					headOutput.add(line);
					tailOutput.addLast(line);
				} else {
					tailOutput.removeFirst();
					tailOutput.addLast(line);
				}

				if (lineListener != null) {
					try {
						lineListener.afterReadLine(line);
					} catch (Throwable e) {
						LOG.warn("skip the exception made by lineListener " + lineListener, e);
					}
				}
			}
			successReadComplete = true;
		} catch (IOException e) {
			LOG.error("fail on read process output", e);
		} finally {
			CloseUtil.closeReader(br);
			finished = true;
			LOG.info("finished.");
		}
	}

	/**
	 * @return {@link #tailOutput}
	 * @since liushen @ Jan 21, 2014
	 */
	public List<String> getOutputAsTail() {
		return tailOutput;
	}

	/**
	 * @return {@link #headOutput}
	 * @since liushen @ Jan 21, 2014
	 */
	public List<String> getOutputAsHead() {
		return headOutput;
	}

	/**
	 * @return the {@link #maxLine}
	 */
	public int getMaxLine() {
		return maxLine;
	}

	/**
	 * @return the {@link #totalOutputLine}
	 */
	public int getTotalOutputLine() {
		return totalOutputLine;
	}

	/**
	 * Get the {@link #finished}.
	 * 
	 * @return the {@link #finished}.
	 */
	public boolean isFinished() {
		return finished;
	}

	/**
	 * Get the {@link #successReadComplete}.
	 * 
	 * @return the {@link #successReadComplete}.
	 */
	public boolean isSuccessReadComplete() {
		return successReadComplete;
	}

	/**
	 * Get the {@link #encoding}.
	 * 
	 * @return the {@link #encoding}.
	 */
	public String getEncoding() {
		return encoding;
	}

	/**
	 * Get the {@link #actualEncoding}.
	 * 
	 * @return the {@link #actualEncoding}.
	 */
	public String getActualEncoding() {
		return actualEncoding;
	}
}
