/*
 * Created: fangxiang@Nov 22, 2010 6:48:04 PM
 */
package com.trs.dev4.jdk16.model;

/**
 * 服务器生命周期控制
 */
public interface IModuleLifecycle {
	/**
	 * 服务器的名字
	 * 
	 * @return
	 * @since fangxiang @ Nov 22, 2010
	 */
	public String getModuleName();

	/**
	 * 启动服务器
	 * 
	 * @since fangxiang @ Nov 22, 2010
	 */
	public void start();

	/**
	 * 停止服务器
	 * 
	 * @since fangxiang @ Nov 22, 2010
	 */
	public void stop();

	/**
	 * 重启服务器
	 * 
	 * @since fangxiang @ Nov 22, 2010
	 */
	public void restart();
}
