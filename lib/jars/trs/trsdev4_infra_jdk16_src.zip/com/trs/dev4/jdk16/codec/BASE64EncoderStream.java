/*
 * Created on 2004-5-16 by Martin (Fu Chengrui)
 */
package com.trs.dev4.jdk16.codec;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * BASE64 编码输入流。 线程不安全。
 */
public class BASE64EncoderStream extends FilterOutputStream {

	/**
	 * 编码码表
	 */
	final static char entable[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', // 0
			'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', // 1
			'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', // 2
			'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', // 3
			'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', // 4
			'o', 'p', 'q', 'r', 's', 't', 'u', 'v', // 5
			'w', 'x', 'y', 'z', '0', '1', '2', '3', // 6
			'4', '5', '6', '7', '8', '9', '+', '/', // 7
	};

	/**
	 * 缓存，待编码的字节数组
	 */
	private byte[] m_baBuffer;

	/**
	 * 缓存中的字节数
	 */
	private int m_iBufSize;

	/**
	 * 最大行长
	 */
	private int m_iMaxLine;

	/**
	 * 累计输出的字节数
	 */
	private int m_iOutSize;

	/**
	 * 使用BASE64编码一个字节数组，输出数组中不会加入非BASE64字符。该方法适用于编码少量数据。
	 * 
	 * @param inbuff
	 *            待编码的字节数组
	 * @return 编码结果数组
	 */
	public final static byte[] encode(byte[] inbuff) {
		if (inbuff.length == 0) {
			return inbuff;
		}

		int inposi = 0;
		int outpos = 0;
		byte[] outbuf = new byte[((inbuff.length + 2) / 3) * 4];

		for (int size = inbuff.length; size > 0; size -= 3) {
			if (size == 1) {
				byte a = inbuff[inposi++];
				byte b = 0;
				outbuf[outpos++] = (byte) entable[(a >>> 2) & 0x3F];
				outbuf[outpos++] = (byte) entable[((a << 4) & 0x30) + ((b >>> 4) & 0xf)];
				outbuf[outpos++] = (byte) '='; // pad character
				outbuf[outpos++] = (byte) '='; // pad character
			} else if (size == 2) {
				byte a = inbuff[inposi++];
				byte b = inbuff[inposi++];
				byte c = 0;
				outbuf[outpos++] = (byte) entable[(a >>> 2) & 0x3F];
				outbuf[outpos++] = (byte) entable[((a << 4) & 0x30) + ((b >>> 4) & 0xf)];
				outbuf[outpos++] = (byte) entable[((b << 2) & 0x3c) + ((c >>> 6) & 0x3)];
				outbuf[outpos++] = (byte) '='; // pad character
			} else {
				byte a = inbuff[inposi++];
				byte b = inbuff[inposi++];
				byte c = inbuff[inposi++];
				outbuf[outpos++] = (byte) entable[(a >>> 2) & 0x3F];
				outbuf[outpos++] = (byte) entable[((a << 4) & 0x30) + ((b >>> 4) & 0xf)];
				outbuf[outpos++] = (byte) entable[((b << 2) & 0x3c) + ((c >>> 6) & 0x3)];
				outbuf[outpos++] = (byte) entable[c & 0x3F];
			}
		}
		return outbuf;
	}

	/**
	 * 使用指定的输出流和缺省的最大行长（76字符换行）创建BASE64编码流对象
	 * 
	 * @param out
	 *            指定的输出流
	 */
	public BASE64EncoderStream(OutputStream out) {
		this(out, 76); // 在邮件系统中缺省每行76字符
	}

	/**
	 * 使用指定的输出流和指定的最大行长创建BASE64编码流对象
	 * 
	 * @param out
	 *            指定的输出流
	 * @param lin
	 *            指定的最大行长
	 */
	public BASE64EncoderStream(OutputStream out, int lin) {
		super(out);

		this.m_baBuffer = new byte[3];
		this.m_iBufSize = 0;
		this.m_iOutSize = 0;
		this.m_iMaxLine = lin > 0 ? lin : 76;
	}

	/**
	 * @see java.io.OutputStream#close()
	 */
	@Override
	public void close() throws IOException {
		this.flush();
		this.out.close();
	}

	private void encode() throws IOException {
		if (m_iOutSize + 4 > m_iMaxLine) {
			out.write('\r');
			out.write('\n');
			m_iOutSize = 0;
		}

		if (m_iBufSize == 1) {
			byte a = m_baBuffer[0];
			byte b = 0;
			out.write(entable[(a >>> 2) & 0x3F]);
			out.write(entable[((a << 4) & 0x30) + ((b >>> 4) & 0xf)]);
			out.write('='); // pad character
			out.write('='); // pad character
		} else if (m_iBufSize == 2) {
			byte a = m_baBuffer[0];
			byte b = m_baBuffer[1];
			byte c = 0;
			out.write(entable[(a >>> 2) & 0x3F]);
			out.write(entable[((a << 4) & 0x30) + ((b >>> 4) & 0xf)]);
			out.write(entable[((b << 2) & 0x3c) + ((c >>> 6) & 0x3)]);
			out.write('='); // pad character
		} else {
			byte a = m_baBuffer[0];
			byte b = m_baBuffer[1];
			byte c = m_baBuffer[2];
			out.write(entable[(a >>> 2) & 0x3F]);
			out.write(entable[((a << 4) & 0x30) + ((b >>> 4) & 0xf)]);
			out.write(entable[((b << 2) & 0x3c) + ((c >>> 6) & 0x3)]);
			out.write(entable[c & 0x3F]);
		}

		// increment count
		m_iOutSize += 4;
	}

	/**
	 * @see java.io.OutputStream#flush()
	 */
	@Override
	public void flush() throws IOException {
		if (m_iBufSize > 0) {
			encode();
			m_iBufSize = 0;
		}
		out.flush();
	}

	/**
	 * @see java.io.OutputStream#write(byte[], int, int)
	 */
	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		for (int i = 0; i < len; i++) {
			this.write(b[i + off]);
		}
	}

	/**
	 * @see java.io.OutputStream#write(byte[])
	 */
	@Override
	public void write(byte[] b) throws IOException {
		this.write(b, 0, b.length);
	}

	/**
	 * @see java.io.OutputStream#write(int)
	 */
	@Override
	public void write(int b) throws IOException {
		m_baBuffer[m_iBufSize++] = (byte) b;
		if (m_iBufSize == 3) {
			encode();
			m_iBufSize = 0;
		}
	}

}
