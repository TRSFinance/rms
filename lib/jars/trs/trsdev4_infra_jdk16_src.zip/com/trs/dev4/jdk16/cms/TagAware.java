package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * 置标对象的数据源接口
 * 
 * 对接口的修改，需要考虑TagAwareProxyFactory中对该接口的代理
 * 
 * @author yangyu
 * @since Jan 16, 2013 3:35:51 PM
 */
public interface TagAware<T> {

	/**
	 * 获取数据源的查询条件总数
	 * 
	 * @param sf
	 * @return
	 * @since yangyu @ Jul 30, 2013
	 */
	int total(SearchFilter sf);

	/**
	 * 根据查询条件获取单个对象
	 * 
	 * @param searchFilter
	 * @return
	 * @since yangyu @ Jul 30, 2013
	 */
	T getPublishObject(SearchFilter searchFilter);

	/**
	 * 根据对象ID获取
	 * 
	 * @param value
	 * @return
	 * @since yangyu @ Jul 30, 2013
	 */
	T getPublishObjectById(int value);

	/**
	 * 设置缓存时间
	 * 
	 * @return
	 * @since yangyu @ Jul 30, 2013
	 */
	int objectCachedTime();

	/**
	 * 获取查询条件的列表信息
	 * 
	 * @param searchFilter
	 * @return
	 * @since yangyu @ Jul 30, 2013
	 */
	PagedList<T> pagePublishObjects(SearchFilter searchFilter);

	/**
	 * 获取数据源对象非属性信息
	 * 
	 * @param publishable
	 * @param key
	 * @param tagContext
	 * @return
	 * @since yangyu @ 2012-6-17
	 */
	Object getExtraProperty(PublishObject publishable, String key, TagContext tagContext);

	/**
	 * 描述非领域对象中的数据的属性列表
	 * 
	 * @return
	 * @since yangyu @ Oct 29, 2012
	 */
	String[] specialTagAttribute();

	/**
	 * 数据源对象的Class
	 * 
	 * @return
	 * @since yangyu @ Jul 30, 2013
	 */
	Class<T> getTagClass();

}
