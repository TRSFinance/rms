package com.trs.dev4.jdk16.view;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.ServletWebRequest;

import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.example.Captcha;
import com.trs.dev4.jdk16.servlet24.RequestUtil;
import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.verifycode.ICaptchaService;

/**
 * 
 * 职责: <br>
 * 验证问答维护 对验证问答对象进行增删改操作
 * 
 */
@Controller("captchaAction")
@RequestMapping(value = "/console/captcha.do")
public class CaptchaAction {
	/**
	 * 日志对象
	 */
	private static final Logger logger = Logger.getLogger(CaptchaAction.class);
	/**
	 * 注入验证码服务
	 * 
	 * @since dujie @ 2011-10-12
	 */
	@Resource(name = "captchaService")
	private ICaptchaService captchaService;

	/**
	 * 成功页面
	 * 
	 * @since dujie @ 2011-10-14
	 */
	private String successView = "redirect:/console/captcha.do?action=list";

	/**
	 * 列表页面
	 * 
	 * @since dujie @ 2011-10-14
	 */
	private String listView = "captcha/captchaList";

	/**
	 * 修改页面
	 * 
	 * @since dujie @ 2011-10-14
	 */
	private String formView = "captcha/captchaForm";

	/**
	 * 验证问答列表
	 * 
	 * @param request
	 *            Servlet请求
	 * @param response
	 *            Servlet响应
	 * @return listView 页面
	 * @throws Exception
	 * @since dujie @ 2011-10-12
	 */
	@RequestMapping(params = "action=list")
	public String list(ServletWebRequest request, ModelMap model) throws Exception {

		RequestWrapper requestWrapper = RequestWrapper.getWrapper(request);
		SearchFilter searchFilter = requestWrapper.getSearchFilter();
		searchFilter.addGreaterThan("id", 0);
		model.addAttribute(captchaService.pagedCaptchas(searchFilter));
		return listView;
	}


	/**
	 * 删除验证问答
	 * 
	 * @param request
	 *            Servlet请求
	 * @param model
	 *            模型
	 * @return successView 页面
	 * @throws Exception
	 * @since dujie @ 2011-10-12
	 */
	@RequestMapping(params = "action=delete")
	public String delete(ServletWebRequest request, ModelMap model) throws Exception {
		
		int[] ids = RequestUtil.getParameterAsIntArray(request.getRequest(), "cId", 0);
 		this.captchaService.deleteCaptchas(ids);
		return successView;

	}

	/**
	 * 
	 * 添加验证问答
	 * 
	 * @param request
	 *            Servlet请求
	 * 
	 * @return successView 页面
	 * @throws Exception
	 * @since dujie @ 2011-10-12
	 */

	@RequestMapping(params = "action=setupCaptcha", method = RequestMethod.GET)
	public String setupCaptcha(ServletWebRequest request, ModelMap model) throws Exception {

		int captchaId = RequestUtil.getParameterAsInt(request.getRequest(), "cId", 0);
		if (captchaId > 0) {
			Captcha captcha = this.captchaService.getCaptcha(captchaId);
			model.addAttribute("captcha", captcha);
		} else {
			model.addAttribute("captcha", new Captcha());
		}
		return formView;
	}

	/**
	 * 保存验证码
	 * 
	 * @param request
	 *            Http 请求
	 * @param model
	 *            模型
	 * @return
	 * @throws Exception
	 * @since TRS @ Oct 25, 2011
	 */
	@RequestMapping(params = "action=processCaptcha", method = RequestMethod.POST)
	public String processCaptcha(ServletWebRequest request, ModelMap model) throws Exception {

		String question = RequestUtil.getParameter(request.getRequest(), "question", "");

		if (StringHelper.isEmpty(question) || !StringHelper.limitedLength(question, 2, 25)) {
			throw new IllegalArgumentException();
		}

		String answer = RequestUtil.getParameter(request.getRequest(), "answer", "");

		if (StringHelper.isEmpty(answer) || !StringHelper.limitedLength(answer, 0, 10)) {
			throw new IllegalArgumentException();
		}

		int captchaId = RequestUtil.getParameterAsInt(request.getRequest(), "cId", 0);
		Captcha captcha = this.captchaService.getCaptcha(captchaId);
		if (captcha == null) {
			captcha = new Captcha();
		}
		captcha.setQuestion(question);
		captcha.setAnswer(answer);

		this.captchaService.saveOrUpdate(captcha);

		if (logger.isDebugEnabled()) {
			logger.debug("captcha:" + captcha.toString() + "question:" + question + "answer:" + answer);
		}
		return successView;
	}

}
