package com.trs.dev4.jdk16.cms.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.springframework.web.util.JavaScriptUtils;

import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.PageletsScheduler;
import com.trs.dev4.jdk16.cms.bo.Pagelet;
import com.trs.dev4.jdk16.cms.bo.TagContext;

/**
 * 
 * @author yangyu
 * @since Feb 4, 2013 3:21:26 PM
 */
public class PageletsSchedulerImpl implements PageletsScheduler {

	private static ExecutorService executor = Executors.newCachedThreadPool();

	@Override
	public String parse(final GeneratorSession generatorSession, final Pagelet pagelet) {
		return generatorSession.parse(new TagContext(generatorSession, pagelet.getTagItem()));
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.PageletsScheduler#parse(com.trs.dev4.jdk16.cms.GeneratorSession, java.util.Set)
	 * @since yangyu @ Aug 12, 2013
	 */
	@Override
	public void parse(final GeneratorSession generatorSession, Set<Pagelet> pagelets) {

		List<Callable<Boolean>> tasks = new ArrayList<Callable<Boolean>>();

		for (final Pagelet pagelet : pagelets) {
			tasks.add(new Callable<Boolean>() {
				public Boolean call() {
					try {
						StringBuilder content = new StringBuilder();
						content.append("<script>arrivedHtml(\"").append(pagelet.getId()).append("\",\"").append(
								JavaScriptUtils.javaScriptEscape(parse(generatorSession, pagelet))).append(
								"\");</script>").toString();
						generatorSession.flushContent(content.toString());
					} catch (Exception e) {
						return false;
					}
					return true;
				}
			});
		}

		try {
			executor.invokeAll(tasks, 1500, TimeUnit.MILLISECONDS);
		} catch (InterruptedException ignored) {
		}
	}
}
