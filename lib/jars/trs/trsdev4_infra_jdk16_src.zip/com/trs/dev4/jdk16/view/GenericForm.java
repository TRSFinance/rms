package com.trs.dev4.jdk16.view;

/**
 * 通用的Form对象.<br>
 * 
 * @author TRS信息技术有限公司
 */
public class GenericForm<E> {

	/**
	 * 是否是新建对象时的表单.
	 */
	protected boolean newForm;

	/**
	 * 实体对象.
	 */
	protected E element;

	/**
	 * 
	 * @param element
	 * @param isNew
	 */
	public GenericForm(E element, boolean isNew) {
		this.element = element;
		this.newForm = isNew;
	}
	
	/**
	 * Get the {@link #newForm}. 
	 * @return the {@link #newForm}.
	 */
	public boolean isNewForm() {
		return newForm;
	}

	/**
	 * Set the {@link #newForm}.
	 * @param isNew the isNew to set
	 */
	public void setNewForm(boolean isNew) {
		this.newForm = isNew;
	}

	/**
	 * Get the {@link #element}. 
	 * @return the {@link #element}.
	 */
	public E getElement() {
		return element;
	}

	/**
	 * Set the {@link #element}.
	 * @param element the element to set
	 */
	public void setElement(E element) {
		this.element = element;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{isNew=").append(newForm).append("; E=").append(element)
				.append(";");
		sb.append(super.toString()).append("}");
		return sb.toString();
	}

}
