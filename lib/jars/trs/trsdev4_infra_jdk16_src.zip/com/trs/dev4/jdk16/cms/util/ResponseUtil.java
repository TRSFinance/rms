/*
 * Created: liushen@Dec 1, 2008 3:24:47 PM
 */
package com.trs.dev4.jdk16.cms.util;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

/**
 * HTTP响应工具类.<br>
 * 
 * @author TRS信息技术有限公司
 */
public class ResponseUtil {

	/**
	 * 构造函数私有.
	 */
	protected ResponseUtil() {
	}

	/**
	 * 给HTTP响应头添加清空缓存标记.
	 */
	public static void clearCache(HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache");
		response.addHeader("Cache-Control", "no-store"); // FireFox
		response.setHeader("Pragma", "no-cache"); // HTTP 1.0
		response.setDateHeader("Expires", -1);
		response.setDateHeader("max-age", 0);
	}

	/**
	 * 给HTTP响应头中, 设置缓存时间.
	 * 
	 * @param ms
	 *            缓存时间(毫秒).
	 */
	public static void setCacheExpire(HttpServletResponse response, long ms) {
		long curTime = System.currentTimeMillis();
		response.setDateHeader("Last-Modified", curTime);
		response.setDateHeader("Expires", curTime + ms);
	}

	/**
	 * 返回Json格式的字符串
	 * 
	 * @param response
	 *            HTTP响应
	 * @param json
	 *            返回给客户端的JSON数据
	 * @throws IOException
	 * @since fangxiang @ May 31, 2010
	 */
	public static void json(HttpServletResponse response, String json) throws IOException {
		response(response, json, "utf-8", "text/html");
	}

	/**
	 * 返回正文内容
	 * 
	 * @param response
	 * @param text
	 * @throws IOException
	 * @since fangxiang @ Oct 19, 2010
	 */
	public static void response(HttpServletResponse response, String textPlain) throws IOException {
		response(response, textPlain, "utf-8", "text/html");
	}

	/**
	 * 将给定的文本内容(字符串)返回给客户端.
	 * 
	 * @param response
	 * @param textPlain
	 * @param encoding
	 *            编码；为<code>null</code>则不设置.
	 * @param contentType
	 *            内容类型；为<code>null</code>则设置为默认值( <code>text/plain</code>).
	 * @throws IOException
	 * @since liushen @ Mar 3, 2011
	 */
	public static void response(HttpServletResponse response, String textPlain, String encoding, String contentType) throws IOException {
		if (contentType != null) {
			response.setContentType(contentType);
		} else {
			response.setContentType("text/plain");
		}
		if (encoding != null) {
			response.setCharacterEncoding(encoding);
		}
		// liushen@Mar 31, 2011: 不能设置setContentLength头, 否则在包含中文时浏览器可能收不全!
		// 见JIRA TRSMAS-478
		response.getWriter().write(textPlain);
		response.flushBuffer();
	}

	/**
	 * 重定向
	 * 
	 * @param response
	 * @param redirectUrl
	 * @throws IOException
	 * @since TRS @ Feb 14, 2012
	 */
	public static void redirect(HttpServletResponse response, String redirectUrl) throws IOException {
		response.sendRedirect(redirectUrl);
	}
}
