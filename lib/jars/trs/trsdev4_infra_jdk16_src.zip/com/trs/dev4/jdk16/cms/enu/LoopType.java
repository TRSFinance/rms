package com.trs.dev4.jdk16.cms.enu;

/**
 * TODO 职责说明
 * 
 * @author yangyu
 * @since Mar 20, 2013 9:39:32 AM
 */
public enum LoopType {
	LOOP {
		@Override
		public boolean needLoop() {
			return false;
		}
	},
	NOLOOP {
		@Override
		public boolean needLoop() {
			return true;
		}
	};

	public static LoopType getLoopType(String value) {
		LoopType loopType = null;
		try {
			loopType = LoopType.valueOf(value.toUpperCase());
		} catch (IllegalArgumentException e) {
			return NOLOOP;
		}
		return loopType;
	}

	public abstract boolean needLoop();

}
