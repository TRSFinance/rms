package com.trs.dev4.jdk16.cms.bo;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import com.trs.dev4.jdk16.servlet24.CookieHelper;
import com.trs.dev4.jdk16.servlet24.RequestUtil;

/**
 * Request封装类
 * 
 * @author yangyu
 * @since Mar 13, 2013 3:33:22 PM
 */
public class RequestWrapper {

	private HttpServletRequest httpRequest;

	/**
	 * 用于封装请求HttpRequest
	 * 
	 * @param request
	 * @return
	 * @since yangyu @ Apr 11, 2013
	 */
	public static RequestWrapper getWebRequestContext(ServletRequest request) {
		RequestWrapper requestWrapper = new RequestWrapper();
		requestWrapper.httpRequest = (HttpServletRequest) request;
		return requestWrapper;
	}

	public String getParameter(String parameterName) {
		if (null == httpRequest) {
			return null;
		}
		return httpRequest.getParameter(parameterName);
	}

	public HttpServletRequest getRequest() {
		return httpRequest;
	}

	public String getQueryString() {
		return httpRequest.getQueryString();
	}

	public String getRequestURL() {
		return httpRequest.getRequestURL().toString();
	}
	
	public String getRequestURI() {
		return httpRequest.getRequestURI();
	}

	/**
	 * @return
	 * @since yangyu @ Mar 28, 2013
	 */
	public String getUriAfterContextPath() {
		return httpRequest.getRequestURI().substring(httpRequest.getContextPath().length());
	}

	/**
	 * @return
	 * @since yangyu @ Apr 1, 2013
	 */
	public boolean fromIOS() {
		return RequestUtil.fromIOS(httpRequest);
	}

	/**
	 * @return
	 * @since yangyu @ Apr 1, 2013
	 */
	public Object getContextUrl() {
		return RequestUtil.getContextUrl(httpRequest);
	}
	
	public String getCookie(String cookieName) {
		if (null == httpRequest) {
			return null;
		}
		CookieHelper cookieHelper = new CookieHelper(httpRequest, null);
		return cookieHelper.getValue(cookieName);
	}

	/**
	 * @param functionParam
	 * @return
	 * @since yangyu @ Jun 7, 2013
	 */
	public int[] getParameterAsIntArray(String functionParam) {
		return RequestUtil.getParameterAsIntArray(httpRequest, functionParam);
	}

	/**
	 * @param request
	 * @return
	 * @since yangyu @ Jul 10, 2013
	 */
	public String getRelativePath(HttpServletRequest request) {
		return RequestUtil.getRelativePath(request);
	}
}
