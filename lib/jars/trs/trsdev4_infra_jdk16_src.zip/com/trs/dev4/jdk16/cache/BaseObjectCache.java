/*
 * Created: liushen@Mar 31, 2010 2:27:19 PM
 */
package com.trs.dev4.jdk16.cache;

/**
 * 默认的抽象实现.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public abstract class BaseObjectCache<K, V> implements IObjectCache<K, V> {

}
