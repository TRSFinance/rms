package com.trs.dev4.jdk16.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.trs.dev4.jdk16.exception.DAOException;

/**
 * 数据库存取接口, 其中领域对象由泛型参数传入.
 * 
 * <b>注意:</b>该接口的所有方法都会执行数据库查询或写入操作；如果在数据库操作出现错误, 则将抛出{@link DAOException}异常,
 * 此异常为运行时异常, 由调用者处理.
 */
public interface IAccessor<T> {

	/**
	 * 向数据库中插入一个对象.
	 * 
	 * @param object
	 *            待插入的对象.
	 * @return 新对象的ID.
	 */
	Serializable insert(T object) throws DAOException;

	/**
	 * 向数据库中批量插入新对象.
	 * 
	 * @param object
	 *            待插入的对象集.
	 * @return 实际插入的条数。
	 * @creator fangxiang @ Mar 17, 2009
	 */
	int batchInsert(T[] objects) throws DAOException;

	/**
	 * 快速批量插入新对象（简单对象），只开一个事务。
	 * 
	 * @param objects
	 *            待插入的对象集.
	 * @return 实际插入的条数。
	 * @throws DAOException
	 * @since liushen @ Jan 10, 2015
	 */
	int batchInsert(List<T> objects) throws DAOException;

	/**
	 * 批量对象删除
	 * 
	 * @param objects
	 * @throws DAOException
	 * @since fangxiang @ Nov 13, 2010
	 */
	void batchDelete(T[] objects) throws DAOException;

	/**
	 * 批量对象更新
	 * 
	 * @param objects
	 * @throws DAOException
	 * @since fangxiang @ Nov 13, 2010
	 */
	void batchUpdate(T[] objects) throws DAOException;

	/**
	 * 从数据库删除一个对象.
	 * 
	 * @param object
	 *            待删除的对象.
	 */
	void delete(T object) throws DAOException;

	/**
	 * 根据表达式批量删除对象.
	 * 
	 * @param builder
	 * @return 返回删除的记录数; 如果没有记录被删除, 则返回<code>0</code>.
	 * @throws DAOException
	 * @creator fangxiang @ Mar 17, 2009
	 */
	int batchDelete(HQLBuilder builder) throws DAOException;

	/**
	 * 根据查询条件删除对象.
	 * 
	 * @param sf
	 * @return 返回删除的记录数; 如果没有记录被删除, 则返回<code>0</code>.
	 */
	int delete(SearchFilter sf);

	/**
	 * 更新对象到数据库；如对象尚不存在，则添加到数据库.
	 * 
	 * @param object
	 *            待更新的对象
	 */
	void update(T object) throws DAOException;

	/**
	 * 更新对象的指定字段到数据库. 该方法可配合hibernate实体对象的dynamicUpdate配置来提高性能.
	 * 
	 * @param id
	 *            待更新对象的ID
	 * @param updatedFields
	 *            所有要更新的字段的Map，Key为字段名，Object为字段值
	 * @return 返回更新的记录数; 如果没有记录被更新, 则返回<code>0</code>.
	 * @since liushen @ Dec 2, 2011
	 */
	int update(int id, Map<String, Object> updatedFields);

	/**
	 * 是 {@link #update(int, Map)} 只更新一个字段的特例。
	 * 
	 * @see #update(int, Map)
	 * @since liushen @ Dec 2, 2011
	 */
	int update(int id, String field, Object value);

	/**
	 * 根据表达式批量更新对象.
	 * 
	 * @param builder
	 * @return 返回更新的记录数; 如果没有记录被更新, 则返回<code>0</code>.
	 * @throws DAOException
	 * @creator fangxiang @ Mar 17, 2009
	 */
	int batchUpdate(HQLBuilder builder) throws DAOException;

	/**
	 * 根据id值获取对象.
	 * 
	 * @param objectId
	 * @return
	 */
	T getObject(int objectId) throws DAOException;

	/**
	 * 从数据库中获取ID最大的对象。
	 * 
	 * @return 表为空返回<code>null</code>.
	 * @since liushen @ Apr 29, 2015
	 */
	T byMaxId();

	/**
	 * 从数据库中获取ID最小的对象。
	 * 
	 * @return 表为空返回<code>null</code>.
	 * @since liushen @ Apr 29, 2015
	 */
	T byMinId();

	/**
	 * 根据ID的最大值、最小值来计算数据表的对象数，仅适用于ID连续的数据表。
	 * 
	 * @return 表为空返回<code>0</code>.
	 * @since liushen @ Apr 29, 2015
	 */
	long countByIdMaxToMin();

	/**
	 * 查指定列的最大值。
	 * 
	 * @param fieldName
	 * @return
	 * @since liushen @ Apr 29, 2015
	 */
	long max(String fieldName);

	/**
	 * 查指定列的最小值。
	 * 
	 * @param fieldName
	 * @return
	 * @since liushen @ Apr 29, 2015
	 */
	long min(String fieldName);

	/**
	 * @return 对象列表.
	 */
	List<T> listObjects() throws DAOException;

	/**
	 * 
	 * @param sf
	 * @return 对象列表; 如果符合条件的记录不存在, 返回一个长度为0的List, 而不是<code>null</code>.
	 */
	List<T> listObjects(SearchFilter sf) throws DAOException;

	/**
	 * 
	 * @param fieldName
	 * @param value
	 * @return 对象列表.
	 * @throws DAOException
	 * @creator liushen @ Jan 25, 2010
	 */
	List<T> listObjects(String fieldName, Object value)
			throws DAOException;

	/**
	 * 传入select内容以及表对应的对象名称，返回对象数组列表
	 * 
	 * @param sf
	 * @param indicators,属性与属性间逗号分隔
	 * @param tableEntityName
	 * @return
	 * @throws DAOException
	 * @since js @ 2015年4月10日
	 */
	List<Object[]> listSelectedFieldsObjects(SearchFilter sf, String indicators,String tableEntityName) throws DAOException;
	
	/**
	 * 传入select内容，返回对象数组列表
	 * 
	 * @param sf
	 * @param indicators，属性与属性间逗号分隔
	 * @return
	 * @throws DAOException
	 * @since js @ 2015年4月13日
	 */
	List<Object[]> listSelectedFieldsObjects(SearchFilter sf, String indicators) throws DAOException;
	
	/**
	 * 
	 * @return 分页结果.
	 * @throws DAOException
	 * @creator liushen @ Feb 15, 2010
	 */
	PagedList<T> pagedAll() throws DAOException;

	/**
	 * 
	 * @param sf
	 *            查询条件
	 * @return 分页结果.
	 */
	PagedList<T> pagedObjects(SearchFilter sf) throws DAOException;

	/**
	 * 返回第一个符合条件的对象；条件为给定字段等于给定的取值.
	 * 
	 * @param field
	 *            字段名
	 * @param value
	 *            取值
	 * @return 对象T；如果不存在则返回<code>null</code>.
	 * @throws DAOException
	 * @since liushen @ Apr 22, 2010
	 */
	T findFirst(String field, Object value) throws DAOException;

	/**
	 * 执行一条HQL查询语句，返回查询结果. <b>注意:</b>此方法仅为统计等复杂查询提供, 不做参数绑定，以后会根据需要调整；因此,
	 * 非必要时不要调用此方法!
	 * 
	 * @param hql
	 * @return 对象列表.
	 * @throws DAOException
	 * @creator liushen @ May 5, 2009
	 */
	List<? extends Object> executeQuery(String hql) throws DAOException;

	/**
	 * 执行一条HQL查询语句，返回查询结果. <b>注意:</b>此方法仅为统计等复杂查询提供, 不做参数绑定，以后会根据需要调整；因此,
	 * 非必要时不要调用此方法!
	 * 
	 * @param hql
	 * @param startPos
	 *            记录的起始位置
	 * @param maxResult
	 *            需要获取到的最大的数值，如果大于0，则默认取该数值的记录条数，否则，返回所有对象
	 * @return 对象列表.
	 * @throws DAOException
	 * @creator liushen @ May 5, 2009
	 */
	List<? extends Object> executeQuery(String hql, int startPos, int maxResult) throws DAOException;

	/**
	 * 执行返回单个整数的HQL，返回整数，便于执行max/min等统计函数。
	 * 
	 * @return 如果结果为null，则返回<code>0</code>；如果结果为多条记录或者不是整数，则抛出异常。
	 * @throws DAOException
	 *             查询数据库出错，或者结果不是单个整数。
	 * @since liushen @ Oct 14, 2013
	 */
	int uniqueResultAsInt(String statHQL) throws DAOException;

	/**
	 * 执行返回单个长整形的HQL，返回整数，便于执行max/min等统计函数。
	 * 
	 * @param statHQL
	 * @return 如果结果为null，则返回<code>0</code>；如果结果为多条记录或者不是整数／长整形，则抛出异常。
	 * @throws DAOException
	 *             查询数据库出错，或者结果不是单个整数／长整形。
	 * @since yirongyi @ 2014年10月11日
	 */
	long uniqueResultAsLong(String statHQL) throws DAOException;

	/**
	 * 执行返回单个长整形的HQL，返回整数，便于执行max/min等统计函数。
	 * 
	 * @param hql
	 * @return 如果结果为null，则返回<code>0f</code>；如果结果为多条记录或者不是整数／长整形，则抛出异常。
	 * @throws DAOException
	 *             查询数据库出错，或者结果不是单个浮点数。
	 * @since yirongyi @ 2015年6月19日
	 */
	Float uniqueResultAsFloat(String hql) throws DAOException;

	/**
	 * 执行返回单个长整形的HQL，返回长整数，便于执行count等统计函数。
	 * 
	 * @param sql
	 * @return 如果结果为多条记录或者不是整数／长整形，则返回<code>0</code>；
	 * @throws DAOException
	 *             查询数据库出错。
	 * @since yirongyi @ 2014年10月31日
	 */
	long uniqueResultAsLongBySql(String sql) throws DAOException;

	/**
	 * 执行一条SQL查询语句，返回查询结果。<b>注意:</b>此方法仅为统计等复杂查询提供, 不做参数绑定，以后会根据需要调整；因此,
	 * 非必要时不要调用此方法!
	 * 
	 * @param sql
	 * @return
	 * @throws DAOException
	 * @since zoumei @ 2013-5-13
	 */
	List<? extends Object> executeNativeQuerySQL(String sql) throws DAOException;

	/**
	 * 执行一条SQL查询语句，可指定返回结果记录开始位置和数目。<b>注意:</b>此方法仅为统计等复杂查询提供, 不做参数绑定，以后会根据需要调整；因此,
	 * 非必要时不要调用此方法!
	 * 
	 * @param sql
	 * @param startPos
	 * @param maxResult
	 * @return
	 * @throws DAOException
	 * @since zoumei @ 2013-5-13
	 */
	List<? extends Object> executeNativeQuerySQL(String sql, int startPos, int maxResult) throws DAOException;

	/**
	 * 判断指定属性字段和属性值的对象是否存在.
	 * 
	 * @param field
	 *            属性字段名
	 * @param value
	 *            属性值
	 * @return 如果存在则返回true，如果不存在的话则返回false
	 */
	boolean exists(String field, Object value) throws DAOException;

	/**
	 * 判断指定属性字段和属性值的对象是否存在
	 * 
	 * @param field
	 *            属性字段名
	 * @param value
	 *            属性值
	 * @param excludedId
	 *            排除的编号
	 * @return 如果存在则返回true，如果不存在的话则返回false
	 */
	boolean exists(String field, Object value, int excludedId)
			throws DAOException;

	/**
	 * 获取该领域对象对应的数据表的总记录数, 其中领域对象由该接口的泛型参数传入.
	 * 
	 * @return 该领域对象对应的数据表的总记录数
	 * @creator liushen @ Mar 17, 2009
	 */
	int total() throws DAOException;

	/**
	 * 获取该领域对象对应的数据表中，符合查询条件的总记录数.
	 * 
	 * @param sf
	 *            查询条件
	 * @return 符合查询条件的总记录数.
	 * @creator liushen @ Apr 30, 2009
	 */
	int total(SearchFilter sf);

	/**
	 * 执行一条原生SQL DML（即INSERT/UPDATE/DELETE）语句，不支持SELECT查询语句，
	 * 执行SQL查询用executeNativeQuerySQL(String sql)方法。
	 * 注意：本方法非必要情况下，不要使用；滥用会造成对数据库的依赖.
	 * 
	 * @param sql
	 *            完整SQL DML语句
	 * @return 影响的记录条数
	 * @since liushen @ Mar 22, 2010
	 */
	int executeNativeUpdateSQL(String sql);

	/**
	 * 执行多条原生SQL DML（即INSERT/UPDATE/DELETE）语句，不支持SELECT查询语句。
	 * 注意：本方法非必要情况下，不要使用；滥用会造成对数据库的依赖.
	 * 
	 * @param statements
	 *            完整SQL DML语句
	 * @return 影响的记录条数
	 * @since liushen @ Mar 22, 2010
	 */
	int executeNativeUpdateSQL(String[] statements);

	/**
	 * 将给定id记录的某字段值增加delta, 由数据库自身来提供多进程安全性, 即update table XX set
	 * fieldX=fieldX+delta这类SQL语句. 目前只开放按id取值来进行该操作的方法; 后续根据实际需要再逐步扩大where条件的支持.
	 * 
	 * @param field
	 *            字段名
	 * @param delta
	 *            正数表示增加, 负数表示减少, 0则不做操作
	 * @param whichId
	 *            id取值
	 * @return 影响的记录条数
	 * @since liushen @ Apr 28, 2010
	 */
	int deltaUpdate(String field, long delta, int whichId);

	/**
	 * 内部接口.
	 * 
	 * @return
	 * @creator liushen @ Jun 1, 2009
	 */
	DBSummary retriveDBSummary();

	/**
	 * 返回范型实体的类型.
	 * 
	 * @return
	 * @since liuyou @ 2010-4-19
	 */
	Class<T> getClassType();

	/**
	 * 获取该实体对象对应的数据库表名.
	 * 
	 * @return 数据表名
	 * @since liushen @ Apr 29, 2010
	 */
	String getTableName();

	/**
	 * 获取该实体对象对应的数据表的标识列名称.
	 * 
	 * @return 数据表的标识列名称
	 * @since liushen @ Jun 23, 2010
	 */
	String getIdFieldName();

	/**
	 * 
	 * @return TODO
	 * @throws DAOException
	 */
	int truncate() throws DAOException;

	/**
	 * 获取符合条件的唯一结果；如果超过1条，会抛出异常。
	 * 
	 * @param sf
	 *            查询条件
	 * @see #findFirst(SearchFilter)
	 */
	public T findUnique(SearchFilter sf);

	/**
	 * 根据检索条件获取第一个符合条件的对象。
	 * 
	 * @param sf
	 *            查询条件
	 */
	public T findFirst(SearchFilter sf);

	/**
	 * 批量保存对象
	 * 
	 * @param objects
	 *            对象集合
	 * @throws DAOException
	 *             发生错误时抛出
	 */
	public void batchUpdate(List<T> objects) throws DAOException;

	/**
	 * 获取符合条件的对象ID集合
	 * 
	 * @param searchFilter
	 *            查询条件
	 * @return 符合分页条件的对象ID集合
	 * @throws DAOException
	 *             发生数据库错误时抛出
	 */
	public PagedList<Integer> pagedObjectIds(SearchFilter searchFilter)
			throws DAOException;

	/**
	 * 将所有字段field值为旧值oldValue的记录改为新值newValue；并且整个过程只执行一条Update语句，以提高性能.
	 * 
	 * @param field
	 *            字段
	 * @param oldValue
	 *            旧值
	 * @param newValue
	 *            新值
	 * @return 影响的记录条数
	 * @since xuyan @ 2012-9-29
	 */
	int bulkUpdate(String field, Object oldValue, Object newValue);

	/**
	 * 执行一条批量更新/删除数据的HQL。
	 * 
	 * @param hql
	 *            批量更新/删除数据的HQL
	 * @param values
	 *            绑定的参数
	 * @return 影响的记录条数
	 * @since liushen @ Jan 7, 2015
	 */
	int bulkUpdate(final String hql, final Object... values);

	/**
	 * 增加索引，通过JDBC执行；只接受<code>create index</code>语句。
	 * 
	 * @param sql
	 *            增加索引的create index语句
	 * @return JDBC返回的受影响的条数(貌似只对DML语句)；如果返回<code>-1</code>则表示并未实际执行，返回<code>-2</code>
	 *         表示SQL执行错误(比如索引已存在)。
	 * @throws DAOException
	 * @since yirongyi @ 2015年2月11日
	 */
	int createIndex(String sql) throws DAOException;


}
