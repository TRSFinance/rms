/*
 * Created: liuyou@2010-5-19 下午01:19:32
 */
package com.trs.dev4.jdk16.remoting;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.trs.dev4.jdk16.exception.BussinessException;

/**
 * Spring框架下远程调用的通用实现
 * 
 */
public class Executor implements IExecutor, ApplicationContextAware {

	protected ApplicationContext applicationContext;

	/**
	 * @see com.trs.dev4.jdk16.remoting.IExecutor#service(java.lang.String,
	 *      java.lang.String, java.lang.Object[])
	 * @since liuyou @ 2010-5-19
	 */
	@Override
	public Object service(String beanName, String methodName, Object... args) {
		Object beanService = applicationContext.getBean(beanName);
		if (beanService == null)
			throw new BussinessException("no bean[" + beanName + "] exsited.");
		Method actionMethod = null;
		try {
			Class<? extends Object> clazzService = beanService.getClass();
			Method[] methods = clazzService.getMethods();
			for (int i = 0; i < methods.length; i++) {
				Method currMethod = methods[i];
				if (!currMethod.getName().equals(methodName))
					continue;
				Class<?>[] argsTypes = currMethod.getParameterTypes();
				if (argsTypes.length != args.length)
					continue;
				boolean isMatched = true;
				for (int j = 0; j < argsTypes.length; j++) {
					if (args[j] == null)
						continue;
					Class<? extends Object> currArgClaz = args[j].getClass();
					Class<?> currDefArgClaz = argsTypes[j];
					if (currDefArgClaz.equals(currArgClaz)
							|| currDefArgClaz.isAssignableFrom(currArgClaz)) {
						continue;
					} else {
						if (currDefArgClaz.equals(int.class)
								&& currArgClaz.equals(Integer.class)) {
							continue;
						}
						if (currDefArgClaz.equals(double.class)
								&& currArgClaz.equals(Double.class)) {
							continue;
						}
						if (currDefArgClaz.equals(long.class)
								&& currArgClaz.equals(Long.class)) {
							continue;
						}
						isMatched = false;
						break;
					}
				}
				if (isMatched) {
					actionMethod = currMethod;
					break;
				}
			}
		} catch (SecurityException e) {
			throw new BussinessException(e);
		}
		if (actionMethod == null) {
			throw new BussinessException("no public method[" + methodName
					+ "]  in bean[" + beanName + "]");
		}
		try {
			return actionMethod.invoke(beanService, args);
		} catch (IllegalArgumentException e) {
			throw new BussinessException(e);
		} catch (IllegalAccessException e) {
			throw new BussinessException(e);
		} catch (InvocationTargetException e) {
			throw new BussinessException(e);
		}
	}

	/**
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 * @since liuyou @ 2010-5-19
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.applicationContext = applicationContext;
	}
}
