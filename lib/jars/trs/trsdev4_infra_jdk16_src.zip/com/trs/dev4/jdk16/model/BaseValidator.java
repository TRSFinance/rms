/*
 * Created: liushen@Jul 27, 2014 9:49:47 PM
 */
package com.trs.dev4.jdk16.model;

/**
 * 领域对象校验接口 {@link IValidator} 的抽象基类. <br>
 */
public abstract class BaseValidator implements IValidator {

	/**
	 * @see com.trs.dev4.jdk16.model.IValidator#validate(java.lang.String, java.lang.String)
	 * @since liushen @ Jul 27, 2014
	 */
	@Override
	public ValidationError validate(String name, String value) {
		return ValidationError.NO_ERROR;
	}

}
