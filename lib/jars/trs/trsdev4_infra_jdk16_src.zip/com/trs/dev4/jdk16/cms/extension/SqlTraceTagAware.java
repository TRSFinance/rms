/*
 * Created: Administrator@2013-11-14 下午04:26:03
 */
package com.trs.dev4.jdk16.cms.extension;

import org.apache.commons.lang.time.StopWatch;
import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.TagAware;
import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * 职责: <br>
 * 
 */
public class SqlTraceTagAware<T> implements TagAware<T> {

	protected static Logger LOG = Logger.getLogger(SqlTraceTagAware.class);
	
	private TagAware<T> tagAware;

	/**
	 * @param tagAware
	 */
	public SqlTraceTagAware(TagAware<T> tagAware) {
		super();
		this.tagAware = tagAware;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getExtraProperty(com.trs.dev4.jdk16.cms.bo.PublishObject, java.lang.String,
	 *      com.trs.dev4.jdk16.cms.bo.TagContext)
	 * @since Administrator @ 2013-11-14
	 */
	@Override
	public Object getExtraProperty(PublishObject publishable, String key, TagContext tagContext) {
		return tagAware.getExtraProperty(publishable, key, tagContext);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getPublishObject(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since Administrator @ 2013-11-14
	 */
	@Override
	public T getPublishObject(SearchFilter searchFilter) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		T t = tagAware.getPublishObject(searchFilter);
		stopWatch.stop();
		if (LOG.isDebugEnabled()) {
			LOG.debug(getTagClass().getSimpleName() + " get searchFilter " + searchFilter + " spend "
					+ stopWatch.getTime());
		}
		return t;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getPublishObjectById(int)
	 * @since Administrator @ 2013-11-14
	 */
	@Override
	public T getPublishObjectById(int id) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		T t = tagAware.getPublishObjectById(id);
		stopWatch.stop();
		if (LOG.isDebugEnabled()) {
			LOG.debug(getTagClass().getSimpleName() + " get id " + id + " spend " + stopWatch.getTime());
		}
		return t;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#getTagClass()
	 * @since Administrator @ 2013-11-14
	 */
	@Override
	public Class<T> getTagClass() {
		return tagAware.getTagClass();
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#objectCachedTime()
	 * @since Administrator @ 2013-11-14
	 */
	@Override
	public int objectCachedTime() {
		return tagAware.objectCachedTime();
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#pagePublishObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since Administrator @ 2013-11-14
	 */
	@Override
	public PagedList<T> pagePublishObjects(SearchFilter searchFilter) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		PagedList<T> pagedList = tagAware.pagePublishObjects(searchFilter);
		stopWatch.stop();
		if (LOG.isDebugEnabled()) {
			LOG.debug(getTagClass().getSimpleName() + " page searchFilter " + searchFilter + " spend "
					+ stopWatch.getTime());
		}
		return pagedList;
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#specialTagAttribute()
	 * @since Administrator @ 2013-11-14
	 */
	@Override
	public String[] specialTagAttribute() {
		return tagAware.specialTagAttribute();
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TagAware#total(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since Administrator @ 2013-11-14
	 */
	@Override
	public int total(SearchFilter sf) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		int count = tagAware.total(sf);
		stopWatch.stop();
		if (LOG.isDebugEnabled()) {
			LOG.debug(getTagClass().getSimpleName() + " total searchFilter " + sf + " spend "
					+ stopWatch.getTime());
		}
		return count;
	}

}
