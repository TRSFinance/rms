package com.trs.dev4.jdk16.cms.bo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.bo.TagItem.TagItemType;

/**
 * 模板的解析结果
 * 
 * @author yangyu
 * @since Feb 6, 2013 8:43:26 AM
 */
public class DocumentWrapper {

	private List<TagItem> tagNodes = new ArrayList<TagItem>();

	/**
	 * Pagelet所使用到的所有JS
	 */
	private Set<String> jsSet = new HashSet<String>();

	/**
	 * 模板的所有的Pagelet
	 */
	private Set<Pagelet> pagelets = new HashSet<Pagelet>();
	
	public Set<String> getJsSet() {
		return jsSet;
	}

	public void setJsSet(Set<String> jsSet) {
		this.jsSet = jsSet;
	}

	public Set<Pagelet> getPagelets() {
		return pagelets;
	}
	
	public void setPagelets(Set<Pagelet> pagelets) {
		this.pagelets = pagelets;
	}

	public void addPagelet(TagItem tagItem) {
		StringBuilder jsbuilder = new StringBuilder();
		String jses = tagItem.getAttribute("js");
		if (!StringUtils.isEmpty(tagItem.getAttribute("js"))) {
			String[] jsArray = StringUtils.split(jses, ";");
			for (int i = 0; i < jsArray.length; i++) {
				jsbuilder.append("<script src=\"").append(jsArray[i]).append("\"></script>");
				jsSet.add(jsArray[i]);
			}
		}
		Pagelet pagelet = new Pagelet(tagItem);
		pagelet.setId(tagItem.getAttribute("id"));
		
		if (!Boolean.valueOf(tagItem.getBooleanAttribute("bigpipe", true))) {
			tagItem.setTagItemType(TagItemType.TRSTAG);
			tagNodes.add(tagItem);
		} else {
			pagelets.add(pagelet);
			tagItem.setTagItemType(TagItemType.PAGELET);
			tagNodes.add(tagItem);
		}
		
	}

	public List<TagItem> getTagNodes() {
		return tagNodes;
	}

	public void setTagNodes(List<TagItem> textNodes) {
		this.tagNodes = textNodes;
	}

	/**
	 * 
	 * @param generatorSession
	 * @param tagItem
	 * @since Administrator @ 2013-11-13
	 */
	public void addTRSTag(GeneratorSession generatorSession, TagItem tagItem) {
		Settings settings = generatorSession.getSettings();
		if (settings.isCachedTag(tagItem)) {
			String resultContent = generatorSession.parse(new TagContext(generatorSession, tagItem));
			if (tagNodes.size() >= 1) {
				TagItem lastTagItem = tagNodes.get(tagNodes.size() - 1);
				if (lastTagItem.isTextTag()) {
					lastTagItem.appendContent(resultContent);
				} else {
					this.addTextNode(new TagItem(resultContent));
				}
			} else {
				this.addTextNode(new TagItem(resultContent));
			}
		} else {
			tagItem.setTagItemType(TagItemType.TRSTAG);
			tagNodes.add(tagItem);
		}
	}

	public void addTextNode(TagItem tagItem) {
		tagItem.setTagItemType(TagItemType.TEXT);
		tagNodes.add(tagItem);
	}

	/**
	 * @param tagItem
	 * @since Administrator @ 2013-11-12
	 */
	public void appendTextTag(TagItem tagItem) {
		this.addTextNode(tagItem);
	}
}
