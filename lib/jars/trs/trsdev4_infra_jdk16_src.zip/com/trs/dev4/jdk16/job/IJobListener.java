/*
 * Created: TRS@Jan 29, 2011 10:28:26 PM
 */
package com.trs.dev4.jdk16.job;

/**
 * 监听定时任务的执行
 * 
 */
public interface IJobListener {
	/**
	 * 执行前
	 * 
	 * @param jobExecutor
	 * @param jobDetail
	 * @since TRS @ Jan 29, 2011
	 */
	public void beforeExecute(IJobExecutor jobExecutor, JobDetail jobDetail);

	/**
	 * 执行后
	 * 
	 * @param jobExecutor
	 * @param jobDetail
	 * @since TRS @ Jan 29, 2011
	 */
	public void afterExecuted(IJobExecutor jobExecutor, JobDetail jobDetail);
}
