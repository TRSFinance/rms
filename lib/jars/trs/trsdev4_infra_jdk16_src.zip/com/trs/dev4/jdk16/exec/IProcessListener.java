/*
 * Created: liushen@Oct 10, 2013 7:26:53 PM
 */
package com.trs.dev4.jdk16.exec;

/**
 * 和 {@link ProcessThread} 配合，监听进程的启动和停止。 <br>
 * 
 */
public interface IProcessListener extends IProcessTerminatedListener {

	/**
	 * 
	 * @param processHelper
	 *            已经执行完进程的 {@link ProcessHelper}.
	 * @since liushen @ Nov 30, 2012
	 */
	void afterStarted(ProcessHelper processHelper);

}
