/*
 * liushen, Created on 2006-7-25 上午10:38:14
 */
package com.trs.dev4.jdk16.http;

import java.util.Iterator;
import java.util.Map;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpConnectionManager;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpState;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.HeadMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.utils.NetUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 纯HTTP客户端. 和业务功能及参数等无关. 内部基于Apache Commons HttpClient实现，但该类的使用者不依赖HttpClient. <BR>
 */
@SuppressWarnings("rawtypes")
public class PureClient {

	/**
	 * HTTP请求未能发出的情况(如网络连接等)
	 */
	static final int CODE_EXCEPTION = 600;

	private static final Logger LOG = Logger.getLogger(PureClient.class);

	/**
	 * 默认的http连接的超时时间.
	 */
	private static final int CONN_TIMEOUT = 20000;
	/**
	 *
	 */
	private static final int LINGER_TIME = 10000;
	/**
	 *
	 */
	private static HttpClient client;
	/**
	 *
	 */
	private static HttpConnectionManager httpConnMgr;
	/**
	 *
	 */
	static {
		init();
	}

	/**
	 * @since liushen @ Jul 23, 2010
	 * @see #get(String, Map)
	 */
	public static Response get(String url) {
		return get(url, null);
	}

	/**
	 * 发送GET请求，并获取响应.
	 * 
	 * @param url
	 *            请求的URL; 不能为空.
	 * @param extraHeaders
	 *            需要定制的HTTP头
	 * @return HTTP响应
	 * @since liushen @ Jul 23, 2010
	 */
	public static Response get(String url, Map<String, String> extraHeaders) {
		return getHttpResponse(url, extraHeaders, null, true);
	}

	/**
	 * 发送POST请求，并获取响应.
	 * 
	 * @param url
	 *            请求的URL; 不能为空.
	 * @param formCharset
	 *            表单请求的字符集. 如不指定(即该参数值为<code>null</code>)，则默认为<code>UTF-8</code>
	 * @param extraHeaders
	 *            其他需要定制的HTTP头
	 * @param postParams
	 *            以POST方式提交的参数集
	 * @return HTTP响应
	 * @since liushen @ Jul 23, 2010
	 */
	public static Response post(String url, String formCharset,
			Map<String, String> extraHeaders, Map<String, String> postParams) {
		PostMethod method = new PostMethod(url);
		formCharset = StringHelper.isEmpty(formCharset) ? "UTF-8" : formCharset;
		method.setRequestHeader("Content-Type",
				"application/x-www-form-urlencoded; charset=" + formCharset);
		NameValuePair[] parametersBody = null;
		if (postParams != null) {
			int size = postParams.size();
			parametersBody = new NameValuePair[size];
			int i = 0;
			for (Iterator iter = postParams.keySet().iterator(); iter.hasNext(); i++) {
				String name = (String) iter.next();
				String value = postParams.get(name);
				NameValuePair valuePair = new NameValuePair();
				parametersBody[i] = valuePair;
				parametersBody[i].setName(name);
				parametersBody[i].setValue(value);
			}
			method.setRequestBody(parametersBody);
		}

		HttpState state = null;
		return getResponseInternal(url, method, extraHeaders, state);
	}

	/**
	 * 内部方法（因为依赖httpclient类库的HttpState对象）.
	 * 
	 * @param url
	 * @param headers
	 * @param state
	 * @param followRedirect
	 * @return
	 * @creator Administrator @ Sep 28, 2009
	 */
	static Response getHttpResponse(String url, Map headers,
			HttpState state, boolean followRedirect) {
		HttpMethod method = new GetMethod(url);
		method.setFollowRedirects(followRedirect);
		return getResponseInternal(url, method, headers, state); // Single
	}

	/**
	 * 单线程方式发送请求, 对虚IP等情况支持较好.
	 * 
	 * @param url
	 * @param method
	 * @param headers
	 * @param state
	 * @return
	 * @since Aug 23, 2007, by TRS
	 */
	static Response getResponseInternal(String url, HttpMethod method,
			Map headers, HttpState state) {
		HttpClient httpClient = buildHttpClient();
		HttpMethodParams params = method.getParams();
		if (params != null) {
			params.setCookiePolicy(CookiePolicy.BROWSER_COMPATIBILITY);
		}

		// 大量CLOSE_WAIT连接: http://dev4.trs.net.cn:8080/browse/TRSIDS-1588
		method.setRequestHeader("Connection", "Close");
		// 加载请求头
		Response res = new Response(url);
		if (headers != null) {
			for (Iterator it = headers.entrySet().iterator(); it.hasNext();) {
				Map.Entry e = (Map.Entry) (it.next());
				method.setRequestHeader((String) e.getKey(), (String) e
						.getValue());
			}
		}
		// 设置状态
		if (state != null) {
			httpClient.setState(state);
		}

		// liushen@Nov 22, 2011: 支持fiddler调试, see
		// http://dev4.trs.net.cn:8080/browse/INFRA-5
		HostConfiguration hostCfg = httpClient.getHostConfiguration();
		String proxyHost = NetUtil.getHttpClientProxyHost();
		int proxyPort = NetUtil.getHttpClientProxyPort();
		if (StringHelper.isNotEmpty(proxyHost) && proxyPort > 0 && proxyPort < 65536) {
			hostCfg = (HostConfiguration) hostCfg.clone();
			hostCfg.setProxy(proxyHost, proxyPort);
		}

		try {
			res.setActualPath(method.getPath());
			int respCode = httpClient.executeMethod(hostCfg, method);
			if (LOG.isDebugEnabled()) {
				LOG.debug("[Request]" + method.getName() + " "
						+ method.getURI() + " [Response]"
						+ method.getStatusLine() + " \n" + hostCfg);
			}
			res.setStatusCode(respCode);
			res.setStatusText(method.getStatusText());

			Header[] respHeaders = method.getResponseHeaders();
			for (int i = 0; i < respHeaders.length; i++) {
				res.addResponseHeader(respHeaders[i].getName(), respHeaders[i]
						.getValue());
			}
			if (res.statusCodeIsFine()) {
				res.setResponseBody(method.getResponseBody());
			} else {
				LOG.warn("respCode=" + respCode + "! url=" + url);
			}
		} catch (Throwable e) {
			// LOG.error("httpClient.executeMethod failed! url=" + url, e); //
			// 会导致大量的无谓日志，因此取消记录
			res.setFail(true);
			res.setError(e);
			res.setStatusCode(CODE_EXCEPTION);
			res.setStatusText(e.getMessage());
		} finally {
			method.releaseConnection();
		}
		return res;
	}

	/**
	 * 多线程方式发送请求, 对虚IP等情况支持待考察.
	 * 
	 * @param url
	 * @param method
	 * @param headers
	 * @param state
	 * @return
	 * @since Aug 23, 2007, by TRS
	 */
	static Response getResponse(String url, HttpMethod method, Map headers,
			HttpState state) {
		Response res = new Response(url);
		if (headers != null) {
			for (Iterator it = headers.entrySet().iterator(); it.hasNext();) {
				Map.Entry e = (Map.Entry) (it.next());
				method.setRequestHeader((String) e.getKey(), (String) e
						.getValue());
			}
		}

		HttpMethodParams params = method.getParams();
		if (params != null) {
			params.setCookiePolicy(CookiePolicy.BROWSER_COMPATIBILITY);
		}

		client.setState((state == null) ? new HttpState() : state);

		try {
			int respCode = client.executeMethod(method);
			res.setStatusCode(respCode);
			res.setStatusText(method.getStatusText());
			res.setActualPath(method.getPath());

			Header[] respHeaders = method.getResponseHeaders();
			for (int i = 0; i < respHeaders.length; i++) {
				res.addResponseHeader(respHeaders[i].getName(), respHeaders[i]
						.getValue());
			}

			if (res.statusCodeIsFine()) {
				res.setResponseBody(method.getResponseBody());
			} else {
				LOG.warn("respCode=" + respCode + "! url=" + url);
			}
		} catch (Throwable e) {
			LOG.error("httpClient.executeMethod failed! url=" + url, e);
			res.setFail(true);
			res.setError(e);
		} finally {
			method.releaseConnection();
		}

		return res;
	}

	/**
	 * 
	 * @param url
	 * @param headers
	 * @return
	 * @creator fangxiang @ Jul 20, 2009
	 * @deprecated liushen@Jul 23, 2010: 参数不应该依赖于httpclient
	 */
	@Deprecated
	static Response headHttpResponse(String url, Map headers,
			HttpState state, NameValuePair[] parametersBody,
			boolean followRedirect) {
		HttpMethod method = new HeadMethod(url);
		method.setFollowRedirects(followRedirect);
		return getResponseInternal(url, method, headers, state);
	}

	private static void init() {
		httpConnMgr = new MultiThreadedHttpConnectionManager();
		if (httpConnMgr != null) {
			HttpConnectionManagerParams mgrParams = buildManagerParams();
			httpConnMgr.setParams(mgrParams);
		}
		client = new HttpClient(httpConnMgr);
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Nov 12, 2010
	 */
	static HttpConnectionManagerParams buildManagerParams() {
		HttpConnectionManagerParams mgrParams = new HttpConnectionManagerParams();
		mgrParams.setSoTimeout(CONN_TIMEOUT);
		mgrParams.setTcpNoDelay(true);
		mgrParams.setConnectionTimeout(CONN_TIMEOUT);
		mgrParams.setLinger(LINGER_TIME);
		mgrParams.setDefaultMaxConnectionsPerHost(10);
		mgrParams.setMaxTotalConnections(15);
		return mgrParams;
	}

	/**
	 * 构造http协议请求的客户端对象
	 * 
	 * @return http协议请求的客户端对象
	 */
	private static HttpClient buildHttpClient() {
		return client;

		// HttpClient httpClient = new HttpClient(httpConnMgr);
		// HttpConnectionManager httpConnManager = httpClient
		// .getHttpConnectionManager();
		// if (httpConnManager != null) {
		// HttpConnectionManagerParams mgrParams = new
		// HttpConnectionManagerParams();
		// mgrParams.setSoTimeout(CONN_TIMEOUT);
		// mgrParams.setTcpNoDelay(true);
		// mgrParams.setConnectionTimeout(CONN_TIMEOUT);
		// mgrParams.setLinger(0);
		// mgrParams.setStaleCheckingEnabled(false);
		// httpConnManager.setParams(mgrParams);
		// }
		// return httpClient;
	}
}
