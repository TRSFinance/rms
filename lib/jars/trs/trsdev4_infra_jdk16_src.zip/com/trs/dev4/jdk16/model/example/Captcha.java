package com.trs.dev4.jdk16.model.example;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.trs.dev4.jdk16.model.BaseEntity;

/**
 * 职责: <br>
 * 问答式验证码
 * 
 * @author dujie
 */
@Entity
@Table(name = "`CAPTCHA`")
@SequenceGenerator(name = "SEQ_CAPTCHA", sequenceName = "SEQ_CAPTCHA")
@GenericGenerator(name = "idStrategy", strategy = "native", parameters = { @Parameter(name = "sequence", value = "SEQ_CAPTCHA") })
public class Captcha extends BaseEntity {

	/**
	 * @since dujie @ 2011-10-12
	 */
	private static final long serialVersionUID = 5664709761531769847L;
	/**
	 * 问题
	 */
	@Column(name = "`QUESTION`")
	private String question;
	/**
	 * 答案
	 */
	@Column(name = "`ANSWER`")
	private String answer;
	/**
	 * 是否包含中文
	 * 
	 * @since TRS信息技术股份有限公司 @ Jun 12, 2012
	 */
	private boolean isChinese;
	/**
	 * @return the id
	 */
	@Override
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	@Override
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the question
	 */
	public String getQuestion() {
		return question;
	}
	/**
	 * @param question the question to set
	 */
	public void setQuestion(String question) {
		this.question = question;
	}
	/**
	 * @return the answer
	 */
	public String getAnswer() {
		return answer;
	}
	/**
	 * @param answer the answer to set
	 */
	public void setAnswer(String answer) {
		this.answer = answer;
	}

	/**
	 * @return the {@link #isChinese}
	 */
	public boolean isChinese() {
		return isChinese;
	}

	/**
	 * @param isChinese the {@link #isChinese} to set
	 */
	public void setChinese(boolean isChinese) {
		this.isChinese = isChinese;
	}
	public Captcha(){
		this.question = "1+1=?";
		this.answer = "2";
		this.isChinese = true;
	}

}
