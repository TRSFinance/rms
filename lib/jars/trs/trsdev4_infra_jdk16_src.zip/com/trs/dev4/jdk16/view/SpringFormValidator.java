/*
 * Created: liushen@Jul 27, 2014 10:25:10 PM
 */
package com.trs.dev4.jdk16.view;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.trs.dev4.jdk16.model.IValidator;
import com.trs.dev4.jdk16.model.ValidationError;
import com.trs.dev4.jdk16.model.ValidationErrors;

/**
 * 通用的Spring Form校验器，适用于 {@link GenericForm}。 <br>
 */
public class SpringFormValidator implements Validator {

	/**
	 * 
	 */
	private IValidator validator;
	private static final Logger LOG = Logger.getLogger(SpringFormValidator.class);

	/**
	 * @see org.springframework.validation.Validator#supports(java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz != null;
	}

	/**
	 * @see org.springframework.validation.Validator#validate(java.lang.Object,
	 *      org.springframework.validation.Errors)
	 */
	@Override
	public void validate(Object target, Errors errors) {
		Object element = null;
		if (target instanceof GenericForm<?>) {
			element = ((GenericForm<?>) target).getElement();
		} else {
			element = target;
		}
		ValidationErrors validationErrors = validator.validate(element);
		if (validationErrors.hasErrors()) {
			LOG.debug(validationErrors);
		}
		for (int i = 0; i < validationErrors.size(); i++) {
			ValidationError error = validationErrors.getError(i);
			String field = error.getField();
			String errorCode = error.getErrorCode();
			String defaultMessage = error.getDefaultMessage();
			Object[] errorArgs = error.getErrorArgs();
			errors.rejectValue(field, errorCode, errorArgs, defaultMessage);
		}
	}

	/**
	 * Get the {@link #validator}.
	 * 
	 * @return the {@link #validator}.
	 */
	public IValidator getValidator() {
		return validator;
	}

	/**
	 * Set the {@link #validator}.
	 * 
	 * @param validator
	 *            the validator to set
	 */
	public void setValidator(IValidator validator) {
		this.validator = validator;
	}

}
