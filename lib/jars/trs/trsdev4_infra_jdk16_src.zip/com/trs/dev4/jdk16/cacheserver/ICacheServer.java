package com.trs.dev4.jdk16.cacheserver;

/**
 * 缓存服务器的接口
 * 
 */
public interface ICacheServer {

	/**
	 * 设置缓存。
	 * 
	 * @param key
	 *            该缓存的索引键
	 * @param expr
	 *            该缓存的有效期；单位为秒
	 * @param value
	 *            要缓存的对象
	 * @since liuyou @ 2010-5-17
	 */
	void set(String key, int expr, Object value);

	/**
	 * 添加缓存。<br>
	 * TODO: liushen@Feb 20, 2012: 
	 * 1)若该对象已被缓存，则该方法不做任何处理？从各实现看，好像不完全一致，待确认
	 * 2)有效期通常为正数。是否允许<code>-1</code>和<code>0</code>两个特殊值以及各自含义？
	 * 3) 不带有效期参数的{@link #add(String, Object)} 方法是否还开放？
	 * 
	 * @param key
	 *            该缓存的索引键
	 * @param expr
	 *            该缓存的有效期；单位为秒
	 * @param value
	 *            要缓存的对象
	 * @since liuyou @ 2010-5-17
	 */
	void add(String key, int expr, Object value);

	/**
	 * 替换缓存<br>
	 * 当不存在该缓存时做替换将不处理
	 * 
	 * @param key
	 *            该缓存的索引键
	 * @param expr
	 *            该缓存的有效期；单位为秒
	 * @param value
	 *            要缓存的对象
	 * @since liuyou @ 2010-5-17
	 */
	void replace(String key, int expr, Object value);

	/**
	 * 删除缓存项
	 * 
	 * @param key
	 *            该缓存的索引键
	 * @since liuyou @ 2010-5-17
	 */
	void delete(String key);

	/**
	 * 获取缓存
	 * 
	 * @param key
	 *            该缓存的索引键
	 * @return 缓存的对象
	 * @since liuyou @ 2010-5-17
	 */
	Object get(String key);

	/**
	 * 设置缓存的值
	 * 
	 * @param key
	 *            键
	 * @param value
	 *            值
	 */
	void set(String key, Object value);

	/**
	 * 添加至缓存
	 * 
	 * @param key
	 *            键
	 * @param value
	 *            值
	 */
	void add(String key, Object value);

	/**
	 * 替换缓存中的值
	 * 
	 * @param key
	 *            键
	 * @param value
	 *            值
	 */
	void replace(String key, Object value);

	/**
	 * 获取缓存中的值
	 * 
	 * @param key
	 *            键
	 * @param defaultVal
	 *            默认值
	 * @return 值
	 */
	Object get(String key, Object defaultVal);

	/**
	 * 清空缓存，远程服务器缓存无效
	 * 
	 * @since TRS @ Feb 13, 2012
	 */
	void clearAll();
}
