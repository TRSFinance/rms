/*
 * Created: fangxiang@Nov 21, 2010 8:10:09 AM
 */
package com.trs.dev4.jdk16.cacheserver;

import java.io.IOException;

import net.rubyeye.xmemcached.utils.AddrUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thimbleware.jmemcached.Cache;
import com.thimbleware.jmemcached.MemCacheDaemon;
import com.thimbleware.jmemcached.storage.hash.LRUCacheStorageDelegate;
import com.trs.dev4.jdk16.model.IModuleLifecycle;

/**
 * 职责: <br>
 *
 */
public class JMemcacheServer implements IModuleLifecycle {
	/**
	 *
	 */
	private final static Logger logger = LoggerFactory
			.getLogger(JMemcacheServer.class);
	/**
	 *
	 */
	MemCacheDaemon daemon = new MemCacheDaemon();

	/**
	 *
	 *
	 * @since fangxiang @ Nov 21, 2010
	 */
	@Override
	public void start() {
		// create daemon and start it
		LRUCacheStorageDelegate cacheStorage = new LRUCacheStorageDelegate(
				2048000, 2048000, 1024000);
		daemon.setCache(new Cache(cacheStorage));
		daemon.setAddr(AddrUtil.getOneAddress("127.0.0.1:12111"));
		daemon.setReceiveBufferSize(1024);
		daemon.setSendBufferSize(1024);
		daemon.setVerbose(true);
		daemon.setBinary(false);
		try {
			daemon.start();
			logger.info("JMemcache Server started successfully@127.0.0.1:12111");
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 *
	 *
	 * @since fangxiang @ Nov 21, 2010
	 */
	@Override
	public void stop() {
		if ( daemon != null ){
			daemon.stop();
			logger.info("JMemcache Server stop successfully.");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#getModuleName()
	 * @since fangxiang @ Nov 22, 2010
	 */
	@Override
	public String getModuleName() {
		return "JMemcacheServer";
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#restart()
	 * @since fangxiang @ Nov 22, 2010
	 */
	@Override
	public void restart() {

	}
}
