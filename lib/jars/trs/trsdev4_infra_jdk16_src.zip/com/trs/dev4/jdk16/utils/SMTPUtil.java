/*
 * Title:     TRS 身份服务器
 * Copyright: Copyright (c) 2004-2005, TRS信息技术有限公司. All rights reserved.
 * License:   see the license file.
 * Company:   TRS信息技术有限公司(www.trs.com.cn)
 *
 * Created on 2005-3-5, by liushen
 */
package com.trs.dev4.jdk16.utils;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.exception.MailException;

/**
 * 邮件客户端工具类. <BR>
 * 
 * @author TRS信息技术有限公司
 * @version 1.0
 */
public class SMTPUtil {

    private static final Logger logger = Logger.getLogger(SMTPUtil.class);

	/**
	 * 发送简单的邮件(不包含附件的邮件).
	 * 
	 * @param smtpServer
	 *            发件人使用的邮件服务器主机或IP
	 * @param from
	 *            发件人地址
	 * @param to
	 *            收件人地址
	 * @param usr
	 *            认证用户名, 对发送邮件时进行验证的邮件服务器需要使用此参数, 否则置为null.
	 * @param pwd
	 *            发件人密码, 对发送邮件时进行验证的邮件服务器需要使用此参数, 否则置为null.
	 * @param subject
	 *            邮件主题
	 * @param msgBody
	 *            邮件正文
	 * @throws MailException
	 *             发送失败抛出
	 */
    public static void sendMail(String smtpServer, String from, String to,
            String usr, String pwd, String subject, String msgBody) {
        Properties prop = new Properties();
        prop.put("mail.smtp.host", smtpServer);
        if (pwd != null && pwd.trim().length() > 0) {
            prop.put("mail.smtp.auth", "true");
        }
        Session session = Session.getInstance(prop, null);
        MimeMessage message = new MimeMessage(session);
        try {
            message.setHeader("Content-Transfer-Encoding", "base64");  // liushen@2005-06-17
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(
                    to));
            message.setSubject(subject);
            message.setText(msgBody);
            if (pwd != null && pwd.trim().length() > 0) {
                Transport transport = session.getTransport("smtp");
                transport.connect(smtpServer, usr, pwd);
                transport.sendMessage(message, message.getAllRecipients());
                transport.close();
            } else {
                Transport.send(message);
            }
        } catch (Exception e) {
            logger.error("(smtpHost, props)=" + smtpServer + ", " + session.getProperties() + "; (from, to, usr, pwd)=" + from + ", " + to + ", " + usr + ", " + pwd, e);
			throw new MailException("邮件发送失败!", e);
        }
    }

	/**
	 * 验证邮件地址是否符合格式规范
	 * 
	 * @param email
	 *            邮件地址
	 * @return true表示符合邮件地址规范，false表示不符合邮件地址规范
	 * @since fangxiang @ Apr 14, 2010
	 */
    public static boolean isValidEMailAddress(String email) {
        if (email == null) {
            return false;
        }

        if (email.indexOf('@') < 1) {
            return false;
        }

        try {
            new InternetAddress(email);

            return true;
        } catch (AddressException e) {
            return false;
        }
    }

}