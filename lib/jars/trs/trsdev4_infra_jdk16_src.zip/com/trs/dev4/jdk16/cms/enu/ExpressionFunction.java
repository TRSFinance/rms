/*
 * Created: yangyu@Jun 5, 2013 2:16:45 PM
 */
package com.trs.dev4.jdk16.cms.enu;

import java.lang.reflect.Field;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.util.ReflectionUtils;

import com.trs.dev4.jdk16.cms.CurrentUsernameExtractor;
import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.TagAware;
import com.trs.dev4.jdk16.cms.bo.ExpressionResult;
import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.RequestWrapper;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.bo.ValidateContext;
import com.trs.dev4.jdk16.cms.exp.ParentObjNotFoundException;
import com.trs.dev4.jdk16.cms.exp.RequestParameterNotFoundException;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.cms.util.ReflectHelper;

/**
 * 定义置标表达式的所有函数
 * 
 * 使用方式：
 * 
 * 根据传入的属性判断，通过ExpressionType获得不带类型的字符串noTypeValue（如‘param.id’为param.id）； 根据noTypeValue根据前缀，获得所使用的ExpressionFunction函数 ；
 * 调用ExpressionFunction函数的getFunctionedResult方法获取解析的值。
 * 
 */
public enum ExpressionFunction {
	
	PARAM {

		@Override
		public ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType,
				String functionParam) {
			GeneratorSession generatorSession = tagContext.getGeneratorSession();
			RequestWrapper requestWrapper = generatorSession.getRequestWrapper();
			String functionedValue = requestWrapper.getParameter(functionParam);
			if (StringUtils.isEmpty(functionedValue)) {
				throw new RequestParameterNotFoundException("不存在的URL请求参数" + functionParam, tagContext);
			}
			return ExpressionType.packingStringValueToResult(expressionType, functionedValue);
		}

	},
	PARAMINTARRAY {

		@Override
		public ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType,
				String functionParam) {
			RequestWrapper requestWrapper = tagContext.getGeneratorSession().getRequestWrapper();
			int[] intValues = requestWrapper.getParameterAsIntArray(functionParam);
			if (ArrayUtils.isEmpty(intValues)) {
				throw new RequestParameterNotFoundException("不存在的URL请求参数" + functionParam, tagContext);
			}
			return new ExpressionResult(ExpressionType.ARRAYINT, intValues);
		}

	},
	PARENT {

		/**
		 * 校验父OBJ是否有这个属性
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionFunction#validate(java.lang.String)
		 * @since yangyu @ Jun 5, 2013
		 */
		@Override
		public void validate(ValidateContext validateContext, ExpressionType expressionType, String value) {
			String param = this.getFunctionParam(value);
			String objValue = "";
			try {
				objValue = validateContext.getParentObjValue();
			} catch (ParentObjNotFoundException e) {
				validateContext.addError("函数parent找不到可用的数据源，即外层标签没有obj属性");
			}
			
			TagAware<?> tagAware = validateContext.getSettings().getTagAware(objValue);
			if (tagAware != null) {
				try {
					ReflectHelper.getField(tagAware.getTagClass(), param);
					Field field = ReflectionUtils.findField(tagAware.getTagClass(), param);
					if(expressionType.equals(ExpressionType.INT)){
						if (field.getType() != Integer.class) {
							validateContext.addError("置标表达式不符合INTFunction表达式要求，置标表达式解析后的值不是INT类型");
						}
					}

				} catch (Exception e) {
					if (!ArrayUtils.contains(tagAware.specialTagAttribute(), param)) {
						validateContext.addError("置标表达式函数定义不正确，parent函数的属性不存在");
						return;
					}
					// TODO 额外属性没有校验
				}

			}
		}

		@Override
		public ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType,
				String functionParam) {
			PublishObject  publishObject  = tagContext.getEntity();
			if (publishObject == null) {
				throw new TemplateException("不存在parent对象");
			}
			
			Object objValue = publishObject.getProperty(tagContext, functionParam);
			if (objValue == null) {
				throw new TemplateException("不存在的parent属性，当前parent的属性为" + publishObject);
			}
			return new ExpressionResult(objValue);
		}
		
	},
	PARENTINTARRAY {

		@Override
		protected ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType,
				String functionParam) {
			PublishObject publishObject = tagContext.getEntity();
			if (publishObject == null) {
				throw new TemplateException("不存在parent对象");
			}

			Object objValue = publishObject.getProperty(tagContext, functionParam);
			if (objValue == null) {
				throw new TemplateException("不存在的parent属性，当前parent的属性为" + publishObject);
			}
			
			if (objValue.getClass() != String.class) {
				throw new TemplateException("parentIntArray不支持当前属性的类型,只支持String类型的属性");
			}
			
			String stringValue = (String) objValue;
			int[] ints = null;
			if (stringValue.contains(",")) {
				ints = separateToIntArray(stringValue, ",");
			} else if (stringValue.contains("/")) {
				ints = separateToIntArray(stringValue, "/");
			}
			
			return new ExpressionResult(ExpressionType.ARRAYINT, ints);
		}

		/**
		 * @param stringValue
		 * @param string
		 * @return
		 * @since Administrator @ 2013-11-14
		 */
		private int[] separateToIntArray(String stringValue, String spot) {
			int[] ints;
			String[] strings = StringUtils.split(stringValue, spot);
			ints = new int[strings.length];
			for (int i = 0; i < strings.length; i++) {
				try {
					ints[i] = Integer.parseInt(strings[i]);
				} catch (NumberFormatException e) {
					throw new TemplateException("parentIntArray不支持当前属性,属性的值存在非数字类型");
				}
			}
			return ints;
		}

	},
	CURRENTUSER {

		/**
		 * 校验固定的几个值
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionFunction#validate(java.lang.String)
		 * @since yangyu @ Jun 5, 2013
		 */
		@Override
		public void validate(ValidateContext validateContext, ExpressionType expressionType, String noTypeValue) {

			if (!noTypeValue.equalsIgnoreCase("currentUser.name")) {
				validateContext.addError("置标表达式函数CURRENTUSER函数值不正确，当前为" + noTypeValue + ",可选值为【currentUser.name】");
			}

		}

		@Override
		public ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType,
				String functionParam) {
			if (!"name".equalsIgnoreCase(functionParam)) {
				throw new TemplateException("currentUser的属性不存在，只支持currentUser.name获取获取当前用户名", tagContext);
			}
			GeneratorSession generatorSession = tagContext.getGeneratorSession();
			CurrentUsernameExtractor currentUsernameExtractor = generatorSession.getSettings().getCurrentUsernameExtractor();
			String username = currentUsernameExtractor.getCurrentUsername(generatorSession.getRequestWrapper().getRequest());
			return new ExpressionResult(ExpressionType.STRING, username);
		}
		
	},
	ENUMVALUE {

		/**
		 * 不校验
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionFunction#validate(java.lang.String)
		 * @since yangyu @ Jun 5, 2013
		 */
		@SuppressWarnings("unchecked")
		@Override
		public void validate(ValidateContext validateContext, ExpressionType expressionType, String noTypeValue) {

			String functionParam = this.getFunctionParam(noTypeValue);

			String attributeName = StringUtils.substring(functionParam, 0, StringUtils.indexOf(functionParam, "_"));
			String enumName = StringUtils.substring(functionParam, StringUtils.indexOf(functionParam, "_") + 1);

			String obj = validateContext.getObjValue();

			TagAware<?> tagAware = validateContext.getSettings().getTagAware(obj);
			if(tagAware!=null){
				Class<?> enumClass;
				try {
					enumClass = tagAware.getTagClass().getDeclaredField(attributeName).getType();
					Enum.valueOf((Class<Enum>) enumClass, enumName);
				} catch (NoSuchFieldException e) {
					validateContext.addError("ENUMVALUE表达式函数不正确，不存在的枚举类型的类属性" + attributeName);
				} catch (SecurityException e) {
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					validateContext.addError("ENUMVALUE表达式函数不正确，不存在的枚举属性" + enumName);
				}
			}

		}

		/**
		 * enumValue.type_COMMON
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionFunctionDefination#getFunctionedResult(com.trs.dev4.jdk16.cms.bo.TagContext,
		 *      com.trs.dev4.jdk16.cms.enu.expressionType, java.lang.String)
		 * @since yangyu @ Jun 6, 2013
		 */
		@SuppressWarnings("unchecked")
		@Override
		public ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType,
				String functionParam) {
			
			String attributeName = StringUtils.substring(functionParam, 0, StringUtils.indexOf(functionParam, "_"));
			String enumName = StringUtils.substring(functionParam, StringUtils.indexOf(functionParam, "_") + 1);
			PublishObject publishObject = tagContext.getEntity();
			Object enumObject = null;
			try {
				if (publishObject == null) {
					TagAware<?> tagAware = tagContext.getTagAware("obj");
					Class<?> enumClass = tagAware.getTagClass().getDeclaredField(attributeName).getType();
					enumObject = Enum.valueOf((Class<Enum>) enumClass, enumName);
				} else {
					Object object = publishObject.getProperty(tagContext, attributeName);
					enumObject = Enum.valueOf((Class<Enum>) (object.getClass()), attributeName);
				}
				return new ExpressionResult(enumObject);
			} catch (IllegalArgumentException e) {
				throw new TemplateException("不存在的枚举值，当前值为" + functionParam, tagContext);
			} catch (NoSuchFieldException e) {
				throw new TemplateException("不存在的枚举属性，当前值为" + functionParam, tagContext);
			}
		}

	},
	REQUEST {

		/**
		 * 校验固定的几个值
		 * 
		 * @see com.trs.dev4.jdk16.cms.enu.ExpressionFunction#validate(java.lang.String)
		 * @since yangyu @ Jun 5, 2013
		 */
		@Override
		public void validate(ValidateContext validateContext, ExpressionType expressionType, String noTypeValue) {
			if (!noTypeValue.equalsIgnoreCase("request.fromIOS") && !noTypeValue.equalsIgnoreCase("request.contentRoot")) {
				validateContext.addError("置标表达式函数REQUEST函数值不正确，当前为" + noTypeValue
						+ ",可选值为【request.fromIOS,request.contentRoot】");
			}
		}

		@Override
		public ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType,
				String functionParam) {
			RequestWrapper requestWrapper = tagContext.getGeneratorSession().getRequestWrapper();
			if (functionParam.equalsIgnoreCase("fromIOS")) {
				return new ExpressionResult(ExpressionType.BOOLEAN, requestWrapper.fromIOS());
			} else if (functionParam.equalsIgnoreCase("contentRoot")) {
				return new ExpressionResult(ExpressionType.STRING, requestWrapper.getContextUrl());
			}
			throw new TemplateException("不存在的Request函数的参数值");
		}

	},
	COOKIE {

		@Override
		public ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType,
				String functionParam) {
			RequestWrapper requestWrapper = tagContext.getGeneratorSession().getRequestWrapper();
			String cookieValue = requestWrapper.getCookie(functionParam);
			if (StringUtils.isEmpty(cookieValue)) {
				cookieValue = "";
			}
			return new ExpressionResult(ExpressionType.STRING, cookieValue);
		}

	},

	PAGELET {

		@Override
		public ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType,
				String functionParam) {
			String functionedValue = tagContext.getPageletValue(functionParam);
			if (StringUtils.isEmpty(functionedValue)) {
				throw new TemplateException("不存在的Pagelet函数值");
			}
			return ExpressionType.packingStringValueToResult(expressionType, functionedValue);
		}
		
	},
	
	NOFUNCTION {
		@Override
		public String getFunctionParam(String noTypeValue) {
			return noTypeValue;
		}
		
		@Override
		public ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType,
				String functionParam) {
			return ExpressionType.packingStringValueToResult(expressionType, functionParam);
		}

		@Override
		public void validate(ValidateContext validateContext, ExpressionType expressionType, String noTypeValue) {
			if (expressionType.equals(ExpressionType.INT)) {
				if (!StringUtils.isNumeric(noTypeValue)) {
					validateContext.addError("置标表达式不符合INTFunction表达式要求，置标表达式解析后的值不是INT类型");
				}
			}
		}
		
	};

	/**
	 * @param noTypeValue
	 * @return
	 * @since yangyu @ Jun 5, 2013
	 */
	public static ExpressionFunction resolveFunction(String noTypeValue) {
		
		if (noTypeValue.startsWith("param.")) {
			return ExpressionFunction.PARAM;
		}
		if (noTypeValue.startsWith("parent.")) {
			return ExpressionFunction.PARENT;
		}
		if (noTypeValue.startsWith("currentUser.")) {
			return ExpressionFunction.CURRENTUSER;
		}
		if (noTypeValue.startsWith("parentIntArray.")) {
			return ExpressionFunction.PARENTINTARRAY;
		}
		if (noTypeValue.startsWith("pagelet.")) {
			return ExpressionFunction.PAGELET;
		}
		if (noTypeValue.startsWith("enumValue.")) {
			return ExpressionFunction.ENUMVALUE;
		}
		if (noTypeValue.startsWith("paramIntArray.")) {
			return ExpressionFunction.PARAMINTARRAY;
		}
		if (noTypeValue.startsWith("cookie.")) {
			return ExpressionFunction.COOKIE;
		}
		if (noTypeValue.startsWith("request.")) {
			return ExpressionFunction.REQUEST;
		}

		return ExpressionFunction.NOFUNCTION;
	}

	/**
	 * @param validateContext
	 * @param noTypeValue
	 * @since yangyu @ Jun 5, 2013
	 */
	public void validate(ValidateContext validateContext, ExpressionType expressionType, String noTypeValue) {

	}

	/**
	 * 获取函数的参数
	 * 
	 * @param noTypeValue
	 * @return
	 * @since yangyu @ Jun 6, 2013
	 */
	public String getFunctionParam(String noTypeValue) {
		return StringUtils.substring(noTypeValue, StringUtils.indexOf(noTypeValue, ".") + 1);
	}

	/**
	 * @param tagContext
	 * @param functionParam
	 * @since yangyu @ Jun 6, 2013
	 */
	protected abstract ExpressionResult getFunctionedResult(TagContext tagContext, ExpressionType expressionType, String functionParam);

	/**
	 * 解析函数
	 * 
	 * @param tagContext
	 *            上下文
	 * @param expressionType
	 * @param attribute
	 * @return
	 * @since yangyu @ Jun 7, 2013
	 */
	public ExpressionResult resolveValue(TagContext tagContext, ExpressionType expressionType, String attribute) {
		String functionParam = this.getFunctionParam(attribute);
		return this.getFunctionedResult(tagContext, expressionType, functionParam);
	}

}
