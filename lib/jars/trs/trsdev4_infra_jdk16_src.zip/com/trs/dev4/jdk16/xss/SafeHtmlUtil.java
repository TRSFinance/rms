/*
 * created by liushen, 2007.02, for xinhua blog.
 */
package com.trs.dev4.jdk16.xss;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.utils.UrlUtil;

/**
 * 用正则表达式过滤html文本的工具类.
 */
public class SafeHtmlUtil {
	
	private static final Pattern pat1ScriptTag;
	private static final Pattern pat2ScriptTag;
	private static final Pattern pat3ScriptTag;
	private static final Pattern pat4ScriptTag;
	private static final Pattern patQuotationTag;
	private static final Pattern patMarksTag;// 对换行符进行过滤处理
//	private static final Pattern patIframeTag;
	private static final Pattern pat1IframeTag;
	private static final Pattern pat2IframeTag;
	private static final Pattern pat3IframeTag;
	private static final Pattern patJSProtocol;
	private static final Pattern patEventCode;

	/**
	 * 在 {@link #getSafeHtml(String)} 的基础上，对其他类型的对象封装一个便于调用的方法，免去转为 <code>String</code>
	 * 的麻烦并避免可能出现NPE的情况.
	 * 
	 * @see #getSafeHtml(String)
	 */
	public static String getSafeHtml(Object obj) {
		if (obj == null) {
			return "";
		}
	
		return getSafeHtml(obj.toString());
	}

	/**
	 * 获取用正则表达式过滤后的安全html文本. 该方法包含以下处理: <li>去除script标记的内容 <li>去除iframe标记的内容 <li>
	 * 将javascript:替换为java-script: <li>将onXXX替换为on-xxx:
	 * 
	 * @param text
	 *            需要过滤的安全html文本. 如果该参数为null或空串, 则仍返回该参数.
	 */
	public static String getSafeHtml(String text) {
		String textByFilter = text;
		if (StringHelper.isEmpty(text)) {
			return text;
		}
		//		if (text.indexOf("%") >= 0) {
		//			textByFilter = UrlUtil.decode(text, "ISO8859-1");
		//			safeHtml.setStringAfterXSSFilter(textByFilter);
		//		} else {
		//			safeHtml.setStringAfterXSSFilter(text);
		//		}
		if (text.indexOf("%") >= 0) {
			textByFilter = UrlUtil.decode(textByFilter);
			//			safeHtml.setStringAfterXSSFilter(text1);
		} else {
			//			safeHtml.setStringAfterXSSFilter(text);
		}
		//		safeHtml = removeScriptTag(safeHtml);
		//		safeHtml = removeIframeTag(safeHtml);
		//		safeHtml = replaceEventCode(safeHtml);
		//		safeHtml = replaceJS(safeHtml);
		//		safeHtml = replaceQuotation(safeHtml);
		//		safeHtml = replaceMarks(safeHtml);
		textByFilter = removeScriptTag(textByFilter);
		textByFilter = removeIframeTag(textByFilter);
		textByFilter = replaceEventCode(textByFilter);
		textByFilter = replaceJS(textByFilter);
		textByFilter = replaceQuotation(textByFilter);
		textByFilter = replaceMarks(textByFilter);
		if (text.equals(UrlUtil.encode(textByFilter))) {
			return text;
		}
		return textByFilter;
	}

	static String removeScriptTag(String text) {
		String replacementStr = "";
		Matcher matcher = pat1ScriptTag.matcher(text);

		String result = matcher.replaceAll(replacementStr);

		matcher = pat2ScriptTag.matcher(result);
		result = matcher.replaceAll(replacementStr);

		matcher = pat3ScriptTag.matcher(result);
		result = matcher.replaceAll(replacementStr);

		matcher = pat4ScriptTag.matcher(result);
		result = matcher.replaceAll(replacementStr);
		return result;
	}

	static String removeIframeTag(String text) {
		String replacementStr = "";

		Matcher matcher = pat1IframeTag.matcher(text);
		text = matcher.replaceAll(replacementStr);

		matcher = pat2IframeTag.matcher(text);
		text = matcher.replaceAll(replacementStr);

		matcher = pat3IframeTag.matcher(text);
		return matcher.replaceAll(replacementStr);
	}

	static String replaceEventCode(String text) {
		String replacementStr = "$1on-$2=";
		Matcher matcher = patEventCode.matcher(text);
		return matcher.replaceAll(replacementStr);
	}

	static String replaceJS(String text) {
		String replacementStr = "=$2java-script:";
		Matcher matcher = patJSProtocol.matcher(text);
		return matcher.replaceAll(replacementStr);
	}

	/**
	 * 瀵瑰紩鍙疯繘琛岃繃婊わ紝鍖呮嫭鍗曞紩鍙峰拰鍙屽紩鍙�
	 **/
	static String replaceQuotation(String text) {
		String replacementStr = "";
		Matcher matcher = patQuotationTag.matcher(text);
		return matcher.replaceAll(replacementStr);
	}

	//	static SafeHtmlObject removeScriptTag(SafeHtmlObject safeHtmlObj) {
	// // safeHtmlObject.setXSSFiltered(false); 默认就应该是false
	//		String replacementStr = "";
	//		String result = filterXSS(pat1ScriptTag, safeHtmlObj, replacementStr);
	//
	//		result = filterXSS(pat2ScriptTag, safeHtmlObj, replacementStr);
	//		result = filterXSS(pat3ScriptTag, safeHtmlObj, replacementStr);
	//		result = filterXSS(pat4ScriptTag, safeHtmlObj, replacementStr);
	//		safeHtmlObj.setStringAfterXSSFilter(result);
	//		return safeHtmlObj;
	//	}
	//
	//	/**
	//	 * @param text
	//	 * @param safeHtmlObject
	//	 * @param replacementStr
	//	 * @return
	//	 * @since congli @ 2014-3-18
	//	 */
	//	private static String filterXSS(Pattern pat, SafeHtmlObject safeHtmlObj,
	//			String replacementStr) {
	//		Matcher matcher = pat.matcher(safeHtmlObj.getStringAfterXSSFilter());
	//		if (matcher.find()) {
	//			safeHtmlObj.setXSSFiltered(true);
	//		}
	//        String result = matcher.replaceAll(replacementStr);
	//		safeHtmlObj.setStringAfterXSSFilter(result);
	//		return result;
	//	}
	//	
	//	static SafeHtmlObject removeIframeTag(SafeHtmlObject safeHtmlObj) {
	//		String replacementStr = "";
	//		String text = filterXSS(pat1IframeTag, safeHtmlObj, replacementStr);
	//		text = filterXSS(pat2IframeTag, safeHtmlObj, replacementStr);
	//		text = filterXSS(pat2IframeTag, safeHtmlObj, replacementStr);
	//		text = filterXSS(pat3IframeTag, safeHtmlObj, replacementStr);
	//		safeHtmlObj.setStringAfterXSSFilter(text);
	//		return safeHtmlObj;
	//	}
	//	
	//	static SafeHtmlObject replaceEventCode(SafeHtmlObject safeHtmlObj) {
	//		String replacementStr = "$1on-$2=";
	//		String text = filterXSS(patEventCode, safeHtmlObj, replacementStr);
	//		safeHtmlObj.setStringAfterXSSFilter(text);
	//		return safeHtmlObj;
	//	}
	//	
	//	static SafeHtmlObject replaceJS(SafeHtmlObject safeHtmlObj) {
	//		String replacementStr = "=$2java-script:";
	//		String text = filterXSS(patJSProtocol, safeHtmlObj, replacementStr);
	//		safeHtmlObj.setStringAfterXSSFilter(text);
	//		return safeHtmlObj;
	//	}
	//
	//	/**
	// * 对引号进行过滤，包括单引号和双引号
	//	 **/
	//	static SafeHtmlObject replaceQuotation(SafeHtmlObject safeHtmlObj) {
	//		String replacementStr = "";
	//		String text = filterXSS(patQuotationTag, safeHtmlObj, replacementStr);
	//		safeHtmlObj.setStringAfterXSSFilter(text);
	//		return safeHtmlObj;
	//	}

	static String replaceMarks(String text) {
		String replacementStr = "";
		Matcher matcher = patMarksTag.matcher(text);

		String result = matcher.replaceAll(replacementStr);

		return result;
	}

	static {

		// ls@07-0528 Note: pat1, 2, 3顺序不能反!
		pat1ScriptTag = Pattern.compile("<%?.*script\\s*[^>]*>.*</script>", Pattern.MULTILINE | Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
		pat2ScriptTag = Pattern.compile("<%?.*script\\s*[^>]*/>", Pattern.MULTILINE | Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
		pat3ScriptTag = Pattern.compile("<%?.*script\\s*[^>]*>",
				Pattern.MULTILINE | Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
		pat4ScriptTag = Pattern
				.compile(
						"<a.+|<img.+>|<|>|`|--|\".+=.+|\"\\);.+|\\(.+\\)|='.+|\\'%.+|\"%.+|=\\s*\".+|\\'\\+.+|\\';.+|\"\\+.+|<STYLE>.+|href=.+|\";.+",
				Pattern.MULTILINE
				| Pattern.CASE_INSENSITIVE
				| Pattern.DOTALL);
		patQuotationTag = Pattern.compile("\\'|\\\""); // by shenhaiwen
		patMarksTag = Pattern.compile("\\\n|\\r"); // 对换行符进行处理 by shenhaiwen
		pat1IframeTag = Pattern.compile("<iframe\\s*[^>]*>.*</iframe>", Pattern.MULTILINE | Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
		pat2IframeTag = Pattern.compile("<iframe\\s*[^>]*/>", Pattern.MULTILINE | Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
		pat3IframeTag = Pattern.compile("<iframe\\s*[^>]*>*", Pattern.MULTILINE | Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

		patJSProtocol = Pattern.compile("=(\\s)*(\\'|\\\")?(\\s)*javascript:", Pattern.MULTILINE | Pattern.CASE_INSENSITIVE);
		patEventCode = Pattern.compile("(\\s)on([a-zA-Z]+)\\s*=", Pattern.MULTILINE | Pattern.CASE_INSENSITIVE);

		/*
		// ls@07-0528 (x\y)* may cause StackOverFlowError. see http://madbean.com/2004/mb2004-20/ and http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=5050507
		// patScriptTag = Pattern.compile("<script\\s*(.|\\s)*(/>|>(.|\\s)*</script>)", Pattern.MULTILINE | Pattern.CASE_INSENSITIVE);
		// patIframeTag = Pattern.compile("<iframe\\s*(.|\\s)*(/>|>(.|\\s)*</iframe>)", Pattern.MULTILINE | Pattern.CASE_INSENSITIVE);
    	*/
	}

}
