/*
 * Created: liushen@Nov 30, 2012 4:22:18 PM
 */
package com.trs.dev4.jdk16.exec;

/**
 * 和 {@link ProcessThread} 配合，监听由 {@link ProcessHelper} 启动的进程的退出。 <br>
 * 
 */
public interface IProcessTerminatedListener {

	/**
	 * 被监听的进程退出后，触发此事件。
	 * 
	 * @param processHelper
	 *            已经执行完进程的 {@link ProcessHelper}.
	 * @since liushen @ Nov 30, 2012
	 */
	void afterExited(ProcessHelper processHelper);

}
