/*
 * Created: liushen@May 31, 2009 3:21:28 PM
 */
package com.trs.dev4.jdk16.dao;

/**
 * 通用的数据库状态概要.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class DBSummary {

	/**
	 * 数据库名称.
	 */
	private String dbProductName;

	/**
	 * 数据库版本.
	 */
	private String dbProductVersion;

	/**
	 * JDBC驱动名称.
	 */
	private String jdbcDriverName;
	/**
	 * JDBC驱动类名.
	 */
	private String jdbcDriverClassName;
	/**
	 * JDBC驱动版本.
	 */
	private String jdbcDriverVersion;
	/**
	 * JDBC驱动版本详细信息.
	 */
	private String jdbcDriverVersionDetail;
	/**
	 * 该驱动实现的JDBC规范版本.
	 */
	private String jdbcVersion;
	/**
	 * 连接数据库的URL.
	 */
	private String jdbcUrl;
	/**
	 * 连接数据库的帐号(用户).
	 */
	private String jdbcUser;

	/**
	 * 连接数据库帐号的密码.
	 */
	private String jdbcPassword;

	/**
	 * 从数据库元数据中返回的当前用户名; 可能形式上和连接指定的有所不同，比如MySQL用root连接可能会返回root@localhost.
	 */
	private String userFromDBMeta;

	/**
	 * 从数据库元数据中返回的JDBC URL.
	 */
	private String urlFromDBMeta;

	/**
	 * 该数据库的关键字.
	 */
	private String sqlKeywords;

	/**
	 * 所使用的hibernate数据库方言.
	 */
	private String hibernateDialect;

	/**
	 * Returns the {@link #dbProductVersion}.
	 * 
	 * @return the dbProductVersion.
	 */
	public String getDbProductVersion() {
		return dbProductVersion;
	}

	/**
	 * Returns the {@link #dbProductName}.
	 * 
	 * @return the dbProductName.
	 */
	public String getDbProductName() {
		return dbProductName;
	}

	/**
	 * 数据库软件是否为MS SQL Server.
	 * 
	 * @since liushen @ Apr 21, 2011
	 */
	public boolean isSQLServer() {
		return dbProductName.toLowerCase().indexOf("sql server") != -1;
	}

	/**
	 * 数据库软件是否为MySQL.
	 * 
	 * @since liushen @ Apr 21, 2011
	 */
	public boolean isMySQL() {
		return dbProductName.toLowerCase().indexOf("mysql") != -1;
	}

	/**
	 * 数据库软件是否为Oracle.
	 * 
	 * @since liushen @ Apr 21, 2011
	 */
	public boolean isOracle() {
		return dbProductName.toLowerCase().indexOf("oracle") != -1;
	}

	/**
	 * Returns the {@link #jdbcDriverVersion}.
	 * 
	 * @return the jdbcDriverVersion.
	 */
	public String getJdbcDriverVersion() {
		return jdbcDriverVersion;
	}

	/**
	 * Returns the {@link #jdbcVersion}.
	 * 
	 * @return the jdbcVersion.
	 */
	public String getJdbcVersion() {
		return jdbcVersion;
	}

	/**
	 * Returns the {@link #jdbcDriverClassName}.
	 * 
	 * @return the jdbcDriverClassName.
	 */
	public String getJdbcDriverClassName() {
		return jdbcDriverClassName;
	}

	/**
	 * Returns the {@link #jdbcDriverName}.
	 * 
	 * @return the jdbcDriverName.
	 */
	public String getJdbcDriverName() {
		return jdbcDriverName;
	}

	/**
	 * Returns the {@link #jdbcDriverVersionDetail}.
	 * 
	 * @return the jdbcDriverVersionDetail.
	 */
	public String getJdbcDriverVersionDetail() {
		return jdbcDriverVersionDetail;
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Sep 7, 2011
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder(256);
		sb.append(super.toString());
		sb.append("[dbProductName]").append(dbProductName);
		sb.append("[dbProductVersion]").append(dbProductVersion);
		sb.append("[jdbcDriverClassName]").append(jdbcDriverClassName);
		sb.append("[jdbcDriverVersion]").append(jdbcDriverVersion);
		sb.append("[jdbcDriverVersionDetail]").append(jdbcDriverVersionDetail);
		sb.append("[jdbcVersion]").append(jdbcVersion);
		sb.append("[jdbcURL]").append(jdbcUrl);
		sb.append("[jdbcUser]").append(jdbcUser);
		sb.append("[jdbcURLFromDBMeta]").append(urlFromDBMeta);
		sb.append("[jdbcUserFromDBMeta]").append(userFromDBMeta);
		return sb.toString();
	}

	/**
	 * Returns the {@link #jdbcUrl}.
	 * 
	 * @return the jdbcURL.
	 */
	public String getJdbcUrl() {
		return jdbcUrl;
	}

	/**
	 * Returns the {@link #jdbcUser}.
	 * 
	 * @return the jdbcUser.
	 */
	public String getJdbcUser() {
		return jdbcUser;
	}

	/**
	 * @return
	 * @since liushen @ Jun 23, 2011
	 */
	public String getJdbcPassword() {
		return jdbcPassword;
	}

	/**
	 * Returns the {@link #hibernateDialect}.
	 * 
	 * @return the dialect.
	 */
	public String getHibernateDialect() {
		return hibernateDialect;
	}

	/**
	 * Get the {@link #sqlKeywords}.
	 * 
	 * @return the {@link #sqlKeywords}.
	 */
	public String getSqlKeywords() {
		return sqlKeywords;
	}

	/**
	 * Set {@link #hibernateDialect}.
	 * 
	 * @param dialect
	 *            The dialect to set.
	 */
	void setHibernateDialect(String dialect) {
		this.hibernateDialect = dialect;
	}

	/**
	 * Set the {@link #dbProductName}.
	 * 
	 * @param dbProductName
	 *            the dbProductName to set
	 */
	void setDbProductName(String dbProductName) {
		this.dbProductName = dbProductName;
	}

	/**
	 * Set the {@link #dbProductVersion}.
	 * 
	 * @param dbProductVersion
	 *            the dbProductVersion to set
	 */
	void setDbProductVersion(String dbProductVersion) {
		this.dbProductVersion = dbProductVersion;
	}

	/**
	 * Set the {@link #jdbcDriverName}.
	 * 
	 * @param jdbcDriverName
	 *            the jdbcDriverName to set
	 */
	void setJdbcDriverName(String jdbcDriverName) {
		this.jdbcDriverName = jdbcDriverName;
	}

	/**
	 * Set the {@link #jdbcDriverClassName}.
	 * 
	 * @param jdbcDriverClassName
	 *            the jdbcDriverClassName to set
	 */
	void setJdbcDriverClassName(String jdbcDriverClassName) {
		this.jdbcDriverClassName = jdbcDriverClassName;
	}

	/**
	 * Set the {@link #jdbcDriverVersion}.
	 * 
	 * @param jdbcDriverVersion
	 *            the jdbcDriverVersion to set
	 */
	void setJdbcDriverVersion(String jdbcDriverVersion) {
		this.jdbcDriverVersion = jdbcDriverVersion;
	}

	/**
	 * Set the {@link #jdbcDriverVersionDetail}.
	 * 
	 * @param jdbcDriverVersionDetail
	 *            the jdbcDriverVersionDetail to set
	 */
	void setJdbcDriverVersionDetail(String jdbcDriverVersionDetail) {
		this.jdbcDriverVersionDetail = jdbcDriverVersionDetail;
	}

	/**
	 * Set the {@link #jdbcVersion}.
	 * 
	 * @param jdbcVersion
	 *            the jdbcVersion to set
	 */
	void setJdbcVersion(String jdbcVersion) {
		this.jdbcVersion = jdbcVersion;
	}

	/**
	 * Set the {@link #jdbcUrl}.
	 * 
	 * @param jdbcUrl
	 *            the jdbcUrl to set
	 */
	void setJdbcUrl(String jdbcUrl) {
		this.jdbcUrl = jdbcUrl;
	}

	/**
	 * Set the {@link #jdbcUser}.
	 * 
	 * @param jdbcUser
	 *            the jdbcUser to set
	 */
	void setJdbcUser(String jdbcUser) {
		this.jdbcUser = jdbcUser;
	}

	/**
	 * Set the {@link #sqlKeywords}.
	 * 
	 * @param sqlKeywords
	 *            the sqlKeywords to set
	 */
	void setSqlKeywords(String sqlKeywords) {
		this.sqlKeywords = sqlKeywords;
	}

	/**
	 * @param jdbcPassword
	 *            the {@link #jdbcPassword} to set
	 */
	void setJdbcPassword(String jdbcPassword) {
		this.jdbcPassword = jdbcPassword;
	}

	/**
	 * @return the {@link #userFromDBMeta}
	 */
	public String getUserFromDBMeta() {
		return userFromDBMeta;
	}

	/**
	 * @param userFromDBMeta
	 *            the {@link #userFromDBMeta} to set
	 */
	void setUserFromDBMeta(String userFromDBMeta) {
		this.userFromDBMeta = userFromDBMeta;
	}

	/**
	 * @return the {@link #urlFromDBMeta}
	 */
	public String getUrlFromDBMeta() {
		return urlFromDBMeta;
	}

	/**
	 * @param urlFromDBMeta
	 *            the {@link #urlFromDBMeta} to set
	 */
	void setUrlFromDBMeta(String urlFromDBMeta) {
		this.urlFromDBMeta = urlFromDBMeta;
	}

}
