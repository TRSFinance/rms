/*
 * Created: liushen@Apr 17, 2012 6:27:03 PM
 */
package com.trs.dev4.jdk16.exec;

import com.trs.dev4.jdk16.exception.WrappedException;
import com.trs.dev4.jdk16.utils.EnvConst;

/**
 * 封装操作系统常用的一些命令行功能，比如端口检查等。 <br>
 * 
 */
public class OSHelper {

	/**
	 * 查看给定的一个或多个端口被占用(监听)的信息。
	 * 
	 * @param port
	 * @return
	 * @since liushen @ Apr 17, 2012
	 */
	public String getTCPListeningInfo(int... ports) {
		if (ports.length == 0) {
			return "Not specific any port!";
		}
		String inputCmd = null;
		String portsWin = null;
		String portsLinux = null;
		for (int port : ports) {
			portsWin = ":" + port + " ";
			portsLinux = " -e \":" + port + " \"";
		}
		if (EnvConst.isWindows()) {
			// assertExecSucceed("netstat -ano | findstr LISTEN | findstr \":21 :80\"");
			inputCmd = "netstat -ano | findstr LISTEN | findstr \"" + portsWin + "\"";
		} else if (EnvConst.isLinux()) {
			inputCmd = "netstat -anp | grep LISTEN | grep" + portsLinux;
			// netstat -anp | grep LISTEN | grep -e ":80 " -e ":1935 "
//			tcp        0      0 0.0.0.0:1935                0.0.0.0:*                   LISTEN      13243/fmsedge       
//			tcp        0      0 :::80                       :::*                        LISTEN      1390/httpd			
		} else if (EnvConst.isMac()) {

		}
		ProcessHelper ph = new ProcessHelper(inputCmd);
		int exitValue = ph.startAndWait();
		if (exitValue != 0) {
			throw new WrappedException(ph.toString());
		}
		int count = 0;
		return new ExecuteResult(ph).firstLinesOfStdout(count);
	}

}
