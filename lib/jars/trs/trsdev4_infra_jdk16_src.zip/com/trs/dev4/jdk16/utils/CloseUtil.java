/*
 * Created: liushen@Dec 17, 2008 9:39:44 PM
 */
package com.trs.dev4.jdk16.utils;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.net.Socket;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.exception.ExceptionUtil;

/**
 * 关闭流/Socket等操作的工具类.<BR>
 * 该类的方法均是在最终清理资源时使用, 那时已经不关心异常, 为调用者方便起见, 因此该类的方法不再抛出异常.
 * 
 * @author liushen
 */
public class CloseUtil {
    
    private static final Logger LOG = Logger.getLogger(CloseUtil.class);

	/**
	 * 关闭给定的输入流. <BR>
	 * 
	 * @param inStream
	 */
	public static void closeInputStream(InputStream inStream) {
		if (inStream != null) {
			try {
				inStream.close();
			} catch (IOException e) {
				LOG.error("error on close the inputstream.", e);
			}
		}
	}

	/**
	 * 关闭给定的输出流. <BR>
	 * 
	 * @param outStream
	 */
	public static void closeOutputStream(OutputStream outStream) {
		if (outStream != null) {
			try {
				outStream.close();
			} catch (IOException e) {
				LOG.error("error on close the outputstream.", e);
			}
		}
	}

	/**
	 * 关闭给定的Socket.
	 * 
	 * @param socket
	 *            给定的Socket
	 */
	public static void closeSocket(Socket socket) {
		if (socket != null) {
			try {
				socket.close();
			} catch (IOException e) {
				LOG.error("fail on close socket: " + socket, e);
			}
		}
	}

	public static void closeStatement(Statement stmt) {
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				final Throwable rootCause = ExceptionUtil.calcRootCause(e);
				LOG.error("fail to close Statement  because " + rootCause, e);
			}
		}
	}

	/**
	 * 关闭给定的Reader.
	 * 
	 * @param reader
	 * @since ls@08.0820
	 */
	public static void closeReader(Reader reader) {
		if (reader == null) {
			return;
		}
		try {
			reader.close();
		} catch (IOException e) {
			LOG.error("error on close reader, ignored!", e);
		}
	}

	public static void closeWriter(Writer writer) {
		if (writer == null) {
			return;
		}
		try {
			writer.close();
		} catch (IOException e) {
			LOG.error("error on close writer, ignored!", e);
		}
	}

	public static void close(Reader reader) {
		if (reader != null) {
			try {
				reader.close();
			} catch (IOException e) {
				LOG.error("error on close the Reader.", e);
			}
		}
	}

	public static void close(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
				LOG.error("error on close java.sql.Connection.", e);
			}
		}
	}

	/**
	 * 关闭给定的输出流. <BR>
	 * 
	 * @param outStream
	 */
	public static void close(Writer writer) {
		if (writer != null) {
			try {
				writer.close();
			} catch (IOException e) {
				LOG.error("error on close the outputstream.", e);
			}
		}
	}

	/**
	 * 关闭给定的输入流. <BR>
	 * 
	 * @param inStream
	 */
	public static void close(InputStream inStream) {
		if (inStream != null) {
			try {
				inStream.close();
			} catch (IOException e) {
				LOG.error("error on close the inputstream.", e);
			}
		}
	}

	/**
	 * 关闭给定的输出流. <BR>
	 * 
	 * @param outStream
	 */
	public static void close(OutputStream outStream) {
		if (outStream != null) {
			try {
				outStream.close();
			} catch (IOException e) {
				LOG.error("error on close the outputstream.", e);
			}
		}
	}

	/**
	 * 关闭给定的流.
	 * 
	 * @param closeable
	 *            JDK1.5引入的新接口，是InputStream、OutputStream、DataInput、DataOutput、
	 *            RandomAccessFile等各I /O相关的接口的父接口.
	 * @since liushen @ Mar 26, 2012
	 */
	public static void close(Closeable closeable) {
		if (closeable == null) {
			return;
		}
		try {
			closeable.close();
		} catch (IOException e) {
			LOG.error("error on close [" + closeable.getClass().getName() + "]", e);
		}
	}

}
