/*
 * Created: TRS@Feb 14, 2012 1:02:28 PM
 */
package com.trs.dev4.jdk16.model;

import java.util.Date;

import net.sf.cglib.beans.BeanMap;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.utils.DateUtil;
import com.trs.dev4.jdk16.utils.NumberUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: 支持用getProperty和setProperty的操作对象属性<br>
 * 
 */
public class BeanMappedEntity {
	/**
	 * 
	 */
	private BeanMap beanMap;

	private static final Logger logger = Logger.getLogger(BeanMappedEntity.class);

	/**
	 * 
	 * @param propertyName
	 * @return
	 */
	public Object getProperty(String propertyName) {
		if (beanMap == null) {
			initBeanMap();
		}
		return beanMap.get(propertyName);
	}

	/**
	 * 
	 * @param propertyName
	 * @param value
	 */
	public void setProperty(String propertyName, Object value) {
		if (beanMap == null) {
			initBeanMap();
		}
		Class<?> propertyClass = beanMap.getPropertyType(propertyName);
		logger.debug("BeanMappedBaseObject setProperty[propertyName=" + propertyName + ",value=" + value
				+ "] , propertyClass =" + propertyClass);
		String valueStr = "";
		if (value != null) {
			valueStr = value.toString();
		}
		try {
			if (int.class.equals(propertyClass) || Integer.class.equals(propertyClass)) {
				if (StringHelper.parseInt(valueStr) == -1 && !("-1".equals(valueStr))) {
					beanMap.put(propertyName, new Integer(0));
				} else {
					beanMap.put(propertyName, new Integer(StringHelper.parseInt(valueStr)));
				}
			} else if (long.class.equals(propertyClass) || Long.class.equals(propertyClass)) {
				if (NumberUtil.parseLong(valueStr) == -1) {
					beanMap.put(propertyName, new Long(0));
				} else {
					beanMap.put(propertyName, new Long(NumberUtil.parseLong(valueStr)));
				}
			} else if (String.class.equals(propertyClass)) {
				beanMap.put(propertyName, value);
			} else if (boolean.class.equals(propertyClass) || Boolean.class.equals(propertyClass)) {
				beanMap.put(propertyName, Boolean.valueOf(valueStr));
			} else if (Date.class.equals(propertyClass)) {
				beanMap.put(propertyName, DateUtil.parseDate(valueStr));
			} else {
				beanMap.put(propertyName, value);
			}
		} catch (Throwable e) {
			logger.error("item:" + propertyName + ",propertyClass:" + propertyClass + ",value:" + value + ",exception:"
					+ e.getMessage(), e);
			//	TODO 待确认，是否需要添加异常		throw new ClassCastException("name:" + propertyName + ",Class:" + propertyClass + ",value:" + value
			//					+ ",exception:" + e.getMessage());
		}
	}

	/**
	 * 
	 */
	private void initBeanMap() {
		beanMap = BeanMap.create(this);
	}
}
