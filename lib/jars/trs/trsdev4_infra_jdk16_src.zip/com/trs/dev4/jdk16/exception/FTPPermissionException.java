/*
 * Created: liushen@Jul 17, 2013 1:12:27 PM
 */
package com.trs.dev4.jdk16.exception;

/**
 * FTP权限引起的异常（非网络连接方面的）。<br>
 * 
 */
@SuppressWarnings("serial")
public class FTPPermissionException extends FTPException {

	/**
	 * @param msg
	 * @param cause
	 */
	public FTPPermissionException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * @param msg
	 */
	public FTPPermissionException(String msg) {
		super(msg);
	}

	/**
	 * @param cause
	 */
	public FTPPermissionException(Throwable cause) {
		super(cause);
	}

}
