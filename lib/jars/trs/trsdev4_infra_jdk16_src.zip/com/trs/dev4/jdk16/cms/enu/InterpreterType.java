package com.trs.dev4.jdk16.cms.enu;

import java.io.PrintWriter;
import java.util.Set;

import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.PageletsScheduler;
import com.trs.dev4.jdk16.cms.TemplateManager;
import com.trs.dev4.jdk16.cms.bo.DocumentWrapper;
import com.trs.dev4.jdk16.cms.bo.Pagelet;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.bo.Template;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 大模板解析方式
 * 
 * @author yangyu
 * @since Feb 4, 2013 2:54:13 PM
 */
public enum InterpreterType {
	
	PageletFrame("pageletFrame"){

		@Override
		public void parsePagelet(TagContext tagContext, StringBuilder content) {
			
			GeneratorSession generatorSession = tagContext.getGeneratorSession();
			
			Site currentSite = generatorSession.getSite();
			
			String applicationUrl = generatorSession.getSettings().getBaseurlExtractor().getApplcationBaseUrl();
			
			TemplateManager templateManager = generatorSession.getSettings().getTemplateManager();
			
			String templateName = tagContext.getTagItem().getAttribute("templateName");
			
			Template template = templateManager.getBySiteAndTemplateName(templateName, currentSite.getId());
			if (template == null) {
				throw new TemplateException("<font color=\"red\">错误：存在未定义的被嵌套模板（" + templateName
						+ "），或者该被嵌套模板被删除</font>");
			}
			content.append("<div style=\"font-size:14px;font-weight:bold;z-index:10\">").append(
					"【模板&nbsp;<a target=\"_blank\" href=\"")
					.append(applicationUrl).append(
					"/console/contentGen/templateForm.do?objectId=").append(
					currentSite.getId())
					.append("&id=")
					.append(
					template.getId())
					.append(
					"&view=pageletFrame\" style=\"text-decoration: none\">").append(
					templateName).append("</a>】</div>");
			
			String loginedTemplateName = tagContext.getTagItem().getAttribute("loginedTemplateName");
			Template loginedTemplate = templateManager.getBySiteAndTemplateName(loginedTemplateName, currentSite.getId());
			if (!StringHelper.isEmpty(loginedTemplateName)) {
				content.append("<div  style=\"font-size:14px;font-weight:bold;z-index:10\">").append(
						"【模板&nbsp;<a target=\"_blank\" href=\"")
						.append(applicationUrl).append(
						"/console/contentGen/templateForm.do?objectId=")
						.append(
						currentSite.getId()).append(
						"&id=")
						.append(
						loginedTemplate.getId()).append(
						"&view=pageletFrame\" style=\"text-decoration: none\">").append(loginedTemplateName).append(
						"</a>】</div>");
			}
		}

		/**
		 * @param generatorSession
		 * @param content
		 * @param tagContext
		 * @since Administrator @ 2014-3-6
		 */
		@Override
		public void parseTRSTag(GeneratorSession generatorSession, StringBuilder content, TagContext tagContext) {
			for (String value : tagContext.getTagItem().getAttributes().values()) {
				if (value.contains("param.")) {
					content.append("<font color=\"red\">此处模板内容使用了param函数，不支持查看模板嵌套关系</font>");
					return;
				}
			}
			content.append(tagContext.getGeneratorSession().parse(tagContext));
		}
		
		
		@Override
		public void flushPagelets(GeneratorSession generatorSession, DocumentWrapper parsedResult) {

		}
		
	},
	/**
	 * COMMON，单线程顺序的解析方式，大模板的多个小模板顺序解析，然后构成一个HTML，一次输出到客户端
	 * 
	 * COMMON方式遇见TRS_PAGELET标签，即时解析
	 */
	COMMON("common") {

		@Override
		public void parsePagelet(TagContext tagContext, StringBuilder content) {
			content.append(tagContext.getGeneratorSession().parse(tagContext));
		}

		@Override
		public void flushPagelets(GeneratorSession generatorSession, DocumentWrapper parsedResult) {

		}

		/**
		 * @param generatorSession
		 * @param content
		 * @param tagContext
		 * @since Administrator @ 2014-3-6
		 */
		@Override
		public void parseTRSTag(GeneratorSession generatorSession, StringBuilder content, TagContext tagContext) {
			content.append(generatorSession.parse(tagContext));
		}
	},
	/**
	 * BIGPIPE解析方式，多线程多管道解析模板，模板多个Pagelet同时多线程解析，每个线程解析结果完成后就立即输出到客户端，避免客户端长期白页面 ，也提高了解析页面的速度
	 * 
	 * BIGPIPE遇到TRS_PAGELET标签先置空不立即解析，然后通过javascript循环解析所有的Pagelet(启动线程解析) 输出到DIV上
	 */
	BIGPIPE("bigpipe") {

		@Override
		public void parsePagelet(TagContext tagContext, StringBuilder content) {
			
		}

		@Override
		public void flushPagelets(GeneratorSession generatorSession, DocumentWrapper parsedResult) {
			PrintWriter printWriter = generatorSession.getPrintWriter();
			generatorSession
					.flushContent("<script type=\"text/javascript\">function arrivedHtml(id,text) { var b=document.getElementById(id); b.innerHTML = text; }</script>");
			
			flushPagelets(generatorSession, parsedResult, printWriter);
		}
		
		private void flushPagelets(GeneratorSession generatorSession, DocumentWrapper parsedResult,
				PrintWriter printWriter) {
			Set<Pagelet> pagelets = parsedResult.getPagelets();
			PageletsScheduler pageletsScheduler = generatorSession.getSettings().getPageletsScheduler();
			pageletsScheduler.parse(generatorSession, pagelets);
		}
		
		/**
		 * @param generatorSession
		 * @param content
		 * @param tagContext
		 * @since Administrator @ 2014-3-6
		 */
		@Override
		public void parseTRSTag(GeneratorSession generatorSession, StringBuilder content, TagContext tagContext) {
			content.append(generatorSession.parse(tagContext));
		}
	};

	String description;

	/**
	 * @param description
	 */
	private InterpreterType(String description) {
		this.description = description;
	}

	/**
	 * 
	 * @param generatorSessionImpl
	 * @param content
	 * @param parsedResult
	 * @since yangyu @ May 16, 2013
	 */
	public abstract void flushPagelets(GeneratorSession generatorSession, DocumentWrapper parsedResult);

	/**
	 * 解析Pagelet标签
	 * 
	 * @param tagContext
	 * @param content
	 * @since yangyu @ Aug 8, 2013
	 */
	public abstract void parsePagelet(TagContext tagContext, StringBuilder content);

	/**
	 * 解析TRS标签
	 * 
	 * @param generatorSession
	 * @param content
	 * @param tagContext
	 * @since yangyu @ 2014-3-6
	 */
	public abstract void parseTRSTag(GeneratorSession generatorSession, StringBuilder content, TagContext tagContext);
}
