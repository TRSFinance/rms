/*
 * Created: TRS@Feb 19, 2011 4:24:58 PM
 */
package com.trs.dev4.jdk16.job;

/**
 * 用于描述定时任务的执行上下文
 * 
 */
public class JobContext {

}
