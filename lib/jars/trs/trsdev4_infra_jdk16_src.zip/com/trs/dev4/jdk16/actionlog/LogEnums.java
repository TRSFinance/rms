/*
 * Created: liuyou@2010-4-21 上午11:51:32
 */
package com.trs.dev4.jdk16.actionlog;

/**
 * 职责: 操作日志的几个枚举属性<br>
 * 
 */
public class LogEnums {
	/**
	 * 日志级别
	 * 
	 */
	public static enum Level {
		DEBUG("调试"), INFO("信息"), WARN("警告"), ERROR("错误"), FATAL("严重");
		private String desc;

		Level(String desc) {
			this.desc = desc;
		}

		public String getDesc() {
			return desc;
		}

		@Override
		public String toString() {
			return this.getDesc();
		}
	}

	/**
	 * 操作结果
	 * 
	 */
	public static enum Result {
		SUCCESS("SUCCESS", "成功"), FAIL("FAIL", "失败");
		private String name;
		private String desc;

		Result(String name, String desc) {
			this.name = name;
			this.desc = desc;
		}

		public String getName() {
			return name;
		}

		public String getDesc() {
			return desc;
		}

		@Override
		public String toString() {
			return this.getDesc();
		}
	}

	/**
	 * 不同字段的前缀，OBJTYPE表对象类型，OPERTYPE表操作类型，OPERDESC表操作描述
	 * 
	 */
	public static enum LabelPrefix {
		OBJTYPE("actionlog.objtype."), OPERTYPE("actionlog.opertype."), OPERDESC(
				"actionlog.operdesc.");
		private String value;

		LabelPrefix(String desc) {
			this.value = desc;
		}

		public String getValue() {
			return value;
		}

		@Override
		public String toString() {
			return this.getValue();
		}
	}
}
