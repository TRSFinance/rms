package com.trs.dev4.jdk16.cms.core;

import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.GeneratorSessionFactory;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.impl.GeneratorSessionImpl;

/**
 * 
 * 职责: 创建GeneratorSession的GeneratorSessionFactory的实现类
 * 
 * 使用了ThreadLocal，创建的Session会绑定到当前的线程中去，其创建GeneratorSession是线程安全的，并且支持高并发
 * 
 */
public class GeneratorSessionFactoryImpl implements GeneratorSessionFactory {

	private ThreadLocal<GeneratorSession> generatorSessions = new ThreadLocal<GeneratorSession>();

	private Settings settings;

	public GeneratorSessionFactoryImpl(Settings settings) {
		this.settings = settings;
	}

	/**
	 * 线程安全创建GeneratorSession
	 * 
	 * @see com.trs.dev4.jdk16.cms.GeneratorSessionFactory#getCurrentSession()
	 * @since yangyu @ Apr 11, 2013
	 */
	public GeneratorSession getCurrentSession() {

		GeneratorSession generatorSession = generatorSessions.get();
		if (generatorSession == null) {
			generatorSession = new GeneratorSessionImpl(settings);
			generatorSessions.set(generatorSession);
		}
		return generatorSession;
	}

	public Settings getSettings() {
		return settings;
	}

}
