package com.trs.dev4.jdk16.cms.util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.util.UriUtils;

import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.RequestWrapper;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.bo.TagItem;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.utils.HtmlCompressor;

public class TagExpressionHelper {

	public static String[] EXPRESSIONS = { "eq", "gt", "lt", "ge", "le", "in", "like", "ne", "since" };
	public static String[] RESERVESTRING = { "true", "false", "currentUser.name", "request.fromIOS" };
	public static String[] NOCHECKEDRESERVEPREFIX = { "pagelet", "param", "cookie", "config" };
	public static String[] CHECKEDRESERVEPREFIX = { "parent", "enumValue" };
	public static String[] RESERVEPREORDERBY = { "desc", "asc" };
	public static String[] UNCHECKEDKEY = { "index", "request.contentRoot" };

	/**
	 * 去掉单引号
	 * 
	 * @param attributePart
	 * @return
	 */
	public static String trimFunction(String attributePart) {
		if ((attributePart.startsWith("'") && attributePart.endsWith("'")) || (attributePart.startsWith("(") && attributePart.endsWith(")"))) {
			attributePart = StringUtils.substring(attributePart, 1, StringUtils.length(attributePart) - 1);
		}
		return attributePart;
	}

	public static String Html2Text(String inputString) {
		String htmlStr = inputString; // 含html标签的字符串
		String textStr = "";
		java.util.regex.Pattern p_script;
		java.util.regex.Matcher m_script;
		java.util.regex.Pattern p_style;
		java.util.regex.Matcher m_style;
		java.util.regex.Pattern p_html;
		java.util.regex.Matcher m_html;

		try {
			String regEx_script = "<[\\s]*?script[^>]*?>[\\s\\S]*?<[\\s]*?\\/[\\s]*?script[\\s]*?>"; // 定义script的正则表达式
																										// {
			// 或
																										// <
																										// script
																										// [
																										// ^
																										// >
																										// ]
																										// *
																										// ?
																										// >
																										// [
																										// \
																										// \
																										// s
																										// \
																										// \
																										// S
																										// ]
																										// *
																										// ?
																										// <
																										// \
																										// \
																										// /
																										// script
																										// >
																										// }
			String regEx_style = "<[\\s]*?style[^>]*?>[\\s\\S]*?<[\\s]*?\\/[\\s]*?style[\\s]*?>"; // 定义style的正则表达式
																									// {
			// 或
																									// <
																									// style
																									// [
																									// ^
																									// >
																									// ]
																									// *
																									// ?
																									// >
																									// [
																									// \
																									// \
																									// s
																									// \
																									// \
																									// S
																									// ]
																									// *
																									// ?
																									// <
																									// \
																									// \
																									// /
																									// style
																									// >
																									// }
			String regEx_html = "<[^>]+>"; // 定义HTML标签的正则表达式

			p_script = Pattern.compile(regEx_script, Pattern.CASE_INSENSITIVE);
			m_script = p_script.matcher(htmlStr);
			htmlStr = m_script.replaceAll(""); // 过滤script标签

			p_style = Pattern.compile(regEx_style, Pattern.CASE_INSENSITIVE);
			m_style = p_style.matcher(htmlStr);
			htmlStr = m_style.replaceAll(""); // 过滤style标签

			p_html = Pattern.compile(regEx_html, Pattern.CASE_INSENSITIVE);
			m_html = p_html.matcher(htmlStr);
			htmlStr = m_html.replaceAll(""); // 过滤html标签

			textStr = htmlStr;

		} catch (Exception e) {
			System.err.println("Html2Text: " + e.getMessage());
		}

		return textStr;// 返回文本字符串
	}

	/**
	 * 构造解析模板的异常信息
	 * 
	 * @param tagContext
	 * @param message
	 * @return
	 */
	public static String buildTemplateException(TagContext tagContext, String message) {
		return "模板(" + tagContext.getTemplateName() + ")"
				+ tagContext.getTagItem().getDescWithPos() + "," + message;
	}

	/**
	 * 用于分页中构造链接
	 * 
	 * @param tagContext
	 * @return
	 */
	public static String buildUrlPattern(TagContext tagContext) {
		return deleteParameter(tagContext, "pageNo");
	}
	
	public static String deleteParameter(TagContext tagContext, String param) {
		RequestWrapper requestWrapper = tagContext.getGeneratorSession().getRequestWrapper();
		
		if (requestWrapper == null) {
			return "";
		}
		
		String queryString = "";
		try {
			queryString = UriUtils.encodeQuery(requestWrapper.getQueryString() == null ? "" : requestWrapper
					.getQueryString(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new TemplateException("encode url query error", e);
		}
		
		StringBuilder urlPattern = new StringBuilder(tagContext.getGeneratorSession().getSettings()
				.getBaseurlExtractor().getApplcationBaseUrl()
				+ requestWrapper.getRelativePath(requestWrapper.getRequest()));

		if (!StringUtils.isEmpty(queryString)) {
			String[] queryStr = StringUtils.split(queryString, "&");
			StringBuilder query = new StringBuilder();

			for (String str : queryStr) {
				if (str.startsWith(param + "=")) {
					continue;
				}
				query.append(str).append("&");
			}
			if (query.length() != 0) {
				queryString = query.deleteCharAt(query.length() - 1).toString();
				urlPattern.append("?").append(queryString);
			}
		}

		return urlPattern.toString();
	}

	public static String parseInternalTemplate(TagContext tagContext, PublishObject entity) {
		StringBuilder content = new StringBuilder();
		List<TagItem> children = tagContext.getTagItem().getChildren();
		for (Iterator<TagItem> childrenIterator = children.iterator(); childrenIterator.hasNext();) {
			TagItem child = childrenIterator.next();
			if (child.isTRSTag()) {
				if (entity == null) {
					TagContext childTagContext = new TagContext(tagContext.getGeneratorSession(), child);
					childTagContext.setPageletTagContext(tagContext.getPageletTagContext());
					content.append(tagContext.parse(childTagContext));
				} else {
					TagContext childTagContext = new TagContext(tagContext.getGeneratorSession(), child, entity);
					childTagContext.setPageletTagContext(tagContext.getPageletTagContext());
					content.append(tagContext.parse(childTagContext));
				}
			} else {
				content.append(child.getContent());
			}
		}
		return content.toString();
	}

	public static String parseLoopTemplate(TagContext tagContext, List<?> publishObjects) {
		StringBuilder content = new StringBuilder();
		int objectSize = publishObjects.size();
		for (int objectIndex = 0; objectIndex < objectSize; objectIndex++) {
			Object entity = publishObjects.get(objectIndex);
			List<TagItem> children = tagContext.getTagItem().getChildren();
			for (Iterator<TagItem> childrenIterator = children.iterator(); childrenIterator.hasNext();) {
				TagItem child = childrenIterator.next();
				if ("TRS_WRAPLINE".equalsIgnoreCase(child.getName())) {
					int length = 0;
					try {
						length = Integer.parseInt(child.getAttribute("length"));
					} catch (NumberFormatException e) {
						throw new TemplateException("TRS_WRAPLINE标签需要指定length属性", tagContext);
					}
					for (int i = 0; i < length && objectIndex < objectSize; i++) {
						TagContext wrapLineTagContext = new TagContext(tagContext.getGeneratorSession(), child, new PublishObject(publishObjects.get(objectIndex)));
						wrapLineTagContext.setPageletTagContext(tagContext.getPageletTagContext());
						content.append(tagContext.parse(wrapLineTagContext));
						if (i != length - 1) {
							objectIndex++;
						}
					}
				} else if (child.isTRSTag()) {
					TagContext childTagContext = new TagContext(tagContext.getGeneratorSession(), child, new PublishObject(entity, objectIndex + 1));
					childTagContext.setPageletTagContext(tagContext.getPageletTagContext());
					content.append(tagContext.parse(childTagContext));
				} else {
					content.append(child.getContent());
				}
			}
		}
		return content.toString();
	}

	/**
	 * 返回原串中位于两个字符串之间的子串，不包括这两个字符串。
	 * 
	 * @param origin
	 *            原字符串
	 * @param begin
	 *            第一个子字符串；如果为<code>null</code>则返回第二个字符串前面的内容；如果原串中不存在该串，则返回原串
	 * @param end
	 *            第二个子字符串；如果为<code>null</code>则返回第一个字符串后面的内容。
	 * @return 符合条件的字符串
	 * @since liushen @ Jan 23, 2010
	 */
	public static String substring(String origin, String begin, String end) {
		if (origin == null) {
			return origin;
		}
		int beginIndex = (begin == null) ? 0 : origin.indexOf(begin) + begin.length();
		int endIndex = (end == null) ? origin.length() : origin.indexOf(end, beginIndex);
		if (endIndex == -1) {
			return origin.substring(beginIndex);
		}
		// 避免越界错误
		if (origin.length() <= beginIndex) {
			return origin;
		}
		return origin.substring(beginIndex, endIndex);
	}

	/**
	 * 获取匹配正则表达式的结果的第一个值
	 * 
	 * @param value
	 * @param reg
	 * @return
	 * @since yangyu @ Oct 23, 2012
	 */
	public static String getMatchRegStr(String value, String reg) {
		Pattern patternQuote = Pattern.compile(reg);
		Matcher matcher = patternQuote.matcher(value);
		while (matcher.find()) {
			return matcher.group();
		}
		return "";
	}

	/**
	 * 获取匹配正则表达式的结果列表
	 * 
	 * @param value
	 * @param reg
	 * @return
	 * @since yangyu @ Oct 23, 2012
	 */
	public static List<String> getMatchRegStrs(String value, String reg) {
		Pattern patternQuote = Pattern.compile(reg);
		Matcher matcher = patternQuote.matcher(value);
		List<String> lst = new ArrayList<String>();
		while (matcher.find()) {
			lst.add(matcher.group());
		}
		return lst;
	}

	/**
	 * 压缩HTML，去掉不必要的空格，和空行
	 * 
	 * @param content
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public static String compressHTML(String content) {
		try {
			return content = HtmlCompressor.compress(content);
		} catch (Exception e) {
			throw new TemplateException("压缩HTML出错");
		}
	}
}
