/*
 * Created: liushen@Sep 27, 2012 12:06:30 PM
 */
package com.trs.dev4.jdk16.utils;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.exception.WrappedException;

/**
 * 对properties文件中的配置值进行加密的工具。 <br>
 * 用法很简单，参见TRSVIDEO工程的单元测试ConfigFileTest。
 */
public class PropertiesFileEncryptor {

	private static final Logger LOG = Logger.getLogger(PropertiesFileEncryptor.class);

	private File file;

	private String[] encryptedNames;

	/**
	 * 
	 */
	public PropertiesFileEncryptor(File file, String[] encryptedNames) {
		this.file = file;
		this.encryptedNames = encryptedNames;
	}

	/**
	 * 执行加密操作，加密 {@link #encryptedNames} 指定的配置项的配置值。
	 * 
	 * @return 实际加密的条数
	 * @since liushen @ Sep 27, 2012
	 */
	@SuppressWarnings("rawtypes")
	public int encryptValues() {
		EncryptedProperties configProps = new EncryptedProperties(encryptedNames);
		try {
			Properties tmpProps = PropertyUtil.assertAndLoadProperties(file);
			configProps.putAll(tmpProps);
			if (LOG.isDebugEnabled()) {
				LOG.debug("tmpProps: " + tmpProps);
				LOG.debug("configProps: " + configProps);
			}
		} catch (RuntimeException e) {
			LOG.error("fail to load properties file [" + file + "]", e);
			throw e;
		}

		// 判断是否有未加密的项，如果没有则直接返回；否则就先加密，然后更新回配置文件
		Map modifiedProperties = configProps.getModifiedProperties();
		if (CollectionUtil.isEmpty(modifiedProperties)) {
			return 0;
		}
		ConfigFileModifier cfm = new ConfigFileModifier(file);
		cfm.modifyProperties(modifiedProperties);
		try {
			cfm.saveModifies();
		} catch (IOException e) {
			LOG.error("", e);
			throw new WrappedException("", e);
		}

		return modifiedProperties.size();
	}

}