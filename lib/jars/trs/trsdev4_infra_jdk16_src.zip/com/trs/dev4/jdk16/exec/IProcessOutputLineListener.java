/*
 * Created: liushen@Jul 4, 2013 5:24:54 PM
 */
package com.trs.dev4.jdk16.exec;

/**
 * 进程输出的监听器， <br>
 * 
 */
public interface IProcessOutputLineListener {

	/**
	 * 读完一行后做什么。
	 * 
	 * @param line
	 *            当前行的内容
	 * @since liushen @ Jul 4, 2013
	 */
	void afterReadLine(String line);

}
