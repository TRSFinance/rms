package com.trs.dev4.jdk16.cms.cache;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.CacheProvider;
import com.trs.dev4.jdk16.cms.SiteManager;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.cms.template.CachedOperationCallback;

/**
 * SiteManager的缓存代理类，为外部实现的SiteManager增加缓存功能
 * 
 * @author yangyu
 * @since Feb 20, 2013 3:04:13 PM
 */
public class CachableSiteManager implements SiteManager {

	protected static Logger LOG = Logger.getLogger(CachableSiteManager.class);

	private SiteManager siteManager;

	private CacheProvider cacheProvider;

	private Settings settings;

	private final String CACHEKEY = "currentSite";

	/**
	 * 创建站点
	 */
	public int addNew(Site site) {
		return siteManager.addNew(site);
	}

	/**
	 * 设置为当前站点
	 */
	public Site changeCurrent(Site site) {
		cacheProvider.set(CACHEKEY, site);
		siteManager.changeCurrent(site);
		return site;
	}

	/**
	 * 删除站点
	 */
	public void delete(Site site) {
		Site currentSite = this.getCurrent();
		if (currentSite != null && currentSite.getId() == site.getId()) {
			cacheProvider.remove(CACHEKEY);
		}
		siteManager.delete(currentSite);
	}

	/**
	 * 获取当前站点
	 */
	public Site getCurrent() {
		return (Site) settings.getCachedOperationTemplate().obtainCachedData(CACHEKEY, 30,
				new CachedOperationCallback() {
			@Override
			public Object doTakeCachingData() {
				return siteManager.getCurrent();
			}
		});
	}

	/**
	 * 更新站点
	 */
	public void update(Site site) {
		Site currentSite = (Site) cacheProvider.get(CACHEKEY).getResultObject();
		if (currentSite != null && currentSite.getId() == site.getId()) {
			cacheProvider.set(CACHEKEY, site);
		}
		siteManager.update(site);
	}

	public void setSiteManager(SiteManager siteManager) {
		this.siteManager = siteManager;
	}

	public void setCacheProvider(CacheProvider cacheProvider) {
		this.cacheProvider = cacheProvider;
	}

	public void setSettings(Settings settings) {
		this.settings = settings;
		this.setCacheProvider(settings.getCacheProvider());
		this.setSiteManager(settings.getSiteManager());
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.SiteManager#cancelCurrent(com.trs.dev4.jdk16.cms.bo.Site)
	 * @since yangyu @ Aug 7, 2013
	 */
	@Override
	public void cancelCurrent(Site site) {
		cacheProvider.remove(CACHEKEY);
		siteManager.delete(site);
	}
}
