package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.cache.CachedResult;

/**
 * 缓存接口
 * 
 * @author yangyu
 * @since Jan 16, 2013 3:41:25 PM
 */
public interface CacheProvider {

	CachedResult get(String key);

	void set(String key, Object object, int expr);
	
	void set(String key, Object object);

	void clear();

	void remove(String key);
	
	void initializeCache();

}
