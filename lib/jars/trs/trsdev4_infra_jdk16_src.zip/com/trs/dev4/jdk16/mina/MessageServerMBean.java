/*
 * Created: dujie@Oct 29, 2010 4:49:30 PM
 */
package com.trs.dev4.jdk16.mina;

/**
 * 职责: JMX使用的MBean接口<br>
 * 
 */
public interface MessageServerMBean {
}
