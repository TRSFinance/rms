/*
 * Created: Administrator@Feb 3, 2009 11:37:00 PM
 */
package com.trs.dev4.jdk16.model;

import java.util.Map;

/**
 * 对需要配置的模块的抽象.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public interface IConfigurable {

	/**
	 * 声明该对象所有配置项的前缀；前缀用于区分各模块，因此不能重复.
	 * 
	 * @return 字符串表示的前缀
	 */
	String getPrefix();

	/**
	 * 更新此对象的配置项; 如果该对象内部没有缓存配置项，则提供一个空的实现即可.
	 * 
	 * @creator liushen @ Sep 3, 2009
	 */
	void refreshConfigs();

	/**
	 * 校验该配置模块的各配置项.
	 * 
	 * @param configs
	 * @return 校验结果
	 * @creator liushen @ Feb 17, 2010
	 */
	ValidationErrors validateConfigs(Map<String, Configuration> configs);

}
