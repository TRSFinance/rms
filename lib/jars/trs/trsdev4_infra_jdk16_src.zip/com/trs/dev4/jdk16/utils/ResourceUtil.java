/**
 * Created: liushen@Jan 27, 2010 12:11:26 AM
 */
package com.trs.dev4.jdk16.utils;

import java.net.URL;

/**
 * 获取资源文件的工具类. <BR>
 * 
 * @author TRS信息技术有限公司
 */
public class ResourceUtil {

	public static String getFullPath(String resourceName) {
		return getFullPath(ResourceUtil.class, resourceName);
	}

    public static String getFullPath(Class<?> clazz, String resourceName) {
		URL url = clazz.getResource(resourceName);
		if (url == null) {
			return null;
		}
		// ls@06-0728 增加对包含空格或中文的路径的处理
		return UrlUtil.decode(url.getFile());
	}

}
