package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.enu.ExpressionFunction;

/**
 * 置标表达式函数定义接口
 * 
 * @author yangyu
 * @since Mar 13, 2013 1:39:11 PM
 */
public interface FunctionExtractor {

	/**
	 * 获取函数名称
	 * @param attributePart
	 * @return
	 */
	ExpressionFunction findFunction(String attributePart);

	/**
	 * 获取函数属性
	 * @param attributePart
	 * @return
	 */
	String extracteParameter(String attributePart);

}
