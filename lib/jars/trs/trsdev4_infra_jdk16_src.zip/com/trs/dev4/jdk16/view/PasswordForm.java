package com.trs.dev4.jdk16.view;

/**
 * 职责: .<br>
 * @author TRS信息技术股份有限公司
 */
public class PasswordForm {

	/**
	 * 
	 */
	private String oldPassword;
	
	/**
	 * 
	 */
	private String newPassword;
	
	/**
	 * 
	 */
	private String confirmPassword;

	/**
	 * Get the {@link #oldPassword}. 
	 * @return the {@link #oldPassword}.
	 */
	public String getOldPassword() {
		return oldPassword;
	}

	/**
	 * Set the {@link #oldPassword}.
	 * @param oldPassword the oldPassword to set
	 */
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	/**
	 * Get the {@link #newPassword}. 
	 * @return the {@link #newPassword}.
	 */
	public String getNewPassword() {
		return newPassword;
	}

	/**
	 * Set the {@link #newPassword}.
	 * @param newPassword the newPassword to set
	 */
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	/**
	 * Get the {@link #confirmPassword}. 
	 * @return the {@link #confirmPassword}.
	 */
	public String getConfirmPassword() {
		return confirmPassword;
	}

	/**
	 * Set the {@link #confirmPassword}.
	 * @param confirmPassword the confirmPassword to set
	 */
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
}
