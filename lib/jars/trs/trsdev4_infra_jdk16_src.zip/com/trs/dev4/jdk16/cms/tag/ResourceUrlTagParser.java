/*
 * Created: yangyu@2013-6-16 下午9:19:41
 */
package com.trs.dev4.jdk16.cms.tag;

import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.TagContext;

/**
 * 职责: <br>
 * 
 */
public class ResourceUrlTagParser implements TagParser {

	/**
	 * @see com.trs.dev4.jdk16.cms.TagParser#parse(com.trs.dev4.jdk16.cms.bo.TagContext)
	 * @since yangyu @ 2013-6-16
	 */
	@Override
	public String parse(TagContext tagContext) {
		return tagContext.getSettings().getBaseurlExtractor().getStaticResourceBaseUrl();
	}

}
