/*
 * Created: Administrator@2013-12-4 下午02:33:41
 */
package com.trs.dev4.jdk16.cms.tag;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/**
 * 职责: <br>
 * 
 */
public class TagDefination {

	protected static Logger LOG = Logger.getLogger(TagDefination.class);

	private List<ParserConf> parsers = new ArrayList<ParserConf>();

	public volatile static TagDefination tagDefination = null;

	private TagDefination() {

	}

	public static TagDefination getInstance() {
		if (tagDefination == null) {
			synchronized (TagDefination.class) {
				if (tagDefination == null) {
					tagDefination = new TagDefination();
				}
			}
		}
		return tagDefination;
	}

	/**
	 * @return the {@link #parsers}
	 */
	public List<ParserConf> getParsers() {
		return parsers;
	}

	/**
	 * @param parsers
	 *            the {@link #parsers} to set
	 */
	public void setParsers(List<ParserConf> parsers) {
		this.parsers = parsers;
	}

	@SuppressWarnings("unchecked")
	public void initDefination() {
		String defaultXMLPath = Thread.currentThread().getContextClassLoader().getResource("tagDefinition-default.xml")
				.getPath();
		SAXReader saxReader = new SAXReader();
		Document doc = null;
		try {
			doc = saxReader.read(defaultXMLPath);
		} catch (DocumentException e) {
			LOG.error("读取tagDefinition-default.xml出错", e);
		}

		Element root = doc.getRootElement();

		List<ParserConf> parsers = new ArrayList<ParserConf>();
		
		for (Iterator<Element> rootIterator = root.elementIterator(); rootIterator.hasNext();) {
			Element tagParserElement = rootIterator.next();
			ParserConf parserConf = ParserConf.read(tagParserElement);
			parsers.add(parserConf);
		}
		
		this.parsers = parsers;
	}

}
