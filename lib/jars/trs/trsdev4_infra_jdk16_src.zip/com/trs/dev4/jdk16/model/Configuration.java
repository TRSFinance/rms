/*
 *
 */
package com.trs.dev4.jdk16.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.GenericGenerator;

import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 全局配置项.
 */
@SuppressWarnings("serial")
@Entity(name = "MAS_Configuration")
@Table(name = "MAS_CONFIG")
@GenericGenerator(name = "idStrategy", strategy = "native")
public class Configuration extends BaseEntity implements Serializable, Cloneable {
	public static final String TYPE_STRING = "string";
	public static final String TYPE_TEXT = "text";
	public static final String TYPE_INT = "int";
	public static final String TYPE_FLOAT = "float";
	public static final String NODE_ALL = "%";

	/**
	 * 前缀.
	 */
	@Column(name = "`PREFIX`")
	private String prefix;

	/**
	 * 名称；注意：名称并不唯一，前缀 + 名称才是全局唯一的.
	 */
	@Column(name = "`NAME`")
	private String name;

	/**
	 * 配置值; 初始值（未设置时）为<code>""</code>.
	 */
	@Column(name = "`VALUE`", length = 1024)
	private String value = "";

	/**
	 * 用于显示给用户的友好名称.
	 */
	@Column(name = "`CNAME`")
	private String cname;

	/**
	 * 备注； 该配置项的一些重要说明.
	 */
	@Column(name = "`COMMENT`")
	private String comment;

	/**
	 * 该配置项适用的节点；默认为%，即所有节点.
	 */
	@Column(name = "`NODE`")
	private String node = NODE_ALL;

	/**
	 * 该配置项是否需要初始化.
	 */
	@Column(name = "`NEEDSETUP`")
	private boolean needSetup;

	// TODO liushen @ Nov 2, 2010: 暂时先处理显示加密，以后再处理存储加密及解密.
	/**
	 * 该配置项是否需要加密.
	 */
	@Column(name = "`NEEDENCRYPT`")
	@AccessType("com.trs.dev4.jdk16.dao.SafeDirectPropertyAccessor")
	private boolean needEncrypt;

	/**
	 * 该配置项的默认值.
	 */
	@Column(name = "`DEFAULTVALUE`")
	private String defaultValue;

	/**
	 * 该配置项是否禁止人为修改.
	 */
	@Column(name = "`FORBIDMODIFY`")
	private boolean forbidModify;

	/**
	 * 类型 int | string | path | url；暂时没有使用.
	 */
	@Column(name = "`TYPE`")
	private String type;

	/**
	 * 可选值，以半角分号(;)分割
	 */
	@Column(name = "`OPTIONS`", length = 200)
	private String options;
	/**
	 * 动态获取可选值，如果设置有optionReader的话，则优先获取，否则获取options。与
	 * {@link IConfigurationOptionReader#getConfigurationOptionReaderName()}
	 * 获得相关的名称，与Spring配置的beanName无关；
	 */
	@Column(name = "`OPTIONREADER`", length = 100)
	private String optionReader;

	/**
	 * 默认构造函数.
	 */
	public Configuration() {
		long now = System.currentTimeMillis();
		createdTime = now;
		lastModifiedTime = now;
	}

	/**
	 * @param obj
	 * @since liushen @ Feb 15, 2010
	 */
	public void setValueFromObject(Object obj) {
		if (obj != null) {
			setValue(String.valueOf(obj));
		}
	}

	/**
	 * 获取该配置值的安全显示形式.
	 * 
	 * @since liushen @ Nov 2, 2010
	 */
	public String getMaskValue() {
		if (isNeedEncrypt()) {
			return StringHelper.avoidNull(StringHelper
					.toSecurityMaskForm(value));
		}
		return StringHelper.avoidNull(getValue());
	}

	/**
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString(){
		StringBuilder buffer = new StringBuilder(96);
		buffer.append(getClass().getSimpleName()).append("@")
				.append(hashCode());
		buffer.append(": ").append(prefix).append(".").append(name);
		buffer.append("=").append(value);
		buffer.append(";id=").append(id);
		buffer.append(";createdTime=").append(createdTime);
		return buffer.toString();
	}

	/**
	 * 
	 * @return
	 * @since TRS @ Feb 1, 2012
	 */
	public static Configuration buildConfiguration(String name, String value, String type, String options, String prefix) {
		Configuration con = new Configuration();
		con.setName(name);
		con.setValue(value);
		con.setType(type);
		con.setOptions(options);
		con.setPrefix(prefix);
		return con;
	}

	/**
	 * @see java.lang.Object#clone()
	 * @since liushen @ Dec 24, 2012
	 */
	@Override
	public Configuration clone() throws CloneNotSupportedException {
		return (Configuration) super.clone();
	}

	/**
	 * Get the {@link #name}.
	 * 
	 * @return the {@link #name}.
	 */
	public String getName() {
		return name;
	}
	/**
	 * Set the {@link #name}.
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Get the {@link #value}.
	 * 
	 * @return the {@link #value}.
	 */
	public String getValue() {
		return value;
	}
	/**
	 * Set the {@link #value}.
	 * @param value the value to set
	 */
	public void setValue(String value) {
		if (value != null && value.length() > 1024) {
			value = value.substring(0, 1024);
		}
		this.value = value;
	}

	/**
	 * Get the {@link #type}.
	 * 
	 * @return the {@link #type}.
	 */
	public String getType() {
		return type;
	}
	/**
	 * Set the {@link #type}.
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Get the {@link #comment}.
	 * 
	 * @return the {@link #comment}.
	 */
	public String getComment() {
		return comment;
	}
	/**
	 * Set the {@link #comment}.
	 * @param notes the notes to set
	 */
	public void setComment(String notes) {
		this.comment = notes;
	}

	/**
	 * Get the {@link #prefix}.
	 * 
	 * @return the {@link #prefix}.
	 */
	public String getPrefix() {
		return prefix;
	}
	/**
	 * Set the {@link #prefix}.
	 * @param module the module to set
	 */
	public void setPrefix(String module) {
		this.prefix = module;
	}

	/**
	 * Get the {@link #node}.
	 * 
	 * @return the {@link #node}.
	 */
	public String getNode() {
		return node;
	}
	/**
	 * Set the {@link #node}.
	 * @param nodeName the nodeName to set
	 */
	public void setNode(String nodeName) {
		this.node = nodeName;
	}

	/**
	 * Get the {@link #cname}.
	 * 
	 * @return the {@link #cname}.
	 */
	public String getCname() {
		return StringHelper.avoidNull(cname);
	}

	/**
	 * Set the {@link #cname}.
	 * 
	 * @param cname
	 *            the cname to set
	 */
	public void setCname(String cname) {
		this.cname = cname;
	}

	/**
	 * Get the {@link #needSetup}.
	 * 
	 * @return the {@link #needSetup}.
	 */
	public boolean isNeedSetup() {
		return needSetup;
	}

	/**
	 * Set the {@link #needSetup}.
	 * 
	 * @param needSetup
	 *            the needSetup to set
	 */
	public void setNeedSetup(boolean needSetup) {
		this.needSetup = needSetup;
	}

	/**
	 * Get the {@link #defaultValue}.
	 * 
	 * @return the {@link #defaultValue}.
	 */
	public String getDefaultValue() {
		return defaultValue;
	}

	/**
	 * Set the {@link #defaultValue}.
	 * 
	 * @param defaultValue
	 *            the defaultValue to set
	 */
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	/**
	 * Get the {@link #forbidModify}.
	 * 
	 * @return the {@link #forbidModify}.
	 */
	public boolean isForbidModify() {
		return forbidModify;
	}

	/**
	 * Set the {@link #forbidModify}.
	 * 
	 * @param forbidModify
	 *            the forbidModify to set
	 */
	public void setForbidModify(boolean forbidModify) {
		this.forbidModify = forbidModify;
	}


	/**
	 * @return the {@link #needEncrypt}
	 */
	public boolean isNeedEncrypt() {
		return needEncrypt;
	}

	/**
	 * @param needEncrypt
	 *            the {@link #needEncrypt} to set
	 */
	public void setNeedEncrypt(boolean needEncrypt) {
		this.needEncrypt = needEncrypt;
	}

	/**
	 * @return the {@link #options}
	 */
	public String getOptions() {
		return options;
	}

	/**
	 * @param options
	 *            the {@link #options} to set
	 */
	public void setOptions(String options) {
		this.options = options;
	}

	/**
	 * @return the {@link #optionReader}
	 */
	public String getOptionReader() {
		return optionReader;
	}

	/**
	 * @param optionsReader
	 *            the {@link #optionReader} to set
	 */
	public void setOptionReader(String optionReader) {
		this.optionReader = optionReader;
	}

}
