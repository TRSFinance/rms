package com.trs.dev4.jdk16.cms.expression;


/**
 * id desc
 * 
 * @author yangyu
 * @since Mar 12, 2013 10:23:46 AM
 */
public class OrderByTagExpresion {

	private String entityProperty;

	private String orderby;
	
	private String searchString;
	
	public String getEntityProperty() {
		return entityProperty;
	}

	public void setEntityProperty(String entityProperty) {
		this.entityProperty = entityProperty;
	}

	public String getSearchString() {
		return searchString;
	}

	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

	public String getOrderby() {
		return orderby;
	}

	public void setOrderby(String orderby) {
		this.orderby = orderby;
	}

}
