package com.trs.dev4.jdk16.cms.impl;

import java.util.Iterator;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.TemplateInterpreter;
import com.trs.dev4.jdk16.cms.bo.DocumentWrapper;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.bo.TagItem;
import com.trs.dev4.jdk16.cms.bo.TemplateDocument;
import com.trs.dev4.jdk16.cms.bo.TagItem.TagItemType;
import com.trs.dev4.jdk16.cms.enu.InterpreterType;
import com.trs.dev4.jdk16.cms.template.CachedOperationCallback;

/**
 * ParsedResultHandller的实现类，缓存中获取获取站点下所有的模板的解析结果
 * 
 * @author yangyu
 * @since Feb 26, 2013 11:02:57 AM
 */
public class TemplateInterpreterImpl implements TemplateInterpreter {

	/**
	 * 将模板的解析结果进行缓存
	 * 
	 * @see com.trs.dev4.jdk16.cms.TemplateInterpreter#retrieveDocumentWrapper(com.trs.dev4.jdk16.cms.GeneratorSession)
	 * @since yangyu @ Apr 11, 2013
	 */
	private DocumentWrapper retrieveCachedDocumentWrapper(final GeneratorSession generatorSession) {

		final Settings settings = generatorSession.getSettings();

		return (DocumentWrapper) settings.getCachedOperationTemplate().obtainCachedData(
				generatorSession.getCacheProvider(), getCacheKey(generatorSession), new CachedOperationCallback() {

					/**
					 * 如果缓存中无数据，重新解析大模板，并将解析结果ParserdResult缓存起来
					 * 
					 * @see com.trs.dev4.jdk16.cms.template.CachedOperationCallback#doTakeCachingData()
					 * @since yangyu @ Apr 12, 2013
					 */
					@Override
					public Object doTakeCachingData() {
						Site currentSite = generatorSession.getSite();
						Settings settings = generatorSession.getSettings();
						String content = generatorSession.getParsedContent(generatorSession, settings);
						content = this.replaceBaseUrl(settings, currentSite, content);
						return wrapDocument(generatorSession, settings, content);
					}

					/**
					 * 将模板的征文封装成 TemplateDocument ， 合并模板的文本和可以缓存的标签，避免重复的拼串，
					 * 
					 * @param generatorSession
					 * @param settings
					 * @param content
					 * @return
					 * @since Administrator @ 2013-11-12
					 */
					private Object wrapDocument(GeneratorSession generatorSession, Settings settings,
							String content) {
						TemplateDocument templateDocument = new TemplateDocument(content);

						DocumentWrapper documentWrapper = new DocumentWrapper();

						for (Iterator<TagItem> iterator = templateDocument.getItems().iterator(); iterator.hasNext();) {
							TagItem tagItem = iterator.next();
							if (tagItem.isTextTag()) {
								documentWrapper.appendTextTag(tagItem);
							} else if (tagItem.isPageletTag()) {
								documentWrapper.addPagelet(tagItem);
							} else if (tagItem.isTRSTag()) {
								documentWrapper.addTRSTag(generatorSession, tagItem);
							}
						}

						return documentWrapper;
					}

					/**
					 * 替换<head>为<head><base href=""/>，方便静态导入后，可以立即看到静态页面效果
					 * 
					 * @param settings
					 * @param currentSite
					 * @param template
					 */
					private String replaceBaseUrl(Settings settings, Site currentSite, String content) {
						if (currentSite.isAutoAttachBaseUrl()) {
							String buildBasePath = settings.getBaseurlExtractor().getStaticResourceBaseUrl();
							if (!StringUtils.isEmpty(buildBasePath) && !StringUtils.isEmpty(currentSite.getSiteMark())) {
								if (content.contains("<head>")) {
									content = StringUtils.replace(content, "<head>", "<head><base href=\""
											+ buildBasePath + "templates/" + currentSite.getSiteMark() + "/\"/>");
								} else {
									content = "<base href=\"" + buildBasePath + "templates/"
											+ currentSite.getSiteMark() + "/\"/>"
											+ content;
								}
							}
						}
						return content;
					}

				});
	}

	/**
	 * 获取缓存键值
	 * 
	 * @param generatorSession
	 * @return
	 * @since yangyu @ Aug 7, 2013
	 */
	private String getCacheKey(final GeneratorSession generatorSession) {
		return "ParsedResult_Site_" + generatorSession.getSite().getId() + "_Template_"
				+ generatorSession.getPageLink().getTemplateName();
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.TemplateInterpreter#interpret(com.trs.dev4.jdk16.cms.impl.GeneratorSessionImpl)
	 * @since yangyu @ Aug 8, 2013
	 */
	@Override
	public void interpret(GeneratorSession generatorSession) {

		InterpreterType interpreterType = generatorSession.getInterpreterType();

		DocumentWrapper documentWrapper = this.retrieveCachedDocumentWrapper(generatorSession);

		flushHtmlBody(generatorSession, interpreterType, documentWrapper);

		interpreterType.flushPagelets(generatorSession, documentWrapper);

		flushJavascripts(generatorSession, documentWrapper);

	}

	private void flushHtmlBody(GeneratorSession generatorSession, InterpreterType interpreterType,
			DocumentWrapper documentWrapper) {
		StringBuilder content = new StringBuilder();

		for (Iterator<TagItem> iterator = documentWrapper.getTagNodes().iterator(); iterator.hasNext();) {
			TagItem tagItem = iterator.next();
			TagContext tagContext = new TagContext(generatorSession, tagItem);
			if (tagItem.getTagItemType() == TagItemType.PAGELET) {
				interpreterType.parsePagelet(tagContext, content);
			} else if (tagItem.getTagItemType() == TagItemType.TRSTAG) {
				interpreterType.parseTRSTag(generatorSession, content, tagContext);
			} else {
				content.append(tagItem.getContent());
			}
		}

		generatorSession.flushContent(content.toString());
	}

	/**
	 * 将Pagelet所使用的Javascript全部输出，放在页面最后
	 * 
	 * 因为BIGPIPE也是通过javascript加载的，如果不放在Pagelet解析javascript之后，可能导致javascript不起作用
	 * 
	 * @param generatorSession
	 * 
	 * @param documentWrapper
	 * @param printWriter
	 * @since yangyu @ Apr 12, 2013
	 */
	private void flushJavascripts(GeneratorSession generatorSession, DocumentWrapper documentWrapper) {
		StringBuilder jscontent = new StringBuilder();
		Set<String> jses = documentWrapper.getJsSet();
		for (Iterator<String> iterator = jses.iterator(); iterator.hasNext();) {
			String js = iterator.next();
			jscontent.append("<script type=\"text/javascript\" src=\"").append(js).append("\"></script>");
		}
		generatorSession.flushContent(jscontent.toString());
	}

}
