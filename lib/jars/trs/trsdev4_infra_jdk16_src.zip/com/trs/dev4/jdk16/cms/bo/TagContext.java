package com.trs.dev4.jdk16.cms.bo;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import com.trs.dev4.jdk16.cms.CurrentUsernameExtractor;
import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.TagAware;
import com.trs.dev4.jdk16.cms.enu.ExpressionDefination;
import com.trs.dev4.jdk16.cms.enu.LoopType;
import com.trs.dev4.jdk16.cms.exp.RequestParameterNotFoundException;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.cms.expression.FilterByFieldTagExpression;
import com.trs.dev4.jdk16.cms.expression.OrderByTagExpresion;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 
 * 职责: 置标标签的上下文信息，用于外层标签传给内部标签的参数封装，也提供了获取标签属性的值给种方法
 * 
 */
public class TagContext {
	/**
	 * 标签
	 */
	private TagItem tagItem;
	/**
	 * 父标签解析对象
	 */
	private PublishObject entity;
	/**
	 * 请求会话，可以获取会话参数，以及Settings组建全局参数
	 */
	private GeneratorSession generatorSession;

	/**
	 * 标签所在Pagelet的上下文，用于Pagelet函数
	 */
	private TagContext pageletTagContext;

	/**
	 * 当前上下文所在的模板名称
	 */
	private String templateName;

	/**
	 * 是否需要使用数据缓存，只有涉及到用户的才使用CachedTagAware
	 */
	private boolean needCachedTagAware = true;


	public TagContext(GeneratorSession generatorSession, TagItem tagItem, PublishObject publishObject) {
		this.generatorSession = generatorSession;
		this.tagItem = tagItem;
		this.entity = publishObject;
		if (StringHelper.isEmpty(templateName)&&generatorSession.getPageLink()!=null) {
			templateName = generatorSession.getPageLink().getTemplateName();
		}
	}

	public TagContext(GeneratorSession generatorSession, TagItem tagItem) {
		this(generatorSession, tagItem, null);
	}

	/**
	 * FilterByField置标表达式取值
	 * 
	 * @param attribute
	 * @return
	 */
	public List<FilterByFieldTagExpression> getFilterByFieldValues(String attributeName) {
		String attribute = tagItem.getAttribute(attributeName);
		ExpressionResult expressionResult = ExpressionDefination.FILTERBYFIELD.resolve(this, attribute);
		return expressionResult.getFilterByFieldList();
	}

	/**
	 * 获取String置标表达式的值
	 * 
	 * @param attributeName
	 * @return
	 */
	public String getStringValue(String attributeName) {
		return tagItem.getAttribute(attributeName);
	}

	/**
	 * 获取String置标表达式的值，可以设置默认值
	 * 
	 * @param attributeName
	 * @param defaultValue
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public String getStringValue(String attributeName, String defaultValue) {
		String attribute = tagItem.getAttribute(attributeName);
		if (StringUtils.isEmpty(attribute)) {
			attribute = defaultValue;
		}
		return attribute;
	}

	/**
	 * INT_FUNCTION置标表达式的属性取值
	 * 
	 * @param attributeName
	 * @return
	 */
	public int getIntFunctionValue(String attributeName) {
		String attribute = tagItem.getAttribute(attributeName);
		ExpressionResult expressionResult = ExpressionDefination.INTFUNCTION.resolve(this, attribute);
		return expressionResult.getIntValue();
	}

	/**
	 * 获取INT类型置标表达式的值
	 * 
	 * @param attributeName
	 * @param defaultValue
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public int getIntFunctionValue(String attributeName, int defaultValue) {
		String attribute = tagItem.getAttribute(attributeName);
		try {
			ExpressionResult expressionResult = ExpressionDefination.INTFUNCTION.resolve(this, attribute);
			return expressionResult.getIntValue();
		} catch (RequestParameterNotFoundException e) {
			return defaultValue;
		}
	}

	/**
	 * ORDERBY置标表达式取值
	 * 
	 * @param attributeName
	 * @return
	 */
	public List<OrderByTagExpresion> getOrderByValue(String attributeName) {
		String attribute = tagItem.getAttribute(attributeName);
		ExpressionResult expressionResult = ExpressionDefination.ORDERBY.resolve(this, attribute);
		return expressionResult.getOrderByArray();
	}

	/**
	 * 获取INT表达式取值
	 * 
	 * @param attributeName
	 * @return
	 */
	public int getIntValue(String attributeName) {
		String attribute = tagItem.getAttribute(attributeName);
		return NumberUtils.toInt(attribute);
	}

	/**
	 * 获取INT表达式取值，补充默认值
	 * 
	 * @param attributeName
	 * @param defaultValue
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public int getIntValue(String attributeName, int defaultValue) {
		String attribute = tagItem.getAttribute(attributeName);
		if (!StringUtils.isEmpty(attribute)) {
			return NumberUtils.toInt(attribute);
		} else {
			return defaultValue;
		}
	}

	/**
	 * 获取boolean表达式的值
	 * 
	 * @param attributeName
	 * @return
	 */
	public boolean getBooleanValue(String attributeName) {
		return this.getBooleanValue(attributeName, false);
	}

	/**
	 * 获取boolean表达式的值，可以设置默认值
	 * 
	 * @param attributeName
	 * @return
	 */
	public boolean getBooleanValue(String attributeName, boolean defaultValue) {
		String attribute = tagItem.getAttribute(attributeName);
		if (!StringUtils.isEmpty(attribute)) {
			return Boolean.valueOf(attribute);
		} else {
			return defaultValue;
		}
	}

	/**
	 * 获取LOOPTYPE表达式的值，可以设置默认值
	 * 
	 * @param attributeName
	 * @return
	 */
	public LoopType getLoopTypeValue(String attributeName, LoopType defaultLoopType) {
		String attribute = tagItem.getAttribute(attributeName);
		if (!StringUtils.isEmpty(attribute)) {
			if ("noloop".equalsIgnoreCase(attribute)) {
				return LoopType.NOLOOP;
			} else if ("loop".equalsIgnoreCase(attribute)) {
				return LoopType.LOOP;
			} else {
				throw new TemplateException("loopType不支持的值");
			}
		} else {
			return defaultLoopType;
		}
	}

	/**
	 * 获取KEYFUNCTION表达式的值
	 * 
	 * @param attributeName
	 * @return
	 */
	public Object getKeyFunctionValue(String attributeName) {
		String attribute = tagItem.getAttribute(attributeName);
		ExpressionResult expressionResult = ExpressionDefination.PROPERTYVALUE.resolve(this, attribute);
		return expressionResult.getResult();
	}

	/**
	 * 获取KEYFUNCTION表达式的值
	 * 
	 * @param attributeName
	 * @return
	 */
	public String getValueFunctionValue(String attributeName) {
		String attribute = tagItem.getAttribute(attributeName);
		ExpressionResult expressionResult = ExpressionDefination.PROPERTYVALUE.resolve(this, attribute);
		return expressionResult.getStringValue();
	}

	/**
	 * 获得SWITCH的VALUE属性的值
	 * 
	 * @param valueAttribute
	 * @return
	 */
	public boolean getSwitchValue(String attributeName) {
		String attribute = this.getStringValue(attributeName);
		ExpressionResult expressionResult = ExpressionDefination.SWITCH.resolve(this, attribute);
		return expressionResult.getBooleanValue();
	}

	/**
	 * OBJ表达式属性的取值
	 * 
	 * @param obj
	 * @return
	 */
	public TagAware<?> getTagAware(String obj) {
		String awarename = tagItem.getAttribute(obj);
		TagAware<?> tagAware = null;
		if (!StringUtils.isEmpty(awarename)) {
			Settings settings = generatorSession.getSettings();
			if (needCachedTagAware) {
				tagAware = settings.getCachableTagAwares().get(awarename.toUpperCase());
			} else {
				tagAware = settings.getTagAware(awarename.toUpperCase());
			}
		}
		if (tagAware == null) {
			throw new TemplateException("不存在的数据源TagAware,确认obj属性取值（" + awarename + "）是否正确", this);
		}
		return tagAware;
	}

	/**
	 * 解析置标上下文为HTML
	 * 
	 * @param tagContext
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public String parse(TagContext tagContext) {
		return generatorSession.parse(tagContext);
	}

	/**
	 * 是否存在某个属性
	 * 
	 * @param attribute
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public boolean existAttribute(String attribute) {
		return !StringUtils.isEmpty(tagItem.getAttribute(attribute));
	}

	/**
	 * 获取全局系统配置
	 * 
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public Settings getSettings() {
		return generatorSession.getSettings();
	}

	/**
	 * 当前用户是否登录
	 * 
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public boolean isLogined() {
		Settings settings = generatorSession.getSettings();
		CurrentUsernameExtractor currentUsernameExtractor = settings.getCurrentUsernameExtractor();
		return currentUsernameExtractor.isLogin(generatorSession.getRequestWrapper().getRequest());
	}

	/**
	 * 获取外层标签的上下文
	 * 
	 * @return
	 * @since yangyu @ 2013-3-31
	 */
	public TagContext getParentTagContext() {
		return new TagContext(generatorSession, tagItem.getParent());
	}

	/**
	 * 获取最外层Pagelet标签的上下文
	 * 
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public TagContext getPageletTagContext() {
		return pageletTagContext;
	}

	public void setPageletTagContext(TagContext pageletTagContext) {
		this.pageletTagContext = pageletTagContext;
	}

	/**
	 * @param attributeName
	 * @return
	 * @since yangyu @ Apr 1, 2013
	 */
	public String getPageletValue(String attributeName) {
		return pageletTagContext.getTagItem().getAttribute(attributeName);
	}
	
	
	public TagItem getTagItem() {
		return tagItem;
	}

	public void setEntity(PublishObject publishObject) {
		entity = publishObject;
	}

	/**
	 * @return the entity
	 */
	public PublishObject getEntity() {
		return entity;
	}

	/**
	 * @return the generatorSession
	 */
	public GeneratorSession getGeneratorSession() {
		return generatorSession;
	}

	/**
	 * @param tagItem
	 *            the {@link #tagItem} to set
	 */
	public void setTagItem(TagItem tagItem) {
		this.tagItem = tagItem;
	}

	/**
	 * @param generatorSession
	 *            the {@link #generatorSession} to set
	 */
	public void setGeneratorSession(GeneratorSession generatorSession) {
		this.generatorSession = generatorSession;
	}

	/**
	 * @return the {@link #needCachedTagAware}
	 */
	public boolean isNeedCachedTagAware() {
		return needCachedTagAware;
	}

	/**
	 * @param needCachedTagAware
	 *            the {@link #needCachedTagAware} to set
	 */
	public void setNeedCachedTagAware(boolean needCachedTagAware) {
		this.needCachedTagAware = needCachedTagAware;
	}

	/**
	 * @param templateName
	 * @since yangyu @ Aug 8, 2013
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * @return the {@link #templateName}
	 */
	public String getTemplateName() {
		return templateName;
	}

}
