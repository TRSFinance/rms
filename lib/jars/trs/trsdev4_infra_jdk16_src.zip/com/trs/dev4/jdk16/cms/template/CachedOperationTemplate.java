package com.trs.dev4.jdk16.cms.template;

import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.CacheProvider;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.cache.CachedResult;

/**
 * 
 * 职责: 置标组件缓存操作的模板，方便封装相同逻辑
 * 
 */
public class CachedOperationTemplate {
	
	protected static Logger LOG = Logger.getLogger(CachedOperationTemplate.class);
	
	private ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();

	private CacheProvider cacheProvider;

	public Object obtainCachedData(String key, final CachedOperationCallback cachedOperationCallback) {
		return this.obtainCachedData(key, 10, cachedOperationCallback);
	}
	
	public Object obtainCachedData(String key, int expr, final CachedOperationCallback cachedOperationCallback) {
		return this.obtainCachedData(cacheProvider, key, expr, cachedOperationCallback);
	}

	public Object obtainCachedData(CacheProvider cacheProvider, String key,
			final CachedOperationCallback cachedOperationCallback) {
		return this.obtainCachedData(cacheProvider, key, 10, cachedOperationCallback);
	}

	/**
	 * 缓存查询的模板，如果缓存中有数据，从缓存中取得
	 * 
	 * 如果缓存中没有，将调用线程查询数据库逻辑，将结果缓存起来
	 * 
	 * 方便编写 缓存操作代码，避免重复逻辑
	 * 
	 * @param cachedOperationCallback
	 *            回调函数
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public Object obtainCachedData(CacheProvider assignedCacheProvider, String key, int expr,
			final CachedOperationCallback cachedOperationCallback) {
		
		if (assignedCacheProvider == null) {
			assignedCacheProvider = cacheProvider;
		}
		
		CachedResult cachedObject = null;
		rwl.readLock().lock();
		cachedObject = assignedCacheProvider.get(key);
		if (cachedObject.notExist()) {
			rwl.readLock().unlock();
			rwl.writeLock().lock();
			try {
				if (cachedObject.notExist()) {
					Object dbObject = cachedOperationCallback.doTakeCachingData();
					assignedCacheProvider.set(key, dbObject, expr);
					cachedObject = new CachedResult(dbObject);
					if(LOG.isDebugEnabled()){
						LOG.debug("Cached data from database key:" + key);
					}
				}
			} finally {
				rwl.writeLock().unlock();
			}
		} else {
			rwl.readLock().unlock();
		}

		return cachedObject.getResultObject();
	}

	public void setCacheProvider(CacheProvider cacheProvider) {
		this.cacheProvider = cacheProvider;
	}

	/**
	 * @param settings
	 * @since yangyu @ Mar 29, 2013
	 */
	public void setSettings(Settings settings) {
		this.setCacheProvider(settings.getCacheProvider());
	}

}
