package com.trs.dev4.jdk16.cms.tag;

import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

public class LinkGroupTagParser extends ObjectsTagParser implements TagParser {

	@Override
	public String parse(TagContext tagContext) {
		if (tagContext.existAttribute("OBJ")) {
			return super.parse(tagContext);
		} else {
			return TagExpressionHelper.parseInternalTemplate(tagContext, null);
		}
	}
}
