package com.trs.dev4.jdk16.actionlog.impl;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.trs.dev4.jdk16.actionlog.IActionlogManager;
import com.trs.dev4.jdk16.actionlog.LogEnums;
import com.trs.dev4.jdk16.actionlog.annotation.LogMe;
import com.trs.dev4.jdk16.model.IEntity;
import com.trs.dev4.jdk16.utils.ArrayUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 自动拦截Manager层方法以记录操作日志的Handler<br>
 *
 */
@Aspect
@Component
public class ActionlogAspectHandler {

	protected static Logger logger = Logger
			.getLogger(ActionlogAspectHandler.class);
	@Autowired
	private IActionlogManager actionLogManager;

	@Pointcut("execution(* * ..*Service*.*(..))")
	public void service() {
	}

	/**
	 * 切入点：@LogMe注解的方法，其中@LogMe被当成参数处理
	 */
	@Pointcut(value = "@annotation(logme)", argNames = "logme")
	public void annolog(LogMe logme) {
	}

	/**
	 * AOP的Around拦截方式，在原执行逻辑前后介入记录操作日志的逻辑
	 *
	 * @param jointPoint
	 *            被切入点命中的方法
	 * @param logMeAnno
	 *            切入点方法上定义的@LogMe注解
	 * @return 返回原方法正常执行的结果
	 * @throws Throwable
	 * @since liuyou @ 2010-5-23
	 */
	@Around(value = "(service() && annolog(logme))", argNames = "logme")
	public Object aroundAnnoLog(ProceedingJoinPoint jointPoint, LogMe logMeAnno)
			throws Throwable {
		if (logger.isDebugEnabled()) {
			logger.debug("aroundAnnoLog(method:" + jointPoint.getSignature()
					+ " is method signature:"
					+ (jointPoint.getSignature() instanceof MethodSignature)
					+ ",args:" + StringHelper.join(jointPoint.getArgs()));
		}
		if (!checkAccess(jointPoint)) {
			return execute(jointPoint);
		}
		MethodSignature methodSignature = (MethodSignature) jointPoint
				.getSignature();
		Method method = methodSignature.getMethod();
		Object targetObject = findTargetObject(jointPoint, logMeAnno);
		if (targetObject == null) {
			logger.debug("targetObject is null.method:" + method.getName());
			return execute(jointPoint);
		}
		String targetObjectName = targetObject.getClass().getSimpleName()
				.toLowerCase()
				+ ".";
		if (!IEntity.class.isInstance(targetObject)) {
			targetObjectName = "";
		}
		String operationName = logMeAnno.action().getSimpleName().toLowerCase();
		String loggingKey = StringHelper.uncapitalize(targetObjectName)
				+ StringHelper.uncapitalize(operationName);
		Object operator = findOperator(jointPoint, logMeAnno);
		logger.debug("targetobject(" + targetObject + "),operator(" + operator
				+ "),operationName(" + operationName + "),loggingKey("
				+ loggingKey + ").");
		//
		long lStartTime = System.currentTimeMillis();
		Actionlog actionLog = null;
		try {
			actionLog = actionLogManager.createActionlog(operator,
					targetObject, loggingKey, LogEnums.Result.SUCCESS,
					lStartTime, 0, "trsuc");
		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
		}
		if (actionLog == null) {
			logger.error("Execute joinPoint(" + actionLog
					+ ") without actionlog.");
			return execute(jointPoint);
		}
		// 如果actionlog != null的话，执行并记录actionlog；
		try {
			return execute(jointPoint);
		} catch (Throwable tx) {
			logger.error("LOG error:" + tx.getMessage(), tx);
			recordException(tx, actionLog);
			throw tx;
		} finally {
			long lEndTime = System.currentTimeMillis();
			actionLog.setSpentTime(lEndTime - lStartTime);
			recordArguments(jointPoint, actionLog);
			actionLogManager.saveOrUpdate(actionLog);
		}
	}

	/**
	 * @param jointPoint
	 * @param actionLog
	 * @since fangxiang @ Nov 30, 2010
	 */
	void recordArguments(ProceedingJoinPoint jointPoint, Actionlog actionLog) {
		// 参数
		Object[] args = jointPoint.getArgs();
		Object[] logArgs = new Object[] { "", "", "" };
		int index = 0;
		for (Object arg : args) {
			if (IEntity.class.isInstance(arg))
				continue;
			logArgs[index++] = castArgValue(arg);
			if (index >= 3)
				break;
		}
		actionLog.setOperArgs(logArgs);
	}

	/**
	 * @param error
	 * @param actionLog
	 * @since fangxiang @ Nov 30, 2010
	 */
	void recordException(Throwable error, Actionlog actionLog) {
		actionLog.setResult(LogEnums.Result.FAIL);
		String errorMessage = error.getMessage();
		if (errorMessage != null && errorMessage.length() > 2000) {
			errorMessage = StringHelper.adjustLength(errorMessage, 1800);
		}
		actionLog.setErrorMsg(errorMessage);
	}

	/**
	 * 转换特殊参数值为字符串
	 *
	 * @param arg
	 * @return
	 */
	private Object castArgValue(Object arg) {
		Object value = arg;
		if (int[].class.isInstance(arg)) {
			value = StringHelper.join(ArrayUtil.toIntegerArray((int[]) arg));
		} else if (arg.getClass().isArray()) {
			value = StringHelper.join((Object[]) arg);
		}
		return value;
	}

	/**
	 * 执行原方法
	 *
	 * @param jointPoint
	 * @return
	 * @throws Throwable
	 * @since liuyou @ 2010-5-23
	 */
	private Object execute(ProceedingJoinPoint jointPoint) throws Throwable {
		return jointPoint.proceed(jointPoint.getArgs());
	}

	/**
	 * 在上下文中查找IEntity对象，若在参数中没有相应的T的话，通过注解的定义构造一个T
	 *
	 * @param jointPoint
	 *            被切入点命中的方法
	 * @param logMeAnno
	 *            切入点方法上定义的@LogMe注解
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @since liuyou @ 2010-5-23
	 */
	private Object findOperator(JoinPoint jointPoint, LogMe logMeAnno) {
		Object[] args = jointPoint.getArgs();
		int operatorIndex = logMeAnno.operatorIndex();
		if (operatorIndex < args.length && operatorIndex >= 0) {
			logger.debug("LogMe() found operator(" + args[operatorIndex]
					+ ") by index(" + operatorIndex + ").");
			return args[operatorIndex];
		}
		//
		logger.debug("LogMe(" + logMeAnno + ") not found operator by index("
				+ operatorIndex + ").");
		return null;
	}

	/**
	 * 在上下文中查找IEntity对象，若在参数中没有相应的T的话，通过注解的定义构造一个T
	 *
	 * @param jointPoint
	 *            被切入点命中的方法
	 * @param logMeAnno
	 *            切入点方法上定义的@LogMe注解
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @since liuyou @ 2010-5-23
	 */
	private Object findTargetObject(JoinPoint jointPoint, LogMe logMeAnno)
			throws InstantiationException, IllegalAccessException {
		Object[] args = jointPoint.getArgs();
		int targetIndex = logMeAnno.targetIndex();
		if (targetIndex < args.length && targetIndex >= 0) {
			logger.debug("LogMe() found operator(" + args[targetIndex]
					+ ") by index(" + targetIndex + ").");
			return args[targetIndex];
		}
		//
		logger.debug("LogMe(" + logMeAnno + ") not found operator by index("
				+ targetIndex + ").");
		return null;
	}

	/**
	 * 即使进入切入点，但也需要满足一定条件才能执行<br>
	 *
	 * @param jointPoint
	 * @return
	 * @since liuyou @ 2010-5-23
	 */
	boolean checkAccess(JoinPoint jointPoint) {
		if (actionLogManager == null)
			return false;
		if (!(jointPoint.getSignature() instanceof MethodSignature))
			return false;
		return !(jointPoint.getTarget() instanceof IActionlogManager);
	}

}
