package com.trs.dev4.jdk16.cms;

import java.util.List;

import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.cms.bo.Template;
import com.trs.dev4.jdk16.cms.exp.CurrentTemplateNotFoundException;

/**
 * 模板操作统一接口
 * 
 * @author yangyu
 * @since Jan 16, 2013 3:18:18 PM
 */
public interface TemplateManager {

	Template getFormPageLink(PageLink pageLink) throws CurrentTemplateNotFoundException;

	List<Template> listTemplatesUnderSite(Site site);

	Template getBySiteAndTemplateName(String templateName, int siteId);
	
	boolean existTemplate(int siteId, String templateName);

}
