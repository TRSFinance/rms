/*
 * Created: Administrator@2013-12-4 下午01:59:55
 */
package com.trs.dev4.jdk16.cms.tag;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Element;

import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.exp.TemplateException;

/**
 * 职责: <br>
 * 
 */
public class ParserConf {

	protected static Logger LOG = Logger.getLogger(TagDefination.class);

	private String name;

	private TagParser tagParser;

	private Map<String, AttributeConf> attributes = new HashMap<String, AttributeConf>();

	private List<String> mutualAttributes = new ArrayList<String>();

	private List<String> neededParentTags = new ArrayList<String>();

	private boolean allowExtensionAttribute = false;

	private boolean cachable = false;

	/**
	 * @param attributes
	 *            the {@link #attributes} to set
	 */
	public void setAttributes(Map<String, AttributeConf> attributes) {
		this.attributes = attributes;
	}

	/**
	 * @return the {@link #mutualAttributes}
	 */
	public List<String> getMutualAttributes() {
		return mutualAttributes;
	}

	/**
	 * @param mutualAttributes
	 *            the {@link #mutualAttributes} to set
	 */
	public void setMutualAttributes(List<String> mutualAttributes) {
		this.mutualAttributes = mutualAttributes;
	}

	/**
	 * @return the {@link #neededParentTags}
	 */
	public List<String> getNeededParentTags() {
		return neededParentTags;
	}

	/**
	 * @param neededParentTags
	 *            the {@link #neededParentTags} to set
	 */
	public void setNeededParentTags(List<String> neededParentTags) {
		this.neededParentTags = neededParentTags;
	}

	/**
	 * @return the {@link #allowExtensionAttribute}
	 */
	public boolean isAllowExtensionAttribute() {
		return allowExtensionAttribute;
	}

	/**
	 * @param allowExtensionAttribute
	 *            the {@link #allowExtensionAttribute} to set
	 */
	public void setAllowExtensionAttribute(boolean allowExtensionAttribute) {
		this.allowExtensionAttribute = allowExtensionAttribute;
	}

	/**
	 * @return the {@link #name}
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the {@link #name} to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the {@link #tagParser}
	 */
	public TagParser getTagParser() {
		return tagParser;
	}

	/**
	 * @param tagParser
	 *            the {@link #tagParser} to set
	 */
	public void setTagParser(TagParser tagParser) {
		this.tagParser = tagParser;
	}

	/**
	 * @return the {@link #cachable}
	 */
	public boolean isCachable() {
		return cachable;
	}

	/**
	 * @param cachable
	 *            the {@link #cachable} to set
	 */
	public void setCachable(boolean cachable) {
		this.cachable = cachable;
	}

	/**
	 * @param tagParserElement
	 * @return
	 * @since Administrator @ 2013-12-4
	 */
	@SuppressWarnings("unchecked")
	public static ParserConf read(Element tagParserElement) {
		try {
			ParserConf parserConf = new ParserConf();
			parserConf.setName(tagParserElement.attribute("name").getValue());
			TagParser tagParser = (TagParser) Class.forName(tagParserElement.attribute("class").getValue())
					.newInstance();
			parserConf.setTagParser(tagParser);

			if (tagParserElement.attribute("cachable") != null) {
				parserConf.setCachable(Boolean.valueOf(tagParserElement.attributeValue("cachable")));
			}
			if (tagParserElement.attribute("allowExtensionAttribute") != null) {
				parserConf.setAllowExtensionAttribute(Boolean.valueOf(tagParserElement
					.attributeValue("allowExtensionAttribute")));
			}
			if (tagParserElement.attribute("neededParentTags") != null) {
				parserConf.setNeededParentTags(Arrays.asList(StringUtils.split(tagParserElement.attribute(
						"neededParentTags").getValue(), ";")));
			}
			
			if (tagParserElement.attribute("mutualAttributes") != null) {
				parserConf.setMutualAttributes(Arrays.asList(StringUtils.split(tagParserElement.attribute(
						"mutualAttributes").getValue().toUpperCase(), ";")));
			}

			for (Iterator<Element> tagParserIterator = tagParserElement.elementIterator(); tagParserIterator.hasNext();) {
				parserConf.addAttributeConfig(AttributeConf.readAttribute(tagParserIterator.next()));
			}

			return parserConf;
		} catch (Exception e) {
			throw new TemplateException("read tag defination xml fail", e);
		}
	}

	/**
	 * @param readAttribute
	 * @since Administrator @ 2013-12-6
	 */
	private void addAttributeConfig(AttributeConf readAttribute) {
		attributes.put(readAttribute.getName().toUpperCase(), readAttribute);
	}

	/**
	 * @param attribute
	 * @return
	 * @since Administrator @ 2013-12-6
	 */
	public boolean existAttribute(String attribute) {
		return attributes.containsKey(attribute.toUpperCase());
	}

	/**
	 * @return
	 * @since Administrator @ 2013-12-6
	 */
	public List<String> getAttributeNames() {
		List<String> attrs = new ArrayList<String>();
		for (AttributeConf attributeConf : attributes.values()) {
			attrs.add(attributeConf.getName());
		}
		return attrs;
	}

	/**
	 * @return
	 * @since Administrator @ 2013-12-6
	 */
	public Collection<AttributeConf> getAttributeList() {
		return attributes.values();
	}

	/**
	 * @param key
	 * @return
	 * @since Administrator @ 2013-12-6
	 */
	public AttributeConf getAttributeConf(String key) {
		return attributes.get(key.toUpperCase());
	}
}
