/*
 * Created: fangxiang@Dec 19, 2010 10:24:10 PM
 */
package com.trs.dev4.jdk16.session;

import com.trs.dev4.jdk16.exception.BussinessException;

/**
 * 应用会话异常
 * 
 * {@link redirectUrl}定义了发生异常时重定向URL
 */
public class ApplicationSessionException extends BussinessException {

	/**
	 * @param msg
	 */
	public ApplicationSessionException(String msg) {
		super(msg);
	}

	/**
	 * 
	 * @param message
	 * @param redirectUrl
	 */
	public ApplicationSessionException(String message, String redirectUrl) {
		super(message);
		this.redirectUrl = redirectUrl;
	}

	/**
	 *
	 */
	public String redirectUrl;

	/**
	 * @since fangxiang @ Dec 19, 2010
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @return the {@link #redirectUrl}
	 */
	public String getRedirectUrl() {
		return redirectUrl;
	}
}
