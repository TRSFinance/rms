/*
 * Created: liushen@Oct 24, 2009 1:04:12 PM
 */
package com.trs.dev4.jdk16.model;


/**
 * 领域对象的标示性接口.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public interface IEntity extends ISerializableEntity {

	/**
	 * 获取创建时间.
	 * 
	 * @return
	 * @since liushen @ Feb 10, 2010
	 */
	long getCreatedTime();

	/**
	 * 获取最后更新的时间.
	 * 
	 * @return
	 * @since liushen @ Feb 10, 2010
	 */
	long getLastModifiedTime();

	/**
	 * 
	 * @return
	 * @since liushen @ Feb 10, 2010
	 */
	String getCreatedUser();

	/**
	 * 
	 * @return
	 * @since liushen @ Feb 10, 2010
	 */
	String getLastModifiedUser();

}
