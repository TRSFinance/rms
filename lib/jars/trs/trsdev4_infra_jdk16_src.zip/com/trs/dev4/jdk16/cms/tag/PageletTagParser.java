package com.trs.dev4.jdk16.cms.tag;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.trs.dev4.jdk16.cms.CacheProvider;
import com.trs.dev4.jdk16.cms.GeneratorSession;
import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.TemplateManager;
import com.trs.dev4.jdk16.cms.bo.DocumentWrapper;
import com.trs.dev4.jdk16.cms.bo.RequestWrapper;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.bo.TagItem;
import com.trs.dev4.jdk16.cms.bo.Template;
import com.trs.dev4.jdk16.cms.bo.TemplateDocument;
import com.trs.dev4.jdk16.cms.exp.TemplateException;
import com.trs.dev4.jdk16.cms.template.CachedOperationCallback;
import com.trs.dev4.jdk16.cms.template.CachedOperationTemplate;

/**
 * 
 * 职责: TRS_PAGELET标签的解析类<br>
 * 
 */
public class PageletTagParser implements TagParser {

	@Override
	public String parse(final TagContext tagContext) {

		final String templateName = tagContext.getStringValue("templateName");
		String loginedTemlateName = tagContext.getStringValue("loginedTemplateName");

		if (!StringUtils.isEmpty(loginedTemlateName) && tagContext.isLogined()) {
			return parseTemplate(tagContext, loginedTemlateName, true);
		} else if (!StringUtils.isEmpty(templateName)) {
			tagContext.setNeedCachedTagAware(false);
			String key = getPageletCacheKey(tagContext, templateName);
			CacheProvider cacheProvider = tagContext.getGeneratorSession().getCacheProvider();
			CachedOperationTemplate cachedOperationTemplate = tagContext.getSettings().getCachedOperationTemplate();
			int cateTime = tagContext.getIntValue("cacheTime", 30);
			return (String) cachedOperationTemplate.obtainCachedData(cacheProvider, key, cateTime,
					new CachedOperationCallback() {
						@Override
						public Object doTakeCachingData() {
							return parseTemplate(tagContext, templateName, false);
						}
					});
		}
		return "";
	}

	/**
	 * @param tagContext
	 * @param generatorSession
	 * @param tagNodes
	 * @return
	 * @since Administrator @ 2013-11-12
	 */
	private String interpreteDocumentWrapper(final TagContext tagContext, final GeneratorSession generatorSession,
			List<TagItem> tagNodes) {
		StringBuilder content = new StringBuilder();
		for (Iterator<TagItem> iterator = tagNodes.iterator(); iterator.hasNext();) {
			TagItem tagItem = iterator.next();
			TagContext childTagContext = new TagContext(generatorSession, tagItem);
			childTagContext.setPageletTagContext(tagContext);
			childTagContext.setNeedCachedTagAware(tagContext.isNeedCachedTagAware());
			if (tagItem.isTRSTag()) {
				content.append(generatorSession.parse(childTagContext));
			} else {
				content.append(tagItem.getContent());
			}
		}
		return content.toString();
	}

	/**
	 * 构造Pagelet内容之前需要的CSS
	 * 
	 * @param tagContext
	 * @return
	 * @since yangyu @ Jun 25, 2013
	 */
	private String buildCssContent(TagContext tagContext) {
		StringBuilder content = new StringBuilder();
		String cssAttr = tagContext.getStringValue("css");
		if (!StringUtils.isEmpty(cssAttr)) {
			String[] csses = StringUtils.split(cssAttr, ";");
			for (String css : csses) {
				content.append("<link href=\"").append(css).append("\" rel=\"stylesheet\" type=\"text/css\" />");
			}
		}
		return content.toString();
	}

	/**
	 * 根据模板名称获得Pagelet解析后的结果 TODO 需要重构
	 * 
	 * @param tagContext
	 * @param templateName
	 * @return
	 * @since yangyu @ Jun 25, 2013
	 */
	private String parseTemplate(final TagContext tagContext, final String templateName, boolean isLogined) {
		String cssContent = buildCssContent(tagContext);
		final GeneratorSession generatorSession = tagContext.getGeneratorSession();
		final Settings settings = generatorSession.getSettings();
		tagContext.setTemplateName(templateName);
		final int siteId = generatorSession.getSite().getId();

		if (isLogined) {
			String key = getPageletCacheKey(siteId, templateName, generatorSession.getRequestWrapper());
			DocumentWrapper documentWrapper = (DocumentWrapper) settings.getCachedOperationTemplate().obtainCachedData(
					key, 10, new CachedOperationCallback() {
						@Override
						public Object doTakeCachingData() {
							return wrapDocument(generatorSession, settings, templateName, siteId);
						}
					});

			return cssContent + interpreteDocumentWrapper(tagContext, generatorSession, documentWrapper.getTagNodes());
		} else {
			TemplateManager templateManager = tagContext.getSettings().getTemplateManager();
			Template template = templateManager.getBySiteAndTemplateName(templateName, siteId);
			if (template == null) {
				throw new TemplateException("TRS_Pagelet标签的templateName或者loginedTemplateName属性设置有误，找不到对应的模板，当前的属性值为"
						+ templateName, tagContext);
			}
			TemplateDocument templateDocument = new TemplateDocument(template.getContent());
			return cssContent
					+ interpreteDocumentWrapper(tagContext, tagContext.getGeneratorSession(), templateDocument
							.getItems());
		}

	}

	/**
	 * 构造缓存键值
	 * 
	 * @param tagContext
	 * @param templateName2
	 * @return
	 * @since yangyu @ Aug 9, 2013
	 */
	private String getPageletCacheKey(final TagContext tagContext, String templateName) {
		int siteId = tagContext.getGeneratorSession().getSite().getId();
		RequestWrapper requestWrapper = tagContext.getGeneratorSession().getRequestWrapper();
		return getPageletCacheKey(siteId, templateName, requestWrapper);
	}

	/**
	 * 构造Pagelet缓存键值
	 * 
	 * @param siteId
	 * @param templateName
	 * @param requestWrapper
	 * @return
	 * @since yangyu @ Aug 9, 2013
	 */
	private String getPageletCacheKey(int siteId, String templateName, RequestWrapper requestWrapper) {
		String key = new StringBuilder("Pagelet_Site_").append(siteId).append("_Template_").append(templateName)
				.append("_URLPARAMS_").append(requestWrapper.getQueryString()).toString();
		return key;
	}
	
	/**
	 * @param generatorSession
	 * @param settings
	 * @param templateName
	 * @param siteId
	 * @return
	 * @since Administrator @ 2013-11-12
	 */
	private DocumentWrapper wrapDocument(final GeneratorSession generatorSession, final Settings settings,
			final String templateName, final int siteId) {
		TemplateManager templateManager = settings.getTemplateManager();
		Template template = templateManager.getBySiteAndTemplateName(templateName, siteId);
		TemplateDocument templateDocument = new TemplateDocument(template.getContent());
		DocumentWrapper documentWrapper = new DocumentWrapper();

		for (Iterator<TagItem> iterator = templateDocument.getItems().iterator(); iterator.hasNext();) {
			TagItem tagItem = iterator.next();
			if (tagItem.isTextTag()) {
				documentWrapper.addTextNode(tagItem);
			} else if (tagItem.isTRSTag()) {
				documentWrapper.addTRSTag(generatorSession, tagItem);
			}
		}
		return documentWrapper;
	}
}
