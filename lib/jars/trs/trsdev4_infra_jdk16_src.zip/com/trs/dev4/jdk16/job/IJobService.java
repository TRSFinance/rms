/*
 * Created: fangxiang@Jan 27, 2011 9:10:15 AM
 */
package com.trs.dev4.jdk16.job;

import java.util.List;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.IModuleLifecycle;

/**
 * 定时任务的服务
 */
public interface IJobService extends IModuleLifecycle {
	/**
	 * 批量重置任务的执行节点
	 * 
	 * @param jobDetails
	 */
	public void resetExecutorNode(List<JobDetail> jobDetails);

	/**
	 * 重置任务的执行节点
	 * 
	 * @param jobDetail
	 */
	public void resetExecutorNode(JobDetail jobDetail);

	/**
	 * 重新加载任务
	 * 
	 * @since TRS @ Feb 23, 2011
	 */
	public void scheduleJobs();

	/**
	 * 保存或更新执行任务
	 * 
	 * @param jobDetail
	 */
	public void saveOrUpdate(JobDetail jobDetail);

	/**
	 * 列出所有实现IJobExecutor接口的执行器
	 * 
	 * @return
	 */
	public List<String> listExecutorNames();

	/**
	 * 根据名称获得执行器IJobExecutor
	 * 
	 * @param name
	 * @return
	 */
	public IJobExecutor getJobExecutor(String name);

	/**
	 * 删除指定的任务
	 * 
	 * @param jobDetail
	 */
	public void delete(JobDetail jobDetail);

	/**
	 * 获取可执行的任务
	 * 
	 * @return
	 */
	public List<JobDetail> listAllAvailableJobs();

	/**
	 * 获取所有任务
	 * 
	 * @param searchFilter
	 * @return
	 * @since fangxiang @ Jan 27, 2011
	 */
	public PagedList<JobDetail> pagedJobs(SearchFilter searchFilter);

	/**
	 * 计算执行任务总数
	 * 
	 * @return
	 * @since TRS @ Mar 3, 2011
	 */
	public int countJobs();

	/**
	 * 计算执行器数目
	 * 
	 * @return
	 * @since TRS @ Mar 3, 2011
	 */
	public int countExecutors();

	/**
	 * 注册任务执行器
	 * 
	 * @param jobExecutor
	 */
	public void registerExecutor(IJobExecutor jobExecutor);

	/**
	 * 定时任务
	 * 
	 * @param jobDetail
	 * @since TRS @ Feb 23, 2011
	 */
	public void scheduleJob(JobDetail jobDetail);

	/**
	 * 列出所有计划中的任务
	 * 
	 * @return
	 * @since TRS @ Feb 23, 2011
	 */
	public List<JobDetail> listScheduledJobs();

	/**
	 * 判断指定任务名是否存在
	 * 
	 * @param jobName
	 * @return
	 * @since TRS @ Mar 3, 2011
	 */
	public boolean existsJob(String jobName);

	/**
	 * 判断指定任务执行器是否存在
	 * 
	 * @param executorName
	 * @return
	 * @since TRS @ Mar 3, 2011
	 */
	public boolean existsExecutor(String executorName);
}
