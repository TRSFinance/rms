package com.trs.dev4.jdk16.cms.tag;

import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

public class SwitchTagParser implements TagParser {

	@Override
	public String parse(TagContext tagContext) {
		boolean result = tagContext.getSwitchValue("value");
		if (result) {
			return TagExpressionHelper.parseInternalTemplate(tagContext, tagContext.getEntity());
		} else {
			return "";
		}
	}

}
