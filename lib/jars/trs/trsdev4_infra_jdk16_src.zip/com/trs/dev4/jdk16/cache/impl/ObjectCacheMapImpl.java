/*
 * Created: lichuanjiao@2010-4-1 下午02:59:59
 */
package com.trs.dev4.jdk16.cache.impl;

import java.util.Hashtable;
import java.util.Map;

import com.trs.dev4.jdk16.cache.IObjectCache;

/**
 * 职责: 对象缓存器.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class ObjectCacheMapImpl<K, V> implements IObjectCache<K, V> {

	/**
	 * 缓存角色对象，能够通过角色对象获取到其关联的操作项.
	 */
	private Map<K, V> cached = new Hashtable<K, V>();

	/**
	 * @see com.trs.dev4.jdk16.cache.IObjectCache#clear()
	 * @since lichuanjiao @ 2010-4-1
	 */
	@Override
	public void clear() {
		cached.clear();
	}

	/**
	 * @see com.trs.dev4.jdk16.cache.IObjectCache#evict(java.lang.Object)
	 * @since lichuanjiao @ 2010-4-1
	 */
	@Override
	public V evict(K key) {
		return cached.remove(key);
	}

	/**
	 * @see com.trs.dev4.jdk16.cache.IObjectCache#get(java.lang.Object)
	 * @since lichuanjiao @ 2010-4-1
	 */
	@Override
	public V get(K key) {
		return cached.get(key);
	}

	/**
	 * @see com.trs.dev4.jdk16.cache.IObjectCache#put(java.lang.Object,
	 *      java.lang.Object)
	 * @since lichuanjiao @ 2010-4-1
	 */
	@Override
	public void put(K key, V value) {
		cached.put(key, value);
	}

}
