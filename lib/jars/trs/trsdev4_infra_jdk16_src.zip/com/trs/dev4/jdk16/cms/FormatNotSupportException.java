/*
 * Created: yangyu@Dec 10, 2012 4:40:12 PM
 */
package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.exception.BussinessException;

/**
 * 职责: .<br>
 * 
 * @author 北京拓尔思信息技术股份有限公司
 */
public class FormatNotSupportException extends BussinessException {
	/**
	 * @since yangyu @ Oct 9, 2012
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param msg
	 */
	public FormatNotSupportException(String msg) {
		super(msg);
	}
}
