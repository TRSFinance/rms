/*
 * created by TRS @ Jan 21, 2011
 *
 */
package com.trs.dev4.jdk16.cms;

import java.util.Map;

/**
 * 发布服务控制器
 * 
 * @author TRS
 * 
 */
public interface IPublisherServer {

	/**
	 * 一次性发布静态内容
	 * 
	 * @param templateName
	 *            模板名
	 * @param inputObjects
	 *            输入内容
	 * @param outputFile
	 *            输出文件路径
	 * @since TRS@Jan 21, 2011
	 */
	public void publish(String templateName, Map<String, Object> inputObjects,
			String outputFile);

	/**
	 * 定时发布静态内容
	 * 
	 * @param templateName
	 *            模板名
	 * @param contentProvider
	 *            内容获取器
	 * @param parameters
	 *            初始参数，供contentProvider使用
	 * @param duration
	 *            执行间隔
	 * @since fangxiang @ Jan 21, 2011
	 */
	public void publish(String templateName, IContentProvider contentProvider,
			Map<String, Object> parameters, int duration);
}
