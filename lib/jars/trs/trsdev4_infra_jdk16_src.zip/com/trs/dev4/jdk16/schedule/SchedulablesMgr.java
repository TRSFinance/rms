/*
 * Created: liushen@May 5, 2011 12:18:27 AM
 */
package com.trs.dev4.jdk16.schedule;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.exception.ExceptionUtil;
import com.trs.dev4.jdk16.schedule.RunCondition.Type;
import com.trs.dev4.jdk16.utils.ClassUtil;
import com.trs.dev4.jdk16.utils.CollectionUtil;
import com.trs.dev4.jdk16.utils.ObjectUtil;

/**
 * 计划调度管理. <br>
 * 
 */
public class SchedulablesMgr {

	private static final Logger LOG = Logger.getLogger(SchedulablesMgr.class);

	private Map<String, ScheduledExecutorService> schedulerMap = new HashMap<String, ScheduledExecutorService>();

	private List<ScheduleRunner> runners = new ArrayList<ScheduleRunner>();

	/**
	 * @see #start(ISchedulable, RunCondition)
	 * @since liushen @ May 5, 2011
	 */
	public void start(ISchedulable schedulable, int fixedDelaySeconds) {
		start(schedulable, new RunCondition(Type.FIXEDDELAY, fixedDelaySeconds, TimeUnit.SECONDS));
	}

	/**
	 * 以指定的触发条件来启动定时任务；且同类型(即Java类全名相同)的任务只会添加一个。
	 * 
	 * @param schedulable
	 *            定时任务
	 * @param runCondition
	 *            触发条件
	 * @since liushen @ Oct 9, 2012
	 */
	public void start(ISchedulable schedulable, RunCondition runCondition) {
		String key = schedulable.getClass().getName();
		if (schedulerMap.containsKey(key)) {
			return;
		}

		int poolSize = 1;
		int initialDelay = 10;
		ScheduledExecutorService scheduler = SchedulerFactory.newScheduler(ClassUtil.getSimpleName(schedulable), poolSize);
		schedulerMap.put(key, scheduler);
		int fixedDelaySeconds = runCondition.getFixedDelta();
		ScheduleRunner runner = new ScheduleRunner(schedulable, runCondition);
		runners.add(runner);
		TimeUnit timeUnit = runCondition.getTimeUnit();
		if (runCondition.isAtFixedRate()) {
			scheduler.scheduleAtFixedRate(runner, initialDelay, fixedDelaySeconds, timeUnit);
		} else {
			scheduler.scheduleWithFixedDelay(runner, initialDelay, fixedDelaySeconds, timeUnit);
		}
	}

	/**
	 * 停止对给定ISchedulable对象的调度运行。
	 * 
	 * @since liushen @ May 5, 2011
	 */
	public void stop(ISchedulable schedulable) {
		String key = schedulable.getClass().getName();
		ScheduledExecutorService scheduler = schedulerMap.get(key);
		if (scheduler == null) {
			LOG.warn("no such ScheduledExecutorService: " + key);
			return;
		}
		scheduler.shutdown();
		List<Runnable> runnables = scheduler.shutdownNow();
		if (false == CollectionUtil.isEmpty(runnables)) {
			LOG.info("when stop " + key + ", these Runnables never commenced execution: "
					+ CollectionUtil.toString(runnables));
		}

		boolean terminatedOrInterrupted = false;
		final int MAX_TRY_TIME = 5;
		for (int i = 1; ; i++) {
			if (i > MAX_TRY_TIME) {
				LOG.warn("the scheduler still running after awaitTermination " + MAX_TRY_TIME + " time, so ignored.");
				break;
			}

			try {
				terminatedOrInterrupted = scheduler.awaitTermination(1000L, TimeUnit.MILLISECONDS);
				if (terminatedOrInterrupted) {
					LOG.info("the scheduler terminated ok when i=" + i);
					break;
				}
			} catch (InterruptedException e) {
				LOG.info("the scheduler interrupted when i=" + i + " by " + ExceptionUtil.getBrief(e));
				break;
			}
		}

		for (int i = 0; i < runners.size(); i++) {
			ScheduleRunner runner = runners.get(i);
			if (ObjectUtil.equals(key, runner.getSchedulabeClassName())) {
				runners.remove(runner);
				LOG.info("remove runner success: " + runner + " for " + key);
				break;
			}
		}
		schedulerMap.remove(key);
		LOG.info("ScheduledExecutorService stopped: " + key);
	}

	/**
	 * 
	 * 
	 * @since liushen @ May 6, 2011
	 */
	public void stopAll() {
		LOG.info("ready to stop all " + runners.size() + " runners...");
		for (; runners.size() > 0; ) {
			ScheduleRunner runner = runners.get(0);
			stop(runner.getSchedulable());
			if (LOG.isDebugEnabled()) {
				LOG.debug("now remain " + runners.size() + " runners.");
			}
		}
		runners.clear();
		LOG.info("all runners stopped ok.");
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public List<ScheduleRunner> listRunners() {
		return runners;
	}

}