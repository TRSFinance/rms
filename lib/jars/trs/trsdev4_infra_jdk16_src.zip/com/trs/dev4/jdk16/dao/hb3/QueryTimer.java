/*
 * Created: Administrator@Oct 27, 2010 2:46:40 PM
 */
package com.trs.dev4.jdk16.dao.hb3;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.exception.ExceptionUtil;

/**
 * 记录数据库查询及操作的耗时。 <br>
 * 
 */
public class QueryTimer {
	/**
	 *
	 */
	private final static Logger logger = Logger.getLogger(QueryTimer.class);
	/**
	 *
	 */
	private long beginTimeInMillis = System.currentTimeMillis();
	private long timeMS;
	private Class<?> classType;

	/**
	 *
	 */
	public QueryTimer(Class<?> classType) {
		this.classType = classType;
	}

	/**
	 * 重新开始计时。
	 *
	 * @since Administrator @ Oct 25, 2010
	 */
	public void restartWatch() {
		beginTimeInMillis = System.currentTimeMillis();
	}

	/**
	 * 停止计时。
	 *
	 * @since Administrator @ Oct 25, 2010
	 */
	public void stopWatch(SearchFilter searchFilter) {
		stopWatch(searchFilter, (Throwable) null);
	}

	/**
	 * 获取记录的用时，单位为毫秒。
	 * 
	 * @since liushen @ Sep 24, 2014
	 */
	public long getTimeUsedMillis() {
		return timeMS;
	}

	/**
	 *
	 *
	 * @param exception TODO
	 * @since Administrator @ Oct 25, 2010
	 */
	public void stopWatch(SearchFilter searchFilter, Throwable exception) {
		long duration = saveDuration();
		if (isHighRiskSlow(duration)) {
			if (exception != null) {
				logger.warn("(" + this.classType + ")'s SearchFilter(" + searchFilter + ") consumed (" + duration + ") ms!!", exception);
			} else {
				logger.warn("(" + this.classType + ")'s SearchFilter(" + searchFilter + ") consumed (" + duration + ") ms!!", new Exception("Thread-dump"));
			}
			return;
		}
		if (isSlow(duration)) {
			if (logger.isDebugEnabled()) {
			logger.debug("(" + this.classType + ")'s SearchFilter("
					+ searchFilter.toString() + ") consumed (" + duration
					+ ") ms");
			}
		}
	}

	/**
	 *
	 *
	 * @since Administrator @ Oct 25, 2010
	 */
	public void stopWatch(int id) {
		long duration = saveDuration();
		if (isHighRiskSlow(duration)) {
			logger.warn("(" + this.classType + ")'s Get id=(" + id + ") consumed (" + duration + ") ms!!", new Exception("Thread-dump"));
			return;
		}
		if (isSlow(duration)) {
			logger.debug("(" + this.classType + ")'s Get id=(" + id
					+ ") consumed (" + duration + ") ms");
		}
	}

	/**
	 *
	 *
	 * @since Administrator @ Oct 25, 2010
	 */
	public void stopWatch() {
		long duration = saveDuration();
		if (isHighRiskSlow(duration)) {
			logger.warn("(" + this.classType + ")'s listObjects consumed (" + duration + ") ms!!", new Exception("Thread-dump"));
			return;
		}
		if (isSlow(duration)) {
			logger.debug("(" + this.classType + ")'s listObjects consumed ("
					+ duration + ") ms");
		}
	}

	/**
	 *
	 *
	 * @since fangxiang @ Oct 25, 2010
	 */
	public void stopWatch(Object entity, String action) {
		long duration = saveDuration();
		if (isHighRiskSlow(duration)) {
			logger.warn("(" + entity.toString() + ")'s (" + action + ") consumed (" + duration + ") ms!!", new Exception("Thread-dump"));
			return;
		}
		if (isSlow(duration)) {
			logger.debug("(" + entity.toString() + ")'s (" + action
					+ ") consumed (" + duration + ") ms");
		}
	}

	/**
	 *
	 *
	 * @since fangxiang @ Oct 25, 2010
	 */
	public void stopWatch(String statement) {
		long duration = saveDuration();
		if (isHighRiskSlow(duration)) {
			logger.warn("use " + duration + " ms! query: " + statement + ", subStackTrace: " + ExceptionUtil.subStackTraceOnlyForPrefix(new Exception("Thread-dump"), 4, "com.trs"));
			// (class com.trs.bas.bo.core.CalcedVisit)'s execute command(select sum(duration) from CalcedVisit where mpId = 74 and browserName =  'Safari'  and browserVersion =  '5'  and visitTime between '1420560000000' and '1420646400000' and duration > 0) consumed (5900) ms!!
//			logger.warn("(" + this.classType + ")'s execute command(" + statement + ") consumed (" + duration + ") ms!!", new Exception("Thread-dump"));
			return;
		}
		if (isSlow(duration)) {
			logger.debug("(" + this.classType + ")'s execute command("
					+ statement + ") consumed (" + duration + ") ms");
		}
	}

	/**
	 * @return
	 * @since Administrator @ Oct 25, 2010
	 */
	private static boolean isSlow(long duration) {
		return (duration > 1000);
	}

	/**
	 * 
	 * @param duration
	 * @return
	 * @since liushen @ Feb 13, 2012
	 */
	private static boolean isHighRiskSlow(long duration) {
		return (duration >= 5000);
	}

	/**
	 * @return
	 * @since Administrator @ Oct 25, 2010
	 */
	private long saveDuration() {
		timeMS = System.currentTimeMillis() - beginTimeInMillis;
		return timeMS;
	}

}