package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.bo.TagContext;

/**
 * 
 * 职责: 标签解析器的接口，用户解析“<TRS_XXX>”类型的标签为HTML
 * 
 */
public interface TagParser {

	/**
	 * 根据TRS标签的上下文，解析成HTML并返回
	 * 
	 * @param tagContext
	 * @return
	 * @since yangyu @ Apr 11, 2013
	 */
	String parse(TagContext tagContext);

}
