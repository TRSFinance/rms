/*
 * Created:         2005-4-19 17:17:15
 * Last Modified:   2005-4-19/2005-4-19
 * Description:
 *      class TagDocument
 */
package com.trs.dev4.jdk16.cms.bo;

import java.util.ArrayList;
import java.util.List;

import com.trs.dev4.jdk16.cms.core.TemplateDocumentReader;

/**
 * 记录模板解析结果，将文本解析成TRS标签的DOM
 * 
 */
public class TemplateDocument {
	/**
	 * 
	 */
	private List<TagItem> m_items = new ArrayList<TagItem>();

	/**
	 * 根据文本构造DOM树
	 */
	public TemplateDocument(String templateContent) {
		TemplateDocumentReader.read(templateContent, this);
	}

	/**
	 * @IClearable#clear()
	 * 
	 */
	public void clear() {
	}

	/**
	 * @return Returns the item list.
	 */
	public List<TagItem> getItems() {
		return m_items;
	}

	/**
	 * @return Returns size of the items.
	 */
	public int getItemCount() {
		return m_items.size();
	}

	/**
	 * get the item at the specified position.
	 * 
	 * @param _index
	 *            the item index.
	 * @return Returns the item at the position.
	 */
	public TagItem getItemAt(int _index) {
		return m_items.get(_index);
	}

	/**
	 * add a TagItem item
	 * 
	 * @param _item
	 *            a TagItem item.
	 */
	public void addItem(TagItem _item) {
		m_items.add(_item);
	}

	/**
	 * add a string item
	 * 
	 * @param _str
	 *            a string item.
	 */
	public void addItem(String _str) {
		m_items.add(new TagItem(_str));
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName()).append("@").append(Integer.toHexString(hashCode()));
		sb.append(", has " + getItemCount() + " TagItems: ");
		if (m_items != null) {
			for (int i = 0; i < m_items.size(); i++) {
				TagItem obj = m_items.get(i);
				/*
				 * TODO 为了提高效率 应该为类 TagItem 增加方法 appendTo(StringBuffer)�?
				 * 并使用其代替下面�? toString()�?
				 */
				sb.append(obj.toString());
			}
		}
		sb.append(".");
		return sb.toString();
	}

}