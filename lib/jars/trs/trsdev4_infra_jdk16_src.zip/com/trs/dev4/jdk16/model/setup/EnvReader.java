/*
 * Created: liushen@Jul 16, 2012 12:04:56 PM
 */
package com.trs.dev4.jdk16.model.setup;

/**
 * 获取当前安装初始化环境的主要信息。 <br>
 * 
 */
public class EnvReader {

	private String installHomeDir;
	private String webInfDir;
	private String nodeKey;

	/**
	 * @param nodeKey
	 * @param installHomeDir
	 * @param webInfDir
	 */
	protected EnvReader(String nodeKey, String installHomeDir, String webInfDir) {
		this.nodeKey = nodeKey;
		this.installHomeDir = installHomeDir;
		this.webInfDir = webInfDir;
	}

	/**
	 * @return the {@link #installHomeDir}
	 */
	public String getInstallHomeDir() {
		return installHomeDir;
	}

	/**
	 * @return the {@link #webInfDir}
	 */
	public String getWebInfDir() {
		return webInfDir;
	}

	/**
	 * @return the {@link #nodeKey}
	 */
	public String getNodeKey() {
		return nodeKey;
	}

}
