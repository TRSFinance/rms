/*
 * Created: yangyu@Jun 5, 2013 1:57:53 PM
 */
package com.trs.dev4.jdk16.cms.enu;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import com.trs.dev4.jdk16.cms.bo.ExpressionResult;
import com.trs.dev4.jdk16.cms.bo.ValidateContext;

/**
 * 职责: 区分表达式解析结果的类型
 * 
 * 例如 'param.name'是字符串类型，param.id是int类型，(1,2,3,4)是int类型数组类型，('aaa','bbb','ccc')是Str ing 数 组 类 型
 * 
 */
public enum ExpressionType {

	STRING {
		@Override
		public ExpressionResult getConvertedValue(String value) {
			String resolvedValue = StringUtils.substringBetween(value, "'", "'");
			ExpressionResult expressionResult = new ExpressionResult(ExpressionType.STRING, resolvedValue);
			return expressionResult;
		}

		@Override
		public String getNoTypeValue(String value) {
			return StringUtils.substringBetween(value, "'", "'");
		}

		@Override
		public boolean canUseFunction() {
			return true;
		}

		@Override
		public void validate(ValidateContext validateContext, Class<?> type, String key) {
			if (!type.getSimpleName().equalsIgnoreCase("String")) {
				validateContext.addError(key + "属性值不正确，条件表达式构建不正确，前后类型不匹配");
			}
		}
	},
	ARRAYSTRING {
		@Override
		public ExpressionResult getConvertedValue(String value) {

			String[] stringValueArray = StringUtils.split(StringUtils.replace(StringUtils.substringBetween(value, "(", ")"), "'", ""), ",");
			return new ExpressionResult(ExpressionType.ARRAYSTRING, stringValueArray);
		}

		@Override
		public String getNoTypeValue(String value) {
			return value;
		}

		@Override
		public boolean canUseFunction() {
			return false;
		}
	},
	ARRAYINT {
		@Override
		public ExpressionResult getConvertedValue(String value) {
			String[] stringValueArray = StringUtils.split(StringUtils.substringBetween(value, "(", ")"), ",");
			int[] valueArray = new int[] {};
			for (String stringValue : stringValueArray) {
				valueArray = ArrayUtils.add(valueArray, NumberUtils.toInt(stringValue));
			}
			return new ExpressionResult(ExpressionType.ARRAYINT, valueArray);
		}

		@Override
		public String getNoTypeValue(String value) {
			return value;
		}

		@Override
		public boolean canUseFunction() {
			return false;
		}

	},
	INT {
		@Override
		public ExpressionResult getConvertedValue(String value) {
			return new ExpressionResult(ExpressionType.INT, NumberUtils.toInt(value));
		}

		@Override
		public String getNoTypeValue(String value) {
			return value;
		}

		@Override
		public boolean canUseFunction() {
			return true;
		}

	},
	BOOLEAN {
		@Override
		public ExpressionResult getConvertedValue(String value) {
			return new ExpressionResult(ExpressionType.BOOLEAN, Boolean.valueOf(value));
		}

		@Override
		public String getNoTypeValue(String value) {
			return value;
		}

		@Override
		public boolean canUseFunction() {
			return true;
		}

	},
	/**
	 * 没有明显的标记类型如INT、BOOLEAN，有标记类型的如'param.name'表示STRING，(1,2,3)表示ARRAYINT
	 */
	NOTYPEMARK {
		@Override
		public ExpressionResult getConvertedValue(String value) {
			return new ExpressionResult(ExpressionType.NOTYPEMARK, value);
		}

		@Override
		public String getNoTypeValue(String value) {
			return value;
		}

		@Override
		public boolean canUseFunction() {
			return true;
		}

	},
	UNDEFINED {

		@Override
		public boolean canUseFunction() {
			return false;
		}

		@Override
		public ExpressionResult getConvertedValue(String value) {
			return new ExpressionResult(value);
		}

		@Override
		public String getNoTypeValue(String value) {
			return value;
		}

	},
	KEY {

		@Override
		public boolean canUseFunction() {
			return false;
		}

		@Override
		public ExpressionResult getConvertedValue(String value) {
			return new ExpressionResult(value);
		}

		@Override
		public String getNoTypeValue(String value) {
			return value;
		}
		
	}
	;

	/**
	 * @param value
	 * @since yangyu @ Jun 5, 2013
	 */
	public static ExpressionType resolveType(String attributeValue) {
		if (attributeValue.startsWith("'") && attributeValue.endsWith("'")) {
			return ExpressionType.STRING;
		}
		if (attributeValue.startsWith("(") && attributeValue.endsWith("")) {
			return ExpressionType.ARRAYINT;
		}
		if (attributeValue.startsWith("('") && attributeValue.endsWith("')")) {
			return ExpressionType.ARRAYSTRING;
		}
		return ExpressionType.NOTYPEMARK;
	}

	/**
	 * @param value
	 * @return
	 * @since yangyu @ Jun 5, 2013
	 */
	public abstract String getNoTypeValue(String value);

	/**
	 * @return
	 * @since yangyu @ Jun 6, 2013
	 */
	public abstract ExpressionResult getConvertedValue(String value);

	/**
	 * @return
	 * @since yangyu @ Jun 6, 2013
	 */
	public abstract boolean canUseFunction();

	/**
	 * 将字符串结果转换成ExpressionResult，为没有类型的结果判断类型
	 * 
	 * @param expressionType
	 *            已判断的类型
	 * @param functionedValue
	 *            函数解析后的值的字符形式
	 * @return
	 * @since yangyu @ Jun 6, 2013
	 */
	public static ExpressionResult packingStringValueToResult(ExpressionType expressionType, String functionedValue) {
		if (ExpressionType.STRING.equals(expressionType)) {
			return new ExpressionResult(STRING, functionedValue);
		} else if (StringUtils.isNumeric(functionedValue)) {
			return ExpressionType.INT.getConvertedValue(functionedValue);
		} else if ("true".equalsIgnoreCase(functionedValue) || "false".equalsIgnoreCase(functionedValue)) {
			return ExpressionType.BOOLEAN.getConvertedValue(functionedValue);
		} 
		return new ExpressionResult(ExpressionType.UNDEFINED, functionedValue);
	}

	/**
	 * @param validateContext
	 * @param type
	 * @param key2
	 * @since yangyu @ Jul 10, 2013
	 */
	public void validate(ValidateContext validateContext, Class<?> type, String key) {

	}

}
