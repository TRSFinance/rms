/*
 * Created: liushen@Sep 24, 2014 1:59:00 PM
 */
package com.trs.dev4.jdk16.dao;

import java.util.List;

/**
 * 包括查询耗时等度量信息的分页结果集。<br>
 */
public class MetricPagedList<T> extends PagedList<T> {

	private static final long serialVersionUID = 1L;

	private long timeUsedMS;

	/**
	 * @see PagedList#PagedList(int, int, int, List, int)
	 * @param timeUsedMS
	 *            查询耗时
	 */
	public MetricPagedList(List<T> pageItems, int pageIndex, int pageSize, int totalItemCount, long timeUsedMS) {
		super(pageItems, pageIndex, pageSize, totalItemCount);

		this.timeUsedMS = timeUsedMS;
	}

	/**
	 * @return the {@link #timeUsedMS}
	 */
	public long getTimeUsedMS() {
		return timeUsedMS;
	}

	/**
	 * @param timeUsedMS
	 *            the {@link #timeUsedMS} to set
	 */
	public void setTimeUsedMS(long timeUsedMS) {
		this.timeUsedMS = timeUsedMS;
	}

}
