package com.trs.dev4.jdk16.cms;

import java.io.PrintWriter;

import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.cms.bo.RequestWrapper;
import com.trs.dev4.jdk16.cms.bo.Settings;
import com.trs.dev4.jdk16.cms.bo.Site;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.enu.InterpreterType;

/**
 * 
 * 职责: 与每个Request请求线程相对应的会话，保存请求中的过程参数，包括当前站点，当前映射，Request封装
 * 
 */
public interface GeneratorSession {

	/**
	 * 请求模板解析为HTML
	 * 
	 * @since yangyu @ Apr 12, 2013
	 */
	void responseGeneratedHTML();

	/**
	 * 绑定会话的参数
	 * 
	 * @param settings
	 * @param site
	 * @param pageLink
	 * @param requestWrapper
	 * @param writer
	 * @since yangyu @ Apr 12, 2013
	 */
	void bind(Settings settings, Site site, PageLink pageLink, RequestWrapper requestWrapper, PrintWriter writer);

	/**
	 * 获取组件全局配置
	 * 
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	Settings getSettings();

	/**
	 * 获取当前站点
	 * 
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	Site getSite();

	/**
	 * 获取当前映射
	 * 
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	PageLink getPageLink();

	/**
	 * 获取Request封装
	 * 
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	RequestWrapper getRequestWrapper();

	/**
	 * 解析模板上下文
	 * 
	 * @param tagContext
	 * @return
	 * @since yangyu @ Apr 12, 2013
	 */
	public String parse(TagContext tagContext);

	/**
	 * 指定模板的解析方式
	 * 
	 * @param common
	 * @since yangyu @ May 17, 2013
	 */
	void setAssignedContentGeneratorType(InterpreterType common);

	/**
	 * 指定解析所需的缓存
	 * 
	 * @param noCacheProvider
	 * @since yangyu @ May 17, 2013
	 */
	void setAssignedCacheProvider(CacheProvider cacheProvider);

	/**
	 * 绑定参数
	 * 
	 * @param site
	 * @param emptyPageLink
	 * @param requestWrapper
	 * @param printWriter
	 * @since yangyu @ May 17, 2013
	 */
	void bind(Site site, PageLink pageLink, RequestWrapper requestWrapper, PrintWriter printWriter);

	/**
	 * 指定解析会话要解析的模板
	 * 
	 * @param content
	 * @since yangyu @ May 17, 2013
	 */
	void setAssignedParsedContent(String content);

	/**
	 * 设置解析过程不需要压缩
	 * 
	 * @param neetNotCompress
	 * @since yangyu @ Aug 12, 2013
	 */
	public void setNeetNotCompress(boolean neetNotCompress);

	/**
	 * 获取模板要解析的模板内容
	 * 
	 * @return
	 * @since yangyu @ Aug 8, 2013
	 */
	public String getAssignedContent();

	/**
	 * 获取该会话要使用的缓存
	 * 
	 * @return
	 * @since yangyu @ Aug 8, 2013
	 */
	public CacheProvider getAssignedCacheProvider();

	/**
	 * 清理线程数据
	 * 
	 * @since yangyu @ May 28, 2013
	 */
	void clear();

	/**
	 * 获得本次解析流程使用的CacheProvider
	 * 
	 * @return
	 * @since yangyu @ Aug 7, 2013
	 */
	CacheProvider getCacheProvider();

	/**
	 * 获取本次解析用的ContentGenerator
	 * 
	 * @return
	 * @since yangyu @ Aug 8, 2013
	 */
	InterpreterType getInterpreterType();

	/**
	 * 获取要解析的内容
	 * 
	 * @param generatorSession
	 * @param settings
	 * @return
	 * @since yangyu @ Aug 7, 2013
	 */
	public String getParsedContent(GeneratorSession generatorSession, Settings settings);

	/**
	 * 获取PrintWriter
	 * 
	 * @return
	 * @since yangyu @ Aug 8, 2013
	 */
	PrintWriter getPrintWriter();

	/**
	 * 压缩并输出结果
	 * 
	 * @param content
	 * @since yangyu @ Aug 8, 2013
	 */
	public void flushContent(String content);

}
