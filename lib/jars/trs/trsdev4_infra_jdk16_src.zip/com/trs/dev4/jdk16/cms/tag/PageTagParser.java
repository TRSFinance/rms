package com.trs.dev4.jdk16.cms.tag;

import org.apache.commons.lang.StringUtils;

import com.trs.dev4.jdk16.cms.TagParser;
import com.trs.dev4.jdk16.cms.bo.PublishObject;
import com.trs.dev4.jdk16.cms.bo.TagContext;
import com.trs.dev4.jdk16.cms.util.TagExpressionHelper;

public class PageTagParser implements TagParser {

	@Override
	public String parse(TagContext tagContext) {

		PublishObject entity = tagContext.getEntity();

		int pageSize = entity.getPropertyAsInt(tagContext, "pageSize");
		int totalPage = entity.getPropertyAsInt(tagContext, "pageTotal");
		int currentPage = entity.getPropertyAsInt(tagContext, "pageIndex") + 1;
		int total = entity.getPropertyAsInt(tagContext, "totalItemCount");
		int pageNum = entity.getPropertyAsInt(tagContext, "pageTotal") == 0 ? 1 : entity.getPropertyAsInt(tagContext, "pageTotal");
		int prevPage = entity.getPropertyAsInt(tagContext, "prevPage") + 1;
		int nextPage = entity.getPropertyAsInt(tagContext, "nextPage") + 1;
		int startPage = entity.getPropertyAsInt(tagContext, "startPage") + 1;
		int endPage = entity.getPropertyAsInt(tagContext, "endPage") + 1;

		String usedFirst = tagContext.getStringValue("first");
		String usedPrev = tagContext.getStringValue("prev");
		String usedNext = tagContext.getStringValue("next");
		String usedLast = tagContext.getStringValue("last");
		String usedTotal = tagContext.getStringValue("total");
		String usedTotalPage = tagContext.getStringValue("totalPage");
		String usedPageSize = tagContext.getStringValue("pageSize");
		String usedCurrent = tagContext.getStringValue("current");
		String defaultClass = tagContext.getStringValue("defaultClass");
		String currentClass = tagContext.getStringValue("currentClass");
		String currentStyle = tagContext.getStringValue("currentStyle");
		boolean hasNumber = tagContext.getBooleanValue("number", false);

		String urlPattern = TagExpressionHelper.buildUrlPattern(tagContext);

		StringBuilder sb = new StringBuilder();
		// 首页
		if (StringUtils.isNotEmpty(usedFirst) && currentPage != 1) {
			buildPage(urlPattern, sb, usedFirst, 1, defaultClass, currentStyle);
		}
		// 上一页
		if (StringUtils.isNotEmpty(usedPrev) && currentPage != 1) {
			buildPage(urlPattern, sb, usedPrev, prevPage, defaultClass, currentStyle);
		}

		if (hasNumber) {
			// 数字
			for (int i = startPage; i <= endPage; i++) {
				if (i == currentPage) {
					buildPage(urlPattern, sb, String.valueOf(i), i, currentClass, currentStyle, true);
					continue;
				}
				buildPage(urlPattern, sb, String.valueOf(i), i, defaultClass, currentStyle);
			}
		}

		// 下一页
		if (StringUtils.isNotEmpty(usedNext) && currentPage != pageNum) {
			buildPage(urlPattern, sb, usedNext, nextPage, defaultClass, currentStyle);
		}

		// 尾页
		if (StringUtils.isNotEmpty(usedLast) && currentPage != pageNum) {
			buildPage(urlPattern, sb, usedLast, pageNum, defaultClass, currentStyle);
		}

		// 总记录数
		if (StringUtils.isNotEmpty(usedTotal)) {
			sb.append(usedTotal.replace("$", total + ""));
		}

		// 总页数
		if (StringUtils.isNotEmpty(usedTotalPage)) {
			sb.append(usedTotalPage.replace("$", totalPage + ""));
		}

		// 每页容量
		if (StringUtils.isNotEmpty(usedPageSize)) {
			sb.append(usedPageSize.replace("$", pageSize + ""));
		}

		// 当前页码
		if (StringUtils.isNotEmpty(usedCurrent)) {
			sb.append(usedCurrent.replace("$", currentPage + ""));
		}

		return sb.toString();

	}

	/**
	 * @param urlPattern
	 * @param sb
	 * @param valueOf
	 * @param i
	 * @param currentClass
	 * @param currentStyle
	 * @param b
	 * @since yangyu @ Jun 28, 2012
	 */
	private void buildPage(String urlPattern, StringBuilder sb, String title, int i, String currentClass, String currentStyle, boolean b) {
		if (StringUtils.isEmpty(currentStyle)) {
			buildDefaultPage(urlPattern, sb, title, i, currentClass, b);
		} else if (currentStyle.equalsIgnoreCase("span")) {
			buildSpanPage(urlPattern, sb, title, i, currentClass, b);
		}

	}

	private void buildPage(String urlPattern, StringBuilder sb, String title, int i, String defaultClass, String currentStyle) {
		if (StringUtils.isEmpty(currentStyle)) {
			buildDefaultPage(urlPattern, sb, title, i, defaultClass, false);
		} else if (currentStyle.equalsIgnoreCase("span")) {
			buildSpanPage(urlPattern, sb, title, i, defaultClass, false);
		}
	}

	/**
	 * @param urlPattern
	 * @param sb
	 * @param title
	 * @param i
	 * @param defaultClass
	 * @param b
	 * @since yangyu @ Jun 28, 2012
	 */
	private void buildSpanPage(String urlPattern, StringBuilder sb, String title, int i, String defaultClass, boolean isCurrent) {

		if (isCurrent) {
			sb.append("<span");
			if (!StringUtils.isEmpty(defaultClass)) {
				sb.append(" class='").append(defaultClass).append("'");
			}
			sb.append("'>").append(title).append("</span> ");
		} else {
			sb.append("<a href='");
			sb.append(urlPattern);

			if (urlPattern.contains("?")) {
				sb.append("&pageNo=").append(i);
			} else {
				sb.append("?pageNo=").append(i);
			}
			sb.append("'>").append(title).append("</a> ");
		}

	}

	private void buildDefaultPage(String urlPattern, StringBuilder sb, String title, int i, String defaultClass, boolean isCurrent) {
		if (isCurrent) {
			sb.append("<a");
			if (!StringUtils.isEmpty(defaultClass)) {
				sb.append(" class='").append(defaultClass).append("'");
			}
			sb.append(">").append(title).append("</a> ");
		} else {
			sb.append("<a href='");
			sb.append(urlPattern);

			if (urlPattern.contains("?")) {
				sb.append("&pageNo=").append(i);
			} else {
				sb.append("?pageNo=").append(i);
			}
			sb.append("'>").append(title).append("</a> ");
		}
	}

}
