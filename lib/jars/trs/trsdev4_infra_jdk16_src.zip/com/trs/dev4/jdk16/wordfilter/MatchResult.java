/**
 * MatchResult.java created on 2006-9-20 10:35:13 by <a href="liukaixuan@gmail.com">liu kaixuan</a>
 */
package com.trs.dev4.jdk16.wordfilter;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 
 * 匹配结果
 * 
 * @author liu kaixuan
 * @date 2006-9-20 10:35:13
 */
public class MatchResult {

	private String wordSep;

	public MatchResult() {
	}

	public MatchResult(List<Word> matchedFilterWords, String markedContent,
			String matchedContentList, String wordSep) {
		this.matchedFilterWords = matchedFilterWords;
		this.markedContent = markedContent;
		this.matchedContentList = matchedContentList;
		this.wordSep = wordSep;
	}

	public MatchResult(List<Word> matchedFilterWords, String markedContent, String matchedContentList, String wordSep, List<Word> matchedFuzzyWords) {
		this.matchedFilterWords = matchedFilterWords;
		this.markedContent = markedContent;
		this.matchedContentList = matchedContentList;
		this.wordSep = wordSep;
		this.matchedFuzzyWords = matchedFuzzyWords;
	}

	
	/** 成功匹配的过滤词 */
	private List<Word> matchedFilterWords;
	
	/** 成功匹配的模糊过滤词 */
	private List<Word> matchedFuzzyWords;

	/** 标记以后的内容 */
	private String markedContent;

	/** 匹配到的内容组成的字符串列表 */
	private String matchedContentList;
	
	/**
	 * 将发现的过滤词列表进行Distinct处理，同时统计每个词的出现次数
	 * 
	 * @return 返回Map<Word, 出现次数> 包含 Distinct 处理后的过滤词列表以及相应的出现次数
	 */
	public Map<Word, Integer> getGroupedMatchedFilterWords() {
		Map<Word, Integer> count = new HashMap<Word, Integer>();
		for (Iterator<Word> it = matchedFilterWords.iterator(); it.hasNext();) {
			Object obj = it.next();
			Integer c = (count.get(obj));
			if (c == null) {
				count.put((Word) obj, new Integer(1));
			} else {
				count.put((Word) obj, new Integer(c.intValue() + 1));
			}
		}
		return count;
	}

	/**
	 * 返回得到的过滤词中最高警告级别
	 * 
	 * @return 最高警告级别
	 */
	public int getHighestLevel() {
		int level = 0;
		for (Iterator<Word> iter = matchedFilterWords.iterator(); iter
				.hasNext();) {
			Word element = iter.next();
			int iLevel = element.getLevel();
			if (iLevel > level)
				level = iLevel;
		}

		return level;
	}

	/** 是否可以通过给定的过滤词等级 */
	public boolean canPass(int level) {
		return getHighestLevel() < level;
	}

	public String getMarkedContent() {
		return markedContent;
	}

	public void setMarkedContent(String markedContent) {
		this.markedContent = markedContent;
	}

	public List<Word> getMatchedFilterWords() {
		return matchedFilterWords;
	}

	public void setMatchedFilterWords(List<Word> matchedWords) {
		this.matchedFilterWords = matchedWords;
	}

	public String getMatchedContentList() {
		return matchedContentList;
	}

	/**
	 * 返回匹配的过滤词列表。方法会自动删除重复的过滤词，并且将返回字符串长度限制在@param maxLength范围内。
	 */
	public String getMatchedContentList(int maxLength) {
		if (matchedContentList == null
				|| matchedContentList.length() <= maxLength)
			return matchedContentList;

		// 过滤词长度太长，压缩过滤词，将重复的删掉。
		Map<Word, Integer> words = getGroupedMatchedFilterWords();
		Iterator<Word> i = words.keySet().iterator();
		StringBuffer sb = new StringBuffer(maxLength + 100);

		boolean meet = false;
		while (i.hasNext()) {
			if (meet) {
				sb.append(wordSep);
			} else {
				meet = true;
			}
			sb.append(i.next().getWord());
		}

		if (sb.length() > maxLength) { // 还是超
			sb.setLength(maxLength);
		}

		return sb.toString();
	}

	public void setMatchedContentList(String wordsListString) {
		this.matchedContentList = wordsListString;
	}

	public String getWordSep() {
		return wordSep;
	}

	public void setWordSep(String wordSep) {
		this.wordSep = wordSep;
	}

	/**
	 * @return the {@link #matchedFuzzyWords}
	 */
	public List<Word> getMatchedFuzzyWords() {
		return matchedFuzzyWords;
	}

	/**
	 * @param matchedFuzzyWords
	 *            the {@link #matchedFuzzyWords} to set
	 */
	public void setMatchedFuzzyWords(List<Word> matchedFuzzyWords) {
		this.matchedFuzzyWords = matchedFuzzyWords;
	}

}
