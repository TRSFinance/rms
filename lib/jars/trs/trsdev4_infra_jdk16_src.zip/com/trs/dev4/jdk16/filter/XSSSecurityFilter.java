/*
 * Created: shenhaiwen@2014-5-25 上午11:04:33
 */
package com.trs.dev4.jdk16.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.xss.AntiXSSRequest;

/**
 * 职责: 预防XSS攻击安全过滤的Filter<br>
 * 
 */
public class XSSSecurityFilter implements Filter {

	private List ignorePaths = new ArrayList();

	/**
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 * @since shenhaiwen @ 2014-5-25
	 */
	@Override
	public void init(FilterConfig fc) throws ServletException {
		String ignoreServlvetPathStr = fc.getInitParameter("ignorePaths");
		ignorePaths = StringHelper.splitToList(ignoreServlvetPathStr, ";");

	}

	/**
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse,
	 *      javax.servlet.FilterChain)
	 * @since shenhaiwen @ 2014-5-25
	 */
	@Override
	public void doFilter(ServletRequest srq, ServletResponse srsp, FilterChain fc) throws IOException,
			ServletException {
		HttpServletRequest request = (HttpServletRequest) srq;
		HttpServletResponse response = (HttpServletResponse) srsp;
		// 对于需要过滤的URL，传递给目标servlet或jsp的实际上时包装器对象的引用
		response.addHeader("X-XSS-Protection", "1; mode=block");
		request = new AntiXSSRequest(request, ignorePaths);
		fc.doFilter(request, response);
	}


	/**
	 * @see javax.servlet.Filter#destroy()
	 * @since shenhaiwen @ 2014-5-25
	 */
	@Override
	public void destroy() {
		// TODO shenhaiwen@2014-5-25 上午11:05:03: Auto-generated method stub

	}

}
