/*
 * Created: liushen@Dec 1, 2008 3:24:47 PM
 */
package com.trs.dev4.jdk16.servlet24;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.utils.CloseUtil;
import com.trs.dev4.jdk16.utils.FileUtil;
import com.trs.dev4.jdk16.utils.IOUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * HTTP响应工具类.<br>
 * 
 * @author TRS信息技术有限公司
 */
public class ResponseUtil {
	/**
	 *
	 */
	private final static Logger LOG = Logger.getLogger(ResponseUtil.class);

	/**
	 * 构造函数私有.
	 */
	protected ResponseUtil() {
	}

	/**
	 * 给HTTP响应头添加清空缓存标记.
	 */
	public static void clearCache(HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache");
		response.addHeader("Cache-Control", "no-store"); // FireFox
		response.setHeader("Pragma", "no-cache"); // HTTP 1.0
		response.setDateHeader("Expires", -1);
		response.setDateHeader("max-age", 0);
	}

	/**
	 * 给HTTP响应头中, 设置缓存时间.
	 * 
	 * @param ms
	 *            缓存时间(毫秒).
	 */
	public static void setCacheExpire(HttpServletResponse response, long ms) {
		long curTime = System.currentTimeMillis();
		response.setDateHeader("Last-Modified", curTime);
		response.setDateHeader("Expires", curTime + ms);
	}

	/**
	 * 下载缓冲的字符串内容，仅适用于较小的临时内容。
	 * 
	 * @param response
	 *            HTTP响应
	 * @param fileName
	 *            显示给客户端的文件名
	 * @param text
	 *            要下载的临时内容
	 * @throws IOException
	 * @creator changpeng @ 2009-5-19
	 */
	public static void download(HttpServletResponse response, String fileName,
			String text) throws IOException {
		response.setContentType("application/x-download");
		response.setHeader("Content-Disposition", "attachment; filename="
				+ fileName);
		response.setCharacterEncoding("UTF-8");
		response.setHeader("Content_Length", StringHelper.int2String(text
				.length()));
		response.getWriter().write(text);
	}

	/**
	 * 以二进制流的方式下载文件。
	 * 
	 * @param response
	 *            HTTP响应
	 * @param fileName
	 *            显示给客户端的文件名
	 * @param file
	 *            要下载的文件
	 * @throws IOException
	 * @since liushen @ Mar 15, 2010
	 */
	public static void download(HttpServletResponse response, String fileName,
			File file) throws IOException {
		FileUtil.assertFileCanRead(file);
		response.setContentType("application/x-download");
		response.setHeader("Content-Disposition", "attachment; filename="
				+ fileName);
		// TODO: liushen@Mar 15, 2010: 1)大于2G如何处理; 2)文件名编码
		response.setContentLength((int) file.length());

		OutputStream os = response.getOutputStream();
		IOUtil.copy(file, os);
	}

	/**
	 * 返回Json格式的字符串
	 * 
	 * @param response
	 *            HTTP响应
	 * @param json
	 *            返回给客户端的JSON数据
	 * @throws IOException
	 * @since fangxiang @ May 31, 2010
	 */
	public static void json(HttpServletResponse response, String json)
			throws IOException {
		response(response, json, "utf-8", "text/html");
	}

	/**
	 * 返回正文内容
	 * 
	 * @param response
	 * @param text
	 * @throws IOException
	 * @since fangxiang @ Oct 19, 2010
	 */
	public static void response(HttpServletResponse response, String textPlain)
			throws IOException {
		response(response, textPlain, "utf-8", "text/html");
	}

	/**
	 * 将给定的文本内容(字符串)返回给客户端.
	 * 
	 * @param response
	 * @param textPlain
	 * @param encoding
	 *            编码；为<code>null</code>则不设置.
	 * @param contentType
	 *            内容类型；为<code>null</code>则设置为默认值( <code>text/plain</code>).
	 * @throws IOException
	 * @since liushen @ Mar 3, 2011
	 */
	public static void response(HttpServletResponse response, String textPlain,
			String encoding, String contentType) throws IOException {
		if (contentType != null) {
			response.setContentType(contentType);
		} else {
			response.setContentType("text/plain");
		}
		if (encoding != null) {
			response.setCharacterEncoding(encoding);
		}
		// liushen@Mar 31, 2011: 不能设置setContentLength头, 否则在包含中文时浏览器可能收不全!
		// 见JIRA TRSMAS-478
		response.getWriter().write(textPlain);
		response.flushBuffer();
	}

	/**
	 * 重定向
	 * 
	 * @param response
	 * @param redirectUrl
	 * @throws IOException
	 * @since TRS @ Feb 14, 2012
	 */
	public static void redirect(HttpServletResponse response, String redirectUrl) throws IOException {
		response.sendRedirect(redirectUrl);
	}

	/**
	 * 将文件内容以流的方式返回给浏览器
	 * 
	 * @param response
	 *            返回
	 * @param contentType
	 *            类型
	 * @param file
	 *            文件
	 * @since TRS @ Jan 29, 2011
	 */
	public static void responseStream(HttpServletResponse response,
			String contentType, File file) {
		if (!file.exists()) {
			try {
				response.sendError(404, "File(" + file.getAbsolutePath()
						+ ") not found!");
			} catch (IOException e) {
				LOG.error("File not found!" + e.getMessage(), e);
			}
			return;
		}
		response.setContentType(contentType);
		//
		FileInputStream in = null;
		OutputStream out = null;
		try {
			response.setContentLength((int) file.length());
			in = new FileInputStream(file);
			out = response.getOutputStream();
			int count = 0;
			byte[] buf = new byte[4096];
			while ((count = in.read(buf)) >= 0) {
				out.write(buf, 0, count);
			}
			out.flush();
		} catch (Exception e) {
			LOG.error("File get fail!" + e.getMessage(), e);
		} finally {
			CloseUtil.closeInputStream(in);
			CloseUtil.closeOutputStream(out);
		}
	}
}
