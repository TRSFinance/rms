/*
 * Created: zhangshi@2011-6-23 下午06:45:56
 */
package com.trs.dev4.jdk16.job.impl;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.trs.dev4.jdk16.job.EJobDetailStatus;
import com.trs.dev4.jdk16.job.IJobExecutor;
import com.trs.dev4.jdk16.job.JobDetail;

/**
 * 职责: <br>
 * 
 */
public class QuartzJob implements Job {
	
	private Logger logger = Logger.getLogger(QuartzJob.class);

	/**
	 * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
	 * @since zhangshi @ 2011-6-23
	 */
	@Override
	public void execute(JobExecutionContext jobContext)
			throws JobExecutionException {
		JobDataMap jobDataMap = new JobDataMap();
		try {
			jobDataMap = jobContext.getJobDetail().getJobDataMap();
		} catch (Exception e) {
			logger.error(
					"error while getting jobDataMap from jobContext. jobContext : "
							+ jobContext, e);
		}
		IJobExecutor jobExecutor = (IJobExecutor) jobDataMap
				.get(QuartzJobService.JOB_EXECUTOR);
		JobDetail jobDetail = (JobDetail) jobDataMap
				.get(QuartzJobService.JOB_KEY);
		if ( jobExecutor == null ) {
			logger.error("jobExecutor is null, return directly.");
			return;
		}
		
		if( jobDetail == null){
			logger.error("jobDetail is null, return directly. ");
			return;
		}
		
		// 当且仅当任务的状态为启用时，才执行调度任务，否则直接返回
		if (jobDetail.getStatus() == EJobDetailStatus.PAUSE.ordinal()) {
			logger.debug(jobExecutor.getName() + "(" + jobExecutor.toString()
					+ ")" + jobDetail.getJobName() + "(" + jobDetail.toString()
					+ ")" + ") is paused. So return directly!");
			return;
		}

		if (jobDetail.getStatus() == EJobDetailStatus.RUN.ordinal()) {
			logger.debug(jobExecutor.getName() + "(" + jobExecutor.toString()
					+ ")" + jobDetail.getJobName() + "(" + jobDetail.toString()
					+ ")" + ") is executing...");
			jobExecutor.execute(jobDetail);
			logger.debug(jobExecutor.getName() + "(" + jobExecutor.toString()
					+ ")" + jobDetail.getJobName() + "(" + jobDetail.toString()
					+ ")" + ") already executed.");

			return;
		}

	}
}
