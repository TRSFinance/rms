/*
 * Created: yangyu@May 31, 2013 10:06:34 AM
 */
package com.trs.dev4.jdk16.cms.bo;

import java.util.List;

import com.trs.dev4.jdk16.cms.enu.ExpressionType;
import com.trs.dev4.jdk16.cms.expression.FilterByFieldTagExpression;
import com.trs.dev4.jdk16.cms.expression.OrderByTagExpresion;
import com.trs.dev4.jdk16.utils.CollectionUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: <br>
 * 
 */
public class ExpressionResult implements Comparable<ExpressionResult> {
	
	private Object result;
	
	private ExpressionType expressionType;

	public ExpressionResult() {

	}

	/**
	 * @param expressionValueType
	 * @param result
	 */
	public ExpressionResult(ExpressionType expressionValueType, Object result) {
		this.expressionType = expressionValueType;
		this.result = result;
	}

	/**
	 * @param expressions
	 */
	public ExpressionResult(Object result) {
		this.expressionType = ExpressionType.UNDEFINED;
		this.result = result;
	}

	/**
	 * @return
	 * @since yangyu @ May 31, 2013
	 */
	public int getIntValue() {
		return (Integer) result;
	}

	/**
	 * @return
	 * @since yangyu @ May 31, 2013
	 */
	@SuppressWarnings("unchecked")
	public List<OrderByTagExpresion> getOrderByArray() {
		return (List<OrderByTagExpresion>) result;
	}
	/**
	 * @return
	 * @since yangyu @ May 31, 2013
	 */
	public String getStringValue() {
		return String.valueOf(result);
	}

	/**
	 * @return
	 * @since yangyu @ May 31, 2013
	 */
	public boolean getBooleanValue() {
		return (Boolean) result;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

	public ExpressionType getExpressionType() {
		return expressionType;
	}

	public void setExpressionType(ExpressionType expressionValueType) {
		this.expressionType = expressionValueType;
	}

	public boolean isEmpty() {
		if (result == null) {
			return true;
		} else if (result instanceof String) {
			String resultString = (String) result;
			return StringHelper.isEmpty(resultString);
		} else {
			return false;
		}
	}
	
	/**
	 * @return
	 * @since yangyu @ Jun 6, 2013
	 */
	public String[] getStringArray() {
		return (String[]) result;
	}

	/**
	 * @return
	 * @since yangyu @ Jun 6, 2013
	 */
	public List<Integer> getIntArray() {
		return CollectionUtil.toCollection((int[]) result);
	}

	@Override
	public int compareTo(ExpressionResult o) {

		if (o.getExpressionType().equals(ExpressionType.INT)) {
			int v1 = this.getIntValue();
			int v2 = o.getIntValue();
			if (v1 > v2) {
				return 1;
			} else if (v1 == v2) {
				return 0;
			} else {
				return -1;
			}
		}
		return -1;
	}

	/**
	 * @return
	 * @since yangyu @ Jun 13, 2013
	 */
	@SuppressWarnings("unchecked")
	public List<FilterByFieldTagExpression> getFilterByFieldList() {
		return (List<FilterByFieldTagExpression>) result;
	}
}
