/*
 * Created: liushen@Apr 26, 2012 6:12:04 PM
 */
package com.trs.dev4.jdk16.dao.hb3.dialect;

import java.sql.Types;

import org.hibernate.dialect.SQLServerDialect;

/**
 * 扩展Hibernate默认的SQLServer方言，用nvarchar代替varchar作为字符串类型的映射，更好地支持多语言，
 * 避免包含中文的字符串的长度计算不一致导致截断错误。 <br>
 * 
 */
public class SQLServerUnicodeDialect extends SQLServerDialect {

	/**
	 * 覆盖varchar类型的注册声明；注意<code>$l</code>中是length的l，而不是1。
	 */
	public SQLServerUnicodeDialect() {
		super();
		registerColumnType(Types.VARCHAR, "nvarchar($l)");
	}

}
