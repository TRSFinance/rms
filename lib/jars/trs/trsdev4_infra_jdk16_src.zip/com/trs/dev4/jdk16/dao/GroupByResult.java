/*
 * Created: liushen@Apr 26, 2010 4:34:47 PM
 */
package com.trs.dev4.jdk16.dao;

import java.util.Collections;
import java.util.List;

/**
 * group by的分类结果. <br>
 */
public class GroupByResult {

	/**
	 * 分类字段的字段名.
	 */
	private String fieldName;

	/**
	 * 按该分类字段进行group by得到的所有记录.
	 */
	private List<GroupByRecord> records;

	/**
	 * 
	 */
	public GroupByResult(String fieldName, List<GroupByRecord> records) {
		this.fieldName = fieldName;
		this.records = records;
	}

	/**
	 * @return the {@link #fieldName}
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @return the {@link #records}
	 */
	public List<GroupByRecord> getRecords() {
		if (records == null) {
			return Collections.emptyList();
		}
		return records;
	}

	/**
	 * group by分类结果中的单条记录. <br>
	 */
	public static class GroupByRecord {

		/**
		 * 分类字段的取值.
		 */
		private Object fieldValue;

		/**
		 * 该分类的记录数.
		 */
		private int recordCount;

		/**
		 * 
		 */
		public GroupByRecord(Object fieldValue, int recordCount) {
			this.fieldValue = fieldValue;
			this.recordCount = recordCount;
		}

		/**
		 * @return the {@link #fieldValue}
		 */
		public Object getFieldValue() {
			return fieldValue;
		}

		/**
		 * @return the {@link #recordCount}
		 */
		public int getRecordCount() {
			return recordCount;
		}

	}

}
