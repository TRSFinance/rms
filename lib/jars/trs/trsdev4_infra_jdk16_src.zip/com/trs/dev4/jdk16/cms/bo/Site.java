package com.trs.dev4.jdk16.cms.bo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.AccessType;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.trs.dev4.jdk16.model.BaseEntity;

/**
 * 职责：站点对象<br>
 * 
 * @author TRS信息技术股份有限公司
 * 
 * @since 2012.02.08
 */
@Entity
@Table(name = "`SITE`")
@SequenceGenerator(name = "SEQ_SITE", sequenceName = "SEQ_SITE")
@GenericGenerator(name = "idStrategy", strategy = "native", parameters = { @Parameter(name = "sequence", value = "SEQ_SITE") })
public class Site extends BaseEntity {

	/**
	 * @since yangyu @ Jul 12, 2012
	 */
	private static final long serialVersionUID = -7197667001202389599L;
	
	public final static Site EMPTYSITE = new Site();

	/**
	 * 站点名
	 */
	@Column(name = "`NAME`")
	private String name;

	/**
	 * 图片Url
	 */
	@Column(name = "`IMAGEURL`")
	private String imageUrl;

	/**
	 * 站点描述
	 */
	@Column(name = "`DESCRIPTION`")
	private String description;
	/**
	 * 模板名
	 */
	@Column(name = "`HOMETEMPLATE`")
	private String homeTemplate;
	
	@Transient
	private String zipName;

	@Transient
	private String imagesLocation;

	@Transient
	private String cssLocation;

	@Transient
	private String jsLocation;
	
	private String exportType = "no";
	
	private String siteMark;

	/**
	 * 状态
	 */
	@Column(name = "`SITESTATUS`")
	private int status;
	
	
	
	@Transient
	private String initType;
	
	@Transient
	private int templateNum;

	@Transient
	private int pagelinkNum;

	/**
	 * 是否自动追加 baseurl
	 */
	@Column(name = "`AUTOATTACHBASEURL`")
	@AccessType("com.trs.dev4.jdk16.dao.SafeDirectPropertyAccessor")
	private boolean autoAttachBaseUrl = true;

	/**
	 * 是否压缩 HTML
	 */
	@Column(name = "`COMPRESSEDHTML`")
	@AccessType("com.trs.dev4.jdk16.dao.SafeDirectPropertyAccessor")
	private boolean compressedHtml = true;
	
	/**
	 * 
	 */
	public Site() {

	}
	
	/**
	 * 
	 * @param id
	 * @param title
	 */
	public Site(int id, String name){
		this.id = id;
		this.name  =name;
	}
	/**
	 * @return the id
	 */
	@Override
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	@Override
	public void setId(int id) {
		this.id = id;
	}


	/**
	 * @return the imageUrl
	 */
	public String getImageUrl() {
		return imageUrl;
	}

	/**
	 * @param imageUrl the imageUrl to set
	 */
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	/**
	 * @return the description
	 */
	@Override
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the homeTemplate
	 */
	public String getHomeTemplate() {
		return homeTemplate;
	}
	/**
	 * @param homeTemplate the homeTemplate to set
	 */
	public void setHomeTemplate(String homeTemplate) {
		this.homeTemplate = homeTemplate;
	}
	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	public String getZipName() {
		return zipName;
	}

	public void setZipName(String zipName) {
		this.zipName = zipName;
	}
	public String getImagesLocation() {
		return imagesLocation;
	}

	public void setImagesLocation(String imagesLocation) {
		this.imagesLocation = imagesLocation;
	}

	public String getCssLocation() {
		return cssLocation;
	}

	public void setCssLocation(String cssLocation) {
		this.cssLocation = cssLocation;
	}

	public String getJsLocation() {
		return jsLocation;
	}

	public void setJsLocation(String jsLocation) {
		this.jsLocation = jsLocation;
	}
	public String getExportType() {
		return exportType;
	}

	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	public String getSiteMark() {
		return siteMark;
	}

	public void setSiteMark(String siteMark) {
		this.siteMark = siteMark;
	}

	public String getInitType() {
		return initType;
	}

	public void setInitType(String initType) {
		this.initType = initType;
	}

	public int getTemplateNum() {
		return templateNum;
	}

	public void setTemplateNum(int templateNum) {
		this.templateNum = templateNum;
	}

	public int getPagelinkNum() {
		return pagelinkNum;
	}

	public void setPagelinkNum(int pagelinkNum) {
		this.pagelinkNum = pagelinkNum;
	}

	public boolean isEmpty() {
		return id == 0;
	}

	/**
	 * @return the {@link #autoAttachBaseUrl}
	 */
	public boolean isAutoAttachBaseUrl() {
		return autoAttachBaseUrl;
	}

	/**
	 * @param autoAttachBaseUrl
	 *            the {@link #autoAttachBaseUrl} to set
	 */
	public void setAutoAttachBaseUrl(boolean autoAttachBaseUrl) {
		this.autoAttachBaseUrl = autoAttachBaseUrl;
	}

	/**
	 * @return the {@link #compressedHtml}
	 */
	public boolean isCompressedHtml() {
		return compressedHtml;
	}

	/**
	 * @param compressedHtml
	 *            the {@link #compressedHtml} to set
	 */
	public void setCompressedHtml(boolean compressedHtml) {
		this.compressedHtml = compressedHtml;
	}
	
}
