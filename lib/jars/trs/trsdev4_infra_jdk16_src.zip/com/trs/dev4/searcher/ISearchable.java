/**
 * Created: chuchanglin@2010-2-23 上午11:28:44
 */
package com.trs.dev4.searcher;

/**
 * 标识可以进行全文检索的领域对象
 * 
 * @author chuchanglin
 */
public interface ISearchable {
	
}
